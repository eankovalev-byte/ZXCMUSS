package com.zxcmuss.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.math.abs

/** «Рыбий глаз»: центр экрана плеера слегка увеличен, края сжаты. Сила регулируется в настройках. */
class FisheyeLayout(c: Context) : FrameLayout(c) {
    /** 0 — выключено, до 0.5 — максимум (при большем значении края «складываются») */
    var strength = 0f
        set(v) { field = v.coerceIn(0f, 0.5f); invalidate() }

    private val gx = 22
    private val gy = 34
    private val scale = 0.8f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var bmp: Bitmap? = null
    private var verts = FloatArray(0)
    private var meshK = -1f
    private var meshW = 0
    private var meshH = 0
    private var skip = 0
    private var scaled = FloatArray(0)

    private fun warp(s: Float, k: Float): Float {
        val a = abs(s).coerceAtMost(1f)
        val d = a * (1f + k) - k * a * a * a
        return if (s < 0) -d else d
    }

    /** Обратное преобразование для касаний (метод Ньютона). */
    private fun unwarp(d: Float, k: Float): Float {
        val a = abs(d).coerceAtMost(1f)
        var s = a
        for (i in 0 until 6) {
            val f = s * (1f + k) - k * s * s * s - a
            val df = 1f + k - 3f * k * s * s
            if (abs(df) < 1e-4f) break
            s = (s - f / df).coerceIn(0f, 1f)
        }
        return if (d < 0) -s else s
    }

    private fun buildMesh() {
        val w = width.toFloat(); val h = height.toFloat()
        verts = FloatArray((gx + 1) * (gy + 1) * 2)
        var n = 0
        for (j in 0..gy) {
            val v = -1f + 2f * j / gy
            val dy = warp(v, strength)
            for (i in 0..gx) {
                val u = -1f + 2f * i / gx
                val dx = warp(u, strength)
                verts[n++] = w / 2f + dx * w / 2f
                verts[n++] = h / 2f + dy * h / 2f
            }
        }
        scaled = FloatArray(verts.size) { verts[it] * scale }
        meshK = strength; meshW = width; meshH = height
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (strength < 0.01f || width == 0 || height == 0) { super.dispatchDraw(canvas); return }
        val bw = (width * scale).toInt().coerceAtLeast(1)
        val bh = (height * scale).toInt().coerceAtLeast(1)
        var b = bmp
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp = b
            skip = 0
        }
        if (meshK != strength || meshW != width || meshH != height) buildMesh()
        // содержимое перерисовываем через кадр — экономим батарею
        if (skip++ % 2 == 0) {
            b.eraseColor(0)
            val bc = Canvas(b)
            bc.scale(scale, scale)
            super.dispatchDraw(bc)
        }
        // sx/sy: bitmap-mesh рисует в координатах bitmap, поэтому масштабируем холст
        canvas.save()
        canvas.scale(1f / scale, 1f / scale)
        // вершины заданы в размере экрана → приводим к размеру bitmap
        val sv = scaled
        canvas.drawBitmapMesh(b, gx, gy, sv, 0, null, 0, paint)
        canvas.restore()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (strength < 0.01f || ev.pointerCount != 1 || width == 0) return super.dispatchTouchEvent(ev)
        val u = (ev.x / width) * 2f - 1f
        val v = (ev.y / height) * 2f - 1f
        val nx = (unwarp(u, strength) + 1f) / 2f * width
        val ny = (unwarp(v, strength) + 1f) / 2f * height
        val e = MotionEvent.obtain(ev)
        e.setLocation(nx, ny)
        val r = super.dispatchTouchEvent(e)
        e.recycle()
        return r
    }
}

/** Рамка карточки: на удар баса от неё медленно расходятся и тают волны. */
class WaveFrame(c: Context) : FrameLayout(c) {
    private class W(val born: Long)

    private val waves = ArrayList<W>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val d = c.resources.displayMetrics.density
    private var avg = 0f
    private var prev = 0f
    private var lastBeat = 0L
    private var level = 0f
    var corner = 30f * d

    init { setWillNotDraw(false) }

    /** Вызывается каждый кадр со значением баса 0..1. */
    fun feed(bass: Float) {
        val now = System.currentTimeMillis()
        avg += (bass - avg) * 0.04f
        level += (bass - level) * 0.35f
        if (bass > 0.28f && bass > avg * 1.22f + 0.05f && bass > prev && now - lastBeat > 420) {
            waves.add(W(now))
            lastBeat = now
            if (waves.size > 5) waves.removeAt(0)
        }
        prev = bass
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val now = System.currentTimeMillis()
        val it = waves.iterator()
        val col = Theme.NEON
        val r0 = Color_r(col); val g0 = Color_g(col); val b0 = Color_b(col)
        while (it.hasNext()) {
            val w = it.next()
            val t = (now - w.born) / 2600f
            if (t >= 1f) { it.remove(); continue }
            val e = 1f - (1f - t) * (1f - t)
            val grow = 15f * d * e
            val a = Math.pow((1f - t).toDouble(), 1.7).toFloat() * 0.6f * Theme.GLOW
            p.strokeWidth = (2.4f * (1f - t * 0.6f)) * d
            p.color = android.graphics.Color.argb((a * 255).toInt().coerceIn(0, 255), r0, g0, b0)
            rect.set(-grow, -grow, width + grow, height + grow)
            canvas.drawRoundRect(rect, corner + grow, corner + grow, p)
        }
        super.dispatchDraw(canvas)
        // сама обводка тоже «дышит» от баса
        val a = (level * 1.4f).coerceIn(0f, 1f) * 0.75f
        if (a > 0.03f) {
            p.strokeWidth = 1.6f * d
            p.color = android.graphics.Color.argb((a * 255).toInt(), r0, g0, b0)
            rect.set(0.8f * d, 0.8f * d, width - 0.8f * d, height - 0.8f * d)
            canvas.drawRoundRect(rect, corner, corner, p)
        }
    }

    private fun Color_r(c: Int) = android.graphics.Color.red(c)
    private fun Color_g(c: Int) = android.graphics.Color.green(c)
    private fun Color_b(c: Int) = android.graphics.Color.blue(c)
}
