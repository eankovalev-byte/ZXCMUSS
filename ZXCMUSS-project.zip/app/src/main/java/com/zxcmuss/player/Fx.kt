package com.zxcmuss.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.view.MotionEvent
import android.annotation.TargetApi
import android.widget.FrameLayout
import kotlin.math.sqrt

/**
 * «Рыбий глаз»: настоящее бочкообразное искажение (как у объектива): центр выпуклый и увеличенный,
 * к краям и углам картинка сжимается и изгибается. Ничего не растягивается за экран.
 * Android 13+: считается на видеокарте шейдером (без нагрузки). Ниже: упрощённая сетка.
 */
class FisheyeLayout(c: Context) : FrameLayout(c) {
    /** 0 — выключено, до 0.5 — максимум */
    var strength = 0f
        set(v) { field = v.coerceIn(0f, 0.5f); update(); invalidate() }

    private val gpu = Build.VERSION.SDK_INT >= 33
    private var shader: Any? = null

    // fallback (Android 10–12)
    private val gx = 20
    private val gy = 32
    private val scale = 0.6f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var bmp: Bitmap? = null
    private var verts = FloatArray(0)
    private var meshK = -1f
    private var meshW = 0
    private var meshH = 0
    private var skip = 0

    private fun cc(k: Float) = 1f / (1f + k / 2f)

    /** Радиус на экране → радиус в исходной картинке (метод половинного деления). */
    private fun solve(ro: Float, k: Float): Float {
        val c = cc(k)
        var lo = 0f; var hi = 1f
        for (i in 0 until 16) {
            val m = (lo + hi) * 0.5f
            val dd = c * (m * (1f + k) - k * m * m * m)
            if (dd < ro) lo = m else hi = m
        }
        return (lo + hi) * 0.5f
    }

    init { clipChildren = false }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        update()
    }

    private fun update() {
        if (Build.VERSION.SDK_INT >= 33) applyShader()
    }

    @TargetApi(33)
    private fun applyShader() {
        if (strength < 0.01f || width == 0 || height == 0) { setRenderEffect(null); return }
        var s = shader as? RuntimeShader
        if (s == null) { s = RuntimeShader(AGSL); shader = s }
        s.setFloatUniform("size", width.toFloat(), height.toFloat())
        s.setFloatUniform("k", strength)
        s.setFloatUniform("c", cc(strength))
        setRenderEffect(RenderEffect.createRuntimeShaderEffect(s, "content"))
    }

    private fun buildMesh() {
        val w = width.toFloat(); val h = height.toFloat()
        val k = strength; val c = cc(k)
        verts = FloatArray((gx + 1) * (gy + 1) * 2)
        var n = 0
        for (j in 0..gy) {
            val v = -1f + 2f * j / gy
            for (i in 0..gx) {
                val u = -1f + 2f * i / gx
                val r2 = (u * u + v * v) / 2f
                val g = c * (1f + k - k * r2)
                verts[n++] = (w / 2f + u * g * w / 2f) * scale
                verts[n++] = (h / 2f + v * g * h / 2f) * scale
            }
        }
        meshK = strength; meshW = width; meshH = height
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (gpu || strength < 0.01f || width == 0 || height == 0) { super.dispatchDraw(canvas); return }
        val bw = (width * scale).toInt().coerceAtLeast(1)
        val bh = (height * scale).toInt().coerceAtLeast(1)
        var b = bmp
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp = b
            skip = 0
        }
        if (meshK != strength || meshW != width || meshH != height) buildMesh()
        if (skip++ % 2 == 0) {
            b.eraseColor(0)
            val bc = Canvas(b)
            bc.scale(scale, scale)
            super.dispatchDraw(bc)
        }
        canvas.save()
        canvas.scale(1f / scale, 1f / scale)
        canvas.drawBitmapMesh(b, gx, gy, verts, 0, null, 0, paint)
        canvas.restore()
        postInvalidateOnAnimation()
    }

    private val tmp = FloatArray(2)

    /** Точка на экране → точка в «неискажённом» содержимом (для касаний). */
    private fun unmap(x: Float, y: Float) {
        val k = strength; val c = cc(k)
        val u = x / width * 2f - 1f
        val v = y / height * 2f - 1f
        val ro = sqrt(u * u + v * v) * 0.70710678f
        val sc = if (ro < 1e-5f) 1f / (c * (1f + k)) else {
            val rr = if (ro >= c) 1f else solve(ro, k)
            rr / ro
        }
        val su = (u * sc).coerceIn(-1f, 1f)
        val sv = (v * sc).coerceIn(-1f, 1f)
        tmp[0] = (su * 0.5f + 0.5f) * width
        tmp[1] = (sv * 0.5f + 0.5f) * height
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (strength < 0.01f || width == 0 || height == 0) return super.dispatchTouchEvent(ev)
        val n = ev.pointerCount
        val props = Array(n) { MotionEvent.PointerProperties() }
        val coords = Array(n) { MotionEvent.PointerCoords() }
        for (i in 0 until n) {
            ev.getPointerProperties(i, props[i])
            ev.getPointerCoords(i, coords[i])
            unmap(coords[i].x, coords[i].y)
            coords[i].x = tmp[0]; coords[i].y = tmp[1]
        }
        val e = MotionEvent.obtain(ev.downTime, ev.eventTime, ev.action, n, props, coords,
            ev.metaState, ev.buttonState, ev.xPrecision, ev.yPrecision, ev.deviceId, ev.edgeFlags, ev.source, ev.flags)
        val r = super.dispatchTouchEvent(e)
        e.recycle()
        return r
    }

    companion object {
        private const val AGSL = """
uniform shader content;
uniform float2 size;
uniform float k;
uniform float c;
half4 main(float2 fc) {
    float2 p = fc / size * 2.0 - 1.0;
    float ro = length(p) * 0.70710678;
    if (ro > c) return half4(0.0);
    float lo = 0.0;
    float hi = 1.0;
    for (int i = 0; i < 14; i++) {
        float m = (lo + hi) * 0.5;
        float dd = c * (m * (1.0 + k) - k * m * m * m);
        if (dd < ro) { lo = m; } else { hi = m; }
    }
    float rr = (lo + hi) * 0.5;
    float sc = ro > 0.00001 ? rr / ro : 1.0 / (c * (1.0 + k));
    float2 s = p * sc;
    if (abs(s.x) > 1.0 || abs(s.y) > 1.0) return half4(0.0);
    return content.eval((s * 0.5 + 0.5) * size);
}
"""
    }
}

/** Рамка карточки: на удар баса от неё медленно расходятся и тают волны. */
class WaveFrame(c: Context) : FrameLayout(c) {
    private class W(val born: Long)

    private val waves = ArrayList<W>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val d = c.resources.displayMetrics.density
    private var avg = 0f
    private var prev = 0f
    private var lastBeat = 0L
    private var level = 0f
    var corner = 30f * d

    init { setWillNotDraw(false) }

    private var prevRaw = 0f
    private var fluxAvg = 0.03f

    /** Каждый кадр: сглаженный бас и «сырой» бас 0..1. Волна на каждый заметный удар, в том числе частые парные. */
    fun feed(bass: Float, raw: Float) {
        val now = System.currentTimeMillis()
        avg += (raw - avg) * 0.03f
        level += (bass - level) * 0.35f
        val flux = raw - prevRaw
        fluxAvg += (Math.abs(flux) - fluxAvg) * 0.05f
        val hit = flux > Math.max(0.04f, fluxAvg * 1.25f) && raw > 0.15f && raw > avg * 0.9f
        if (hit && now - lastBeat > 100) {
            waves.add(W(now))
            lastBeat = now
            if (waves.size > 9) waves.removeAt(0)
        }
        prevRaw = raw
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val now = System.currentTimeMillis()
        val it = waves.iterator()
        val col = Theme.NEON
        val r0 = Color_r(col); val g0 = Color_g(col); val b0 = Color_b(col)
        while (it.hasNext()) {
            val w = it.next()
            val t = (now - w.born) / 2600f
            if (t >= 1f) { it.remove(); continue }
            val e = 1f - (1f - t) * (1f - t)
            val grow = 15f * d * e
            val a = Math.pow((1f - t).toDouble(), 1.7).toFloat() * 0.6f * Theme.GLOW
            p.strokeWidth = (2.4f * (1f - t * 0.6f)) * d
            p.color = android.graphics.Color.argb((a * 255).toInt().coerceIn(0, 255), r0, g0, b0)
            rect.set(-grow, -grow, width + grow, height + grow)
            canvas.drawRoundRect(rect, corner + grow, corner + grow, p)
        }
        super.dispatchDraw(canvas)
        // сама обводка тоже «дышит» от баса
        val a = (level * 1.4f).coerceIn(0f, 1f) * 0.75f
        if (a > 0.03f) {
            p.strokeWidth = 1.6f * d
            p.color = android.graphics.Color.argb((a * 255).toInt(), r0, g0, b0)
            rect.set(0.8f * d, 0.8f * d, width - 0.8f * d, height - 0.8f * d)
            canvas.drawRoundRect(rect, corner, corner, p)
        }
    }

    private fun Color_r(c: Int) = android.graphics.Color.red(c)
    private fun Color_g(c: Int) = android.graphics.Color.green(c)
    private fun Color_b(c: Int) = android.graphics.Color.blue(c)
}
