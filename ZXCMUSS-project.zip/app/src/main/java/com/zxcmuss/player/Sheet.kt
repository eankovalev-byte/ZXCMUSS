package com.zxcmuss.player

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Красивая нижняя шторка вместо системного диалога: стекло, неоновые иконки, анимация. */
class Sheet(private val act: Activity) {

    class Row(
        val icon: Int,
        val label: String,
        val value: String? = null,
        val checked: Boolean = false,
        val accent: Boolean = false,
        val onClick: () -> Unit
    )

    private val dm = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dm).toInt()

    private fun selectable(): Drawable? {
        val a = act.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
        val d = a.getDrawable(0)
        a.recycle()
        return d
    }

    private fun label(sp: Float, color: Int, medium: Boolean = true) = TextView(act).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = Typeface.create(if (medium) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        includeFontPadding = false
    }

    fun show(title: String, rows: List<Row>, footer: String? = null) {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(26))
            val r = dp(30).toFloat()
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xF4082015.toInt(), 0xF6030A06.toInt())
            ).apply {
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), 0x55B7F5D1)
            }
        }

        root.addView(View(act).apply {
            background = GradientDrawable().apply { cornerRadius = dp(2).toFloat(); setColor(0x44FFFFFF) }
        }, LinearLayout.LayoutParams(dp(38), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })

        root.addView(label(12f, Theme.NEON).apply {
            text = title.uppercase()
            letterSpacing = 0.2f
            setPadding(dp(8), 0, 0, dp(8))
        })

        for (row in rows) {
            val line = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = selectable()
                isClickable = true
            }
            val box = FrameLayout(act).apply {
                background = GradientDrawable().apply { cornerRadius = dp(13).toFloat(); setColor(0x1F2BFD89) }
            }
            box.addView(ImageView(act).apply {
                setImageResource(row.icon)
                setColorFilter(Theme.NEON)
            }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            line.addView(box, LinearLayout.LayoutParams(dp(42), dp(42)))

            line.addView(label(16f, Color.WHITE).apply { text = row.label },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })

            if (row.value != null) {
                line.addView(label(14f, if (row.accent) Theme.NEON else Theme.DIM).apply { text = row.value })
            }
            if (row.checked) {
                line.addView(ImageView(act).apply {
                    setImageResource(R.drawable.ic_check)
                    setColorFilter(Theme.NEON)
                }, LinearLayout.LayoutParams(dp(24), dp(24)))
            }
            line.setOnClickListener { d.dismiss(); row.onClick() }
            root.addView(line, LinearLayout.LayoutParams(-1, -2))
        }

        if (footer != null) {
            root.addView(label(14f, 0xCCFFFFFF.toInt(), false).apply {
                text = footer
                setLineSpacing(0f, 1.2f)
                setPadding(dp(8), dp(10), dp(8), dp(4))
            })
        }

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.62f)
            val lp = attributes
            lp.windowAnimations = R.style.SheetAnim
            attributes = lp
        }
        d.show()
    }
}
