package com.zxcmuss.player

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Красивая нижняя шторка вместо системного диалога: стекло, неоновые иконки, анимация. */
class Sheet(private val act: Activity) {

    class Row(
        val icon: Int,
        val label: String,
        val value: String? = null,
        val checked: Boolean = false,
        val accent: Boolean = false,
        val swatch: Int = 0,
        val onClick: () -> Unit
    )

    private val dm = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dm).toInt()

    private fun selectable(): Drawable? {
        val a = act.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
        val d = a.getDrawable(0)
        a.recycle()
        return d
    }

    private fun label(sp: Float, color: Int, medium: Boolean = true) = TextView(act).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = Typeface.create(if (medium) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        includeFontPadding = false
    }

    fun show(title: String, rows: List<Row>, footer: String? = null, signature: String? = null, extra: View? = null) {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(26))
            val r = dp(30).toFloat()
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Theme.SHEET_TOP, Theme.SHEET_BOT)
            ).apply {
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), Theme.alpha(Theme.EDGE, 0x55))
            }
        }

        root.addView(View(act).apply {
            background = GradientDrawable().apply { cornerRadius = dp(2).toFloat(); setColor(Theme.alpha(Theme.TEXT, 0x44)) }
        }, LinearLayout.LayoutParams(dp(38), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })

        root.addView(label(12f, Theme.NEON).apply {
            text = title.uppercase()
            letterSpacing = 0.2f
            setPadding(dp(8), 0, 0, dp(8))
        })

        val box0 = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        if (extra != null) box0.addView(extra, LinearLayout.LayoutParams(-1, -2))
        for (row in rows) {
            val line = LinearLayout(act).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = selectable()
                isClickable = true
            }
            val box = FrameLayout(act).apply {
                background = GradientDrawable().apply { cornerRadius = dp(13).toFloat(); setColor(Theme.accentA(0x1F)) }
            }
            if (row.swatch != 0) {
                box.addView(View(act).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(row.swatch)
                        setStroke(dp(2), Theme.alpha(Theme.TEXT, 0x55))
                    }
                }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            } else {
                box.addView(ImageView(act).apply {
                    setImageResource(row.icon)
                    setColorFilter(Theme.NEON)
                }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            }
            line.addView(box, LinearLayout.LayoutParams(dp(42), dp(42)))

            line.addView(label(16f, Theme.TEXT).apply { text = row.label },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })

            if (row.value != null) {
                line.addView(label(14f, if (row.accent) Theme.NEON else Theme.DIM).apply { text = row.value })
            }
            if (row.checked) {
                line.addView(ImageView(act).apply {
                    setImageResource(R.drawable.ic_check)
                    setColorFilter(Theme.NEON)
                }, LinearLayout.LayoutParams(dp(24), dp(24)))
            }
            line.setOnClickListener { d.dismiss(); row.onClick() }
            box0.addView(line, LinearLayout.LayoutParams(-1, -2))
        }

        if (footer != null) {
            box0.addView(label(14f, Theme.alpha(Theme.TEXT, 0xCC), false).apply {
                text = footer
                setLineSpacing(0f, 1.2f)
                setPadding(dp(8), dp(10), dp(8), dp(4))
            })
        }

        root.addView(ScrollView(act).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(box0)
        }, LinearLayout.LayoutParams(-1, -2))

        if (signature != null) {
            root.addView(label(12f, Theme.alpha(Theme.TEXT, 0x59), false).apply {
                text = signature
                gravity = Gravity.CENTER
                setPadding(0, dp(16), 0, dp(2))
                setOnClickListener {
                    try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/xosub"))) } catch (_: Exception) {}
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.62f)
            val lp = attributes
            lp.windowAnimations = R.style.SheetAnim
            attributes = lp
        }
        d.show()
    }
}
