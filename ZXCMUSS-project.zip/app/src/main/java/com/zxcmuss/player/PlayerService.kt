package com.zxcmuss.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast

class PlayerService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlayerService get() = this@PlayerService
    }

    companion object {
        const val ACTION_TOGGLE = "com.zxcmuss.player.TOGGLE"
        const val ACTION_NEXT = "com.zxcmuss.player.NEXT"
        const val ACTION_PREV = "com.zxcmuss.player.PREV"
        const val CHANNEL = "zxcmuss_playback"
        const val NOTIF_ID = 1
    }

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var session: MediaSession
    private lateinit var nm: NotificationManager

    private var player: MediaPlayer? = null
    private var original: List<Track> = emptyList()
    var queue: List<Track> = emptyList()
        private set
    var index = -1
        private set
    var shuffle = false
        private set
    /** 0 — без повтора, 1 — повтор всех, 2 — зациклить трек */
    var repeat = 0
        private set
    var sleepEndsAt = 0L
        private set

    var onChange: (() -> Unit)? = null

    private var fg = false
    private var resumeOnGain = false
    private var focusReq: AudioFocusRequest? = null
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    val current: Track? get() = queue.getOrNull(index)
    val isPlaying: Boolean get() = try { player?.isPlaying == true } catch (_: Exception) { false }
    val position: Int get() = try { player?.currentPosition ?: 0 } catch (_: Exception) { 0 }
    val duration: Int get() = try { player?.duration ?: current?.durationMs?.toInt() ?: 0 } catch (_: Exception) { 0 }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { pause() }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeOnGain = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> if (isPlaying) { resumeOnGain = true; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(0.3f, 0.3f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.setVolume(1f, 1f)
                if (resumeOnGain) { resumeOnGain = false; play() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("zx", MODE_PRIVATE)
        shuffle = prefs.getBoolean("shuffle", false)
        repeat = prefs.getInt("repeat", 0)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Воспроизведение", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "ZXCMUSS").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { play() }
                override fun onPause() { pause() }
                override fun onSkipToNext() { next() }
                override fun onSkipToPrevious() { prev() }
                override fun onSeekTo(pos: Long) { seekTo(pos.toInt()) }
            })
            isActive = true
        }
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> toggle()
            ACTION_NEXT -> next()
            ACTION_PREV -> prev()
            else -> { startFg(buildNotification()); updateNotification() }
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!isPlaying) stopSelf()
    }

    override fun onDestroy() {
        savePosition()
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(noisy) } catch (_: Exception) {}
        releaseFx()
        player?.release(); player = null
        session.release()
        super.onDestroy()
    }

    // ---------- управление ----------

    fun setQueue(list: List<Track>, start: Int, autoplay: Boolean, seekMs: Int = 0) {
        if (list.isEmpty() || start !in list.indices) return
        original = list
        val cur = list[start]
        queue = if (shuffle) listOf(cur) + list.filter { it.id != cur.id }.shuffled() else list
        index = queue.indexOfFirst { it.id == cur.id }
        load(autoplay, seekMs)
    }

    fun play() {
        val mp = player ?: return
        if (!requestFocus()) return
        try { mp.start() } catch (_: Exception) {}
        updateAll()
    }

    fun pause() {
        try { player?.pause() } catch (_: Exception) {}
        savePosition()
        updateAll()
    }

    fun toggle() { if (isPlaying) pause() else play() }

    fun next() {
        if (queue.isEmpty()) return
        index = if (index + 1 < queue.size) index + 1 else 0
        load(true)
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (position > 3000) { seekTo(0); return }
        index = if (index - 1 >= 0) index - 1 else queue.size - 1
        load(true)
    }

    fun seekTo(ms: Int) {
        try { player?.seekTo(ms) } catch (_: Exception) {}
        updateSession()
    }

    fun setShuffle(on: Boolean) {
        shuffle = on
        prefs.edit().putBoolean("shuffle", on).apply()
        val cur = current
        if (cur != null && original.isNotEmpty()) {
            queue = if (on) listOf(cur) + original.filter { it.id != cur.id }.shuffled() else original
            index = queue.indexOfFirst { it.id == cur.id }
        }
        updateAll()
    }

    fun cycleRepeat() {
        repeat = (repeat + 1) % 3
        prefs.edit().putInt("repeat", repeat).apply()
        try { player?.isLooping = repeat == 2 } catch (_: Exception) {}
        updateAll()
    }

    /** minutes = 0 — выключить таймер сна */
    fun setSleepTimer(minutes: Int) {
        handler.removeCallbacks(sleepRun)
        if (minutes > 0) {
            sleepEndsAt = System.currentTimeMillis() + minutes * 60_000L
            handler.postDelayed(sleepRun, minutes * 60_000L)
        } else sleepEndsAt = 0L
        onChange?.invoke()
    }

    private val sleepRun = Runnable { sleepEndsAt = 0L; pause() }

    // ---------- эквалайзер и бас-буст ----------

    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    val fxOn: Boolean get() = prefs.getBoolean("fx", false)
    val bassLevel: Int get() = prefs.getInt("bass", 0)
    fun eqPct(i: Int): Int = prefs.getInt("eq$i", 0)
    fun eqBandCount(): Int = eq?.numberOfBands?.toInt() ?: 5
    fun eqFreq(i: Int): Int = try { eq!!.getCenterFreq(i.toShort()) / 1000 } catch (_: Exception) { intArrayOf(60, 230, 910, 3600, 14000).getOrElse(i) { 1000 } }

    private fun releaseFx() {
        try { eq?.release() } catch (_: Exception) {}
        try { bassFx?.release() } catch (_: Exception) {}
        eq = null; bassFx = null
    }

    private fun applyFx(sid: Int) {
        releaseFx()
        try { eq = Equalizer(0, sid) } catch (_: Exception) { eq = null }
        try { bassFx = BassBoost(0, sid) } catch (_: Exception) { bassFx = null }
        syncEq(); syncBass()
    }

    private fun syncEq() {
        val e = eq ?: return
        try {
            e.enabled = fxOn
            val r = e.bandLevelRange
            for (i in 0 until e.numberOfBands) {
                val pct = eqPct(i)
                val lv = if (pct >= 0) pct * r[1] / 100 else -pct * r[0] / 100
                e.setBandLevel(i.toShort(), lv.toShort())
            }
        } catch (_: Exception) {}
    }

    private fun syncBass() {
        val b = bassFx ?: return
        try {
            if (b.strengthSupported) b.setStrength(bassLevel.toShort())
            b.enabled = fxOn && bassLevel > 0
        } catch (_: Exception) {}
    }

    fun setFx(on: Boolean) { prefs.edit().putBoolean("fx", on).apply(); syncEq(); syncBass() }
    fun setEqBand(i: Int, pct: Int) { prefs.edit().putInt("eq$i", pct).apply(); syncEq() }
    fun setBass(v: Int) { prefs.edit().putInt("bass", v).apply(); syncBass() }

    // ---------- внутреннее ----------

    private fun load(autoplay: Boolean, seekMs: Int = 0) {
        try { player?.release() } catch (_: Exception) {}
        player = null
        releaseFx()
        val t = current ?: run { updateAll(); return }
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(attrs)
            mp.setDataSource(this, t.uri)
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.prepare()
            applyFx(mp.audioSessionId)
            mp.isLooping = repeat == 2
            mp.setOnCompletionListener { onComplete() }
            if (seekMs > 0) mp.seekTo(seekMs)
        } catch (_: Exception) {
            mp.release()
            Toast.makeText(this, "Не удалось открыть: ${t.title}", Toast.LENGTH_SHORT).show()
            updateAll()
            return
        }
        player = mp
        prefs.edit().putLong("lastId", t.id).putInt("lastPos", seekMs).apply()
        updateMetadata()
        if (autoplay) play() else updateAll()
    }

    private fun onComplete() {
        if (index + 1 < queue.size) { index++; load(true) }
        else if (repeat == 1 && queue.isNotEmpty()) { index = 0; load(true) }
        else { seekTo(0); pause() }
    }

    private fun savePosition() {
        val t = current ?: return
        prefs.edit().putLong("lastId", t.id).putInt("lastPos", position).apply()
    }

    private fun requestFocus(): Boolean {
        val am = getSystemService(AudioManager::class.java)
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs).setOnAudioFocusChangeListener(focusListener).build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun updateAll() {
        updateSession()
        updateNotification()
        onChange?.invoke()
    }

    private fun updateMetadata() {
        val t = current ?: return
        session.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs).build()
        )
    }

    private fun updateSession() {
        val st = if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
        session.setPlaybackState(
            PlaybackState.Builder().setActions(actions).setState(st, position.toLong(), 1f).build()
        )
    }

    private fun startFg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIF_ID, n)
        fg = true
    }

    private fun updateNotification() {
        if (current == null) {
            if (fg) { stopForeground(STOP_FOREGROUND_REMOVE); fg = false }
            return
        }
        val n = buildNotification()
        if (isPlaying) startFg(n)
        else {
            if (fg) { stopForeground(STOP_FOREGROUND_DETACH); fg = false }
            nm.notify(NOTIF_ID, n)
        }
    }

    private fun action(icon: Int, title: String, a: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, a.hashCode(), Intent(this, PlayerService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build()
    }

    private fun buildNotification(): Notification {
        val t = current
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(t?.title ?: "ZXCMUSS")
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(R.drawable.ic_prev, "Назад", ACTION_PREV))
            .addAction(action(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play, "Пауза/Играть", ACTION_TOGGLE))
            .addAction(action(R.drawable.ic_next, "Вперёд", ACTION_NEXT))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }
}
