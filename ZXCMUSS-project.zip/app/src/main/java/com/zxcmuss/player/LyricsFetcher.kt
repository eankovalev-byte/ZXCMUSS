package com.zxcmuss.player

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.abs

/** Ищет синхронные тексты в открытой базе lrclib.net и кэширует на устройстве. */
object LyricsFetcher {
    private val pool = Executors.newSingleThreadExecutor { r -> Thread(r, "zx-lyrics") }
    @Volatile private var wanted = -1L

    private fun dir(ctx: Context) = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    /** Текст из кэша; "" — искали и не нашли (недавно); null — ещё не искали. */
    fun cached(ctx: Context, t: Track): String? {
        return try {
            val f = File(dir(ctx), "${t.id}.lrc")
            if (f.exists()) return f.readText()
            val none = File(dir(ctx), "${t.id}.none")
            if (none.exists() && System.currentTimeMillis() - none.lastModified() < 3L * 24 * 3600 * 1000) "" else null
        } catch (_: Exception) {
            null
        }
    }

    fun fetch(ctx: Context, t: Track, cb: (String?) -> Unit) {
        wanted = t.id
        val app = ctx.applicationContext
        pool.execute {
            if (wanted != t.id) return@execute
            val queries = ArrayList<String>()
            val title = t.title
            if (t.artist != "Неизвестный исполнитель") queries.add("${t.artist} $title")
            queries.add(title)
            var netOk = false
            var found: String? = null
            for (q in queries) {
                try {
                    val res = search(q, t.durationMs / 1000.0)
                    netOk = true
                    if (res != null) { found = res; break }
                } catch (_: Exception) {}
            }
            try {
                if (found != null) File(dir(app), "${t.id}.lrc").writeText(found)
                else if (netOk) File(dir(app), "${t.id}.none").writeText("0")
            } catch (_: Exception) {}
            cb(found)
        }
    }

    private fun search(q: String, durSec: Double): String? {
        val url = URL("https://lrclib.net/api/search?q=" + URLEncoder.encode(q, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "ZXCMUSS/2.0")
        try {
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            var best: String? = null
            var bestDiff = 1e9
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = o.optString("syncedLyrics", "")
                if (s.isBlank() || s == "null") continue
                val d = o.optDouble("duration", -1.0)
                val diff = if (d > 0) abs(d - durSec) else 4.0
                if (diff < bestDiff) { bestDiff = diff; best = s }
            }
            return if (best != null && bestDiff <= 6.0) best else null
        } finally {
            c.disconnect()
        }
    }
}
