package com.zxcmuss.player

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.abs

/** Ищет синхронные тексты в открытой базе lrclib.net и кэширует на устройстве. */
object LyricsFetcher {
    private val pool = Executors.newSingleThreadExecutor { r -> Thread(r, "zx-lyrics") }
    @Volatile private var wanted = -1L

    private fun dir(ctx: Context) = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    /** Текст из кэша; "" — искали и не нашли (недавно); null — ещё не искали. */
    fun cached(ctx: Context, t: Track): String? {
        return try {
            val f = File(dir(ctx), "${t.id}.lrc")
            if (f.exists()) return f.readText()
            val none = File(dir(ctx), "${t.id}.none")
            if (none.exists() && System.currentTimeMillis() - none.lastModified() < 3L * 24 * 3600 * 1000) "" else null
        } catch (_: Exception) {
            null
        }
    }

    /** Свой текст: готовый LRC или обычные строки (тогда расставим по времени равномерно). */
    fun saveOwn(ctx: Context, t: Track, text: String) {
        val body = text.trim()
        val out = if (Regex("\\[\\d+:\\d+").containsMatchIn(body)) body else {
            val lines = body.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val dur = t.durationMs.coerceAtLeast(30000L)
            val sb = StringBuilder()
            lines.forEachIndexed { i, l ->
                val ms = 4000L + (dur - 8000L) * i / lines.size.coerceAtLeast(1)
                sb.append(String.format("[%02d:%02d.%02d]%s\n", ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10, l))
            }
            sb.toString()
        }
        try {
            File(dir(ctx), "${t.id}.none").delete()
            File(dir(ctx), "${t.id}.lrc").writeText(out)
        } catch (_: Exception) {}
    }

    fun deleteFor(ctx: Context, id: Long) {
        try {
            File(dir(ctx), "$id.lrc").delete()
            File(dir(ctx), "$id.none").writeText("0")
        } catch (_: Exception) {}
    }

    private val rxBr = Regex("[\\(\\[][^\\)\\]]*[\\)\\]]")
    private val rxJunk = Regex("(?i)\\b(feat|ft|prod|official|lyrics?|audio|video|clip|hd|hq|remastered|remaster|премьера|клип)\\b.*$")
    private val rxNum = Regex("^\\s*\\d{1,3}\\s*[.\\-_)]\\s*")
    private val rxTok = Regex("[\\p{L}\\p{N}]+")

    private fun tokens(s: String): Set<String> = rxTok.findAll(s.lowercase()).map { it.value }.toSet()

    /** Название без приписок: скобки, feat., «official video», номер в начале. */
    private fun clean(s: String): String {
        var x = rxBr.replace(s, " ")
        x = rxNum.replace(x, "")
        x = rxJunk.replace(x, " ")
        return x.replace('_', ' ').replace(Regex("\\s+"), " ").trim().trim('-', ' ')
    }

    fun fetch(ctx: Context, t: Track, cb: (String?) -> Unit) {
        wanted = t.id
        val app = ctx.applicationContext
        pool.execute {
            if (wanted != t.id) return@execute
            val known = t.artist != "Неизвестный исполнитель"
            val queries = LinkedHashSet<String>()
            val titles = LinkedHashSet<String>()
            titles.add(clean(t.title)); titles.add(t.title)
            // «Исполнитель - Название» в одном названии
            val dash = clean(t.title).split(" - ", " – ", " — ")
            if (dash.size == 2) { queries.add(dash[0] + " " + dash[1]); titles.add(dash[1]) }
            for (ti in titles) {
                if (ti.isBlank()) continue
                if (known) queries.add("${t.artist} $ti")
                queries.add(ti)
                // другая раскладка и транслит: «ghbdtn» → «привет», «privet» ↔ «привет»
                for (v in WebMusic.variants(ti)) {
                    if (known) queries.add("${t.artist} $v")
                    queries.add(v)
                }
            }
            var netOk = false
            var found: String? = null
            var n = 0
            for (q in queries) {
                if (wanted != t.id || n++ >= 9) break
                try {
                    val res = search(q, t.durationMs / 1000.0)
                    netOk = true
                    if (res != null) { found = res; break }
                } catch (_: Exception) {}
            }
            try {
                if (found != null) File(dir(app), "${t.id}.lrc").writeText(found)
                else if (netOk) File(dir(app), "${t.id}.none").writeText("0")
            } catch (_: Exception) {}
            cb(found)
        }
    }

    private fun search(q: String, durSec: Double): String? {
        val url = URL("https://lrclib.net/api/search?q=" + URLEncoder.encode(q, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "ZXCMUSS/3.3")
        try {
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            val want = tokens(q)
            var best: String? = null
            var bestScore = -1.0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = o.optString("syncedLyrics", "")
                if (s.isBlank() || s == "null") continue
                val have = tokens(o.optString("trackName", "") + " " + o.optString("artistName", ""))
                val cov = if (want.isEmpty()) 0.0 else want.intersect(have).size.toDouble() / want.size
                if (cov < 0.6) continue
                val d = o.optDouble("duration", -1.0)
                val diff = if (d > 0) abs(d - durSec) else 5.0
                if (diff > 12.0 && !(cov >= 0.99 && diff <= 25.0)) continue
                val score = cov * 10.0 - diff * 0.3
                if (score > bestScore) { bestScore = score; best = s }
            }
            return best
        } finally {
            c.disconnect()
        }
    }
}
