package com.zxcmuss.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val dateAdded: Long,
    val path: String?,
    val year: String = ""
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

/** Чистит «мусорные» названия файлов: подчёркивания, названия сайтов в скобках. */
object TrackText {
    private val bracketSite = Regex("[\\(\\[]\\s*[^\\)\\]]*\\.(com|ru|net|org|me|fm|su|io|cc|biz)[^\\)\\]]*[\\)\\]]", RegexOption.IGNORE_CASE)
    private val siteWord = Regex("\\b[\\w-]+\\.(com|ru|net|org|me|fm|su|io|cc|biz)\\b", RegexOption.IGNORE_CASE)
    private val spaces = Regex("\\s+")

    fun cleanTitle(raw: String): String {
        var s = raw.replace('_', ' ')
        s = bracketSite.replace(s, " ")
        s = siteWord.replace(s, " ")
        s = spaces.replace(s, " ").trim().trim('-', ' ')
        return if (s.isEmpty()) raw else s
    }
}

object Library {
    /** Читает всю музыку устройства из MediaStore (быстро, без ручного обхода папок). */
    fun load(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DATA
        )
        val sel = "${MediaStore.Audio.Media.IS_RINGTONE}=0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION}=0 " +
            "AND ${MediaStore.Audio.Media.IS_ALARM}=0 AND ${MediaStore.Audio.Media.DURATION}>=20000"
        try {
            ctx.contentResolver.query(m, proj, sel, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)
                    out.add(
                        Edits.applyTo(ctx, Track(
                            id = c.getLong(0),
                            title = TrackText.cleanTitle(c.getString(1) ?: "Без названия"),
                            artist = if (artist == null || artist == "<unknown>") "Неизвестный исполнитель" else artist,
                            album = c.getString(3) ?: "",
                            durationMs = c.getLong(4),
                            dateAdded = c.getLong(5),
                            path = c.getString(6)
                        ))
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}
