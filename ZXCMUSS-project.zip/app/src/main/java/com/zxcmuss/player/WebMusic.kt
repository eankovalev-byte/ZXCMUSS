package com.zxcmuss.player

import android.content.ContentUris
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class JamendoKeyException : Exception("jamendo key")

/**
 * Поиск и скачивание ТОЛЬКО свободной музыки:
 * Internet Archive (общественное достояние / Creative Commons) и Jamendo (Creative Commons).
 */
object WebMusic {
    class Item(val source: Int, val id: String, val title: String, val artist: String, val durationSec: Int, val url: String?)
    class FileItem(val name: String, val title: String, val durationSec: Int, val url: String)

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun encPath(s: String): String = enc(s).replace("+", "%20")

    private fun open(url: String): HttpURLConnection {
        var u = url
        for (hop in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "ZXCMUSS/3.0")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return c
                u = URL(URL(u), loc).toString()
                c.disconnect()
                continue
            }
            return c
        }
        throw IOException("too many redirects")
    }

    private fun getText(url: String): String {
        val c = open(url)
        try {
            if (c.responseCode != 200) throw IOException("http " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun str(o: Any?): String = when (o) {
        is JSONArray -> o.optString(0, "")
        is String -> o
        else -> ""
    }

    fun searchArchive(q: String): List<Item> {
        val clean = q.replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim()
        if (clean.isEmpty()) return emptyList()
        val query = "($clean) AND mediatype:audio"
        val url = "https://archive.org/advancedsearch.php?q=" + enc(query) +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&rows=25&page=1&output=json&sort%5B%5D=downloads+desc"
        val docs = JSONObject(getText(url)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Item>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier", "")
            if (id.isEmpty()) continue
            val title = str(d.opt("title")).ifEmpty { id }
            out.add(Item(0, id, title, str(d.opt("creator")), 0, null))
        }
        return out
    }

    private fun parseLen(s: String): Int {
        if (s.isBlank()) return 0
        return try { s.split(':').fold(0.0) { a, x -> a * 60 + x.toDouble() }.toInt() } catch (_: Exception) { 0 }
    }

    fun archiveFiles(id: String): List<FileItem> {
        val root = JSONObject(getText("https://archive.org/metadata/" + encPath(id)))
        val files = root.optJSONArray("files") ?: return emptyList()
        val seen = HashSet<String>()
        val out = ArrayList<FileItem>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name", "")
            if (!name.lowercase().endsWith(".mp3")) continue
            val title = f.optString("title", "").ifEmpty { name.substringAfterLast('/').substringBeforeLast('.') }
            if (!seen.add(title.lowercase())) continue
            val url = "https://archive.org/download/" + encPath(id) + "/" + name.split("/").joinToString("/") { encPath(it) }
            out.add(FileItem(name, title, parseLen(f.optString("length", "")), url))
            if (out.size >= 60) break
        }
        return out
    }

    fun searchJamendo(q: String, key: String): List<Item> {
        val url = "https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(key) +
            "&format=json&limit=25&audiodlformat=mp32&search=" + enc(q)
        val root = JSONObject(getText(url))
        val headers = root.optJSONObject("headers")
        if (headers != null && headers.optString("status", "") == "failed") throw JamendoKeyException()
        val res = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Item>()
        for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            val dl = o.optString("audiodownload", "")
            if (dl.isBlank() || !o.optBoolean("audiodownload_allowed", false)) continue
            out.add(Item(1, o.optString("id", ""), o.optString("name", ""), o.optString("artist_name", ""), o.optInt("duration", 0), dl))
        }
        return out
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), "_").replace(Regex("\\s+"), " ").trim().take(120)

    /** Скачивает в Music/ZXCMUSS, добавляет в «Загрузки». Возвращает id трека или null. */
    fun download(ctx: Context, url: String, title: String, artist: String, onProgress: (Int) -> Unit): Long? {
        var conn: HttpURLConnection? = null
        var uri: android.net.Uri? = null
        try {
            val c = open(url)
            conn = c
            if (c.responseCode != 200) return null
            val total = c.contentLengthLong
            val ct = (c.contentType ?: "").lowercase()
            val low = url.lowercase()
            val ext: String
            val mime: String
            if (low.contains(".ogg") || ct.contains("ogg")) { ext = "ogg"; mime = "audio/ogg" }
            else if (low.contains(".flac") || ct.contains("flac")) { ext = "flac"; mime = "audio/flac" }
            else { ext = "mp3"; mime = "audio/mpeg" }
            val base = if (artist.isBlank()) title else "$artist - $title"
            val u = Importer.createAudio(ctx, safeName(base) + "." + ext, mime) ?: return null
            uri = u
            ctx.contentResolver.openOutputStream(u)?.use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            } ?: return null
            Importer.publish(ctx, u)
            val id = ContentUris.parseId(u)
            Importer.markDownloaded(ctx, id)
            return id
        } catch (e: Exception) {
            try { uri?.let { ctx.contentResolver.delete(it, null, null) } } catch (_: Exception) {}
            return null
        } finally {
            conn?.disconnect()
        }
    }
}
