package com.zxcmuss.player

import android.content.ContentUris
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class JamendoKeyException : Exception("jamendo key")

/**
 * Поиск и скачивание ТОЛЬКО свободной музыки:
 * Internet Archive (общественное достояние / Creative Commons) и Jamendo (Creative Commons).
 */
object WebMusic {
    class Item(val source: Int, val id: String, val title: String, val artist: String, val durationSec: Int, val url: String?)
    class FileItem(val name: String, val title: String, val durationSec: Int, val url: String)

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun encPath(s: String): String = enc(s).replace("+", "%20")

    private fun open(url: String): HttpURLConnection {
        var u = url
        for (hop in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "ZXCMUSS/3.1")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return c
                u = URL(URL(u), loc).toString()
                c.disconnect()
                continue
            }
            return c
        }
        throw IOException("too many redirects")
    }

    private fun getText(url: String): String {
        val c = open(url)
        try {
            if (c.responseCode != 200) throw IOException("http " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun str(o: Any?): String = when (o) {
        is JSONArray -> o.optString(0, "")
        is String -> o
        else -> ""
    }

    private fun archiveDocs(query: String, sort: String): List<Item> {
        val url = "https://archive.org/advancedsearch.php?q=" + enc(query) +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&rows=30&page=1&output=json&sort%5B%5D=" + enc(sort)
        val docs = JSONObject(getText(url)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Item>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier", "")
            if (id.isEmpty()) continue
            val title = str(d.opt("title")).ifEmpty { id }
            out.add(Item(0, id, title, str(d.opt("creator")), 0, null))
        }
        return out
    }

    fun searchArchive(q: String): List<Item> {
        val toks = q.replace(Regex("[^\\p{L}\\p{N} ]"), " ").split(' ').filter { it.isNotBlank() }
        if (toks.isEmpty()) return emptyList()
        fun part(t: String, fuzzy: Boolean) =
            "(title:($t OR $t*" + (if (fuzzy && t.length >= 4) " OR $t~" else "") + ") OR creator:($t OR $t*" +
                (if (fuzzy && t.length >= 4) " OR $t~" else "") + "))"
        val strict = toks.joinToString(" AND ") { part(it, true) }
        var r = archiveDocs("($strict) AND mediatype:audio", "downloads desc")
        if (r.isEmpty() && toks.size > 1) {
            val loose = toks.joinToString(" OR ") { part(it, true) }
            r = archiveDocs("($loose) AND mediatype:audio", "downloads desc")
        }
        return r
    }

    fun popularArchive(g: Genre): List<Item> {
        val sub = if (g.archive.isBlank()) "" else " AND subject:(${g.archive})"
        return archiveDocs("mediatype:audio AND format:MP3$sub", "week desc")
    }

    // ---------- Audius: свежая независимая музыка (хип-хоп, трэп, электроника…) ----------

    private fun audiusItems(url: String): List<Item> {
        val arr = JSONObject(getText(url)).optJSONArray("data") ?: return emptyList()
        val out = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id", "")
            if (id.isEmpty() || !o.optBoolean("is_streamable", true)) continue
            val dl = o.optBoolean("is_downloadable", o.optBoolean("downloadable", false))
            val acc = o.optJSONObject("access")
            val ok = dl && (acc == null || acc.optBoolean("download", true))
            val user = o.optJSONObject("user")?.optString("name", "") ?: ""
            out.add(Item(2, id, o.optString("title", ""), user, o.optInt("duration", 0),
                if (ok) "https://api.audius.co/v1/tracks/" + id + "/stream?app_name=ZXCMUSS" else null))
        }
        return out
    }

    fun searchAudius(q: String): List<Item> =
        audiusItems("https://api.audius.co/v1/tracks/search?app_name=ZXCMUSS&limit=30&query=" + enc(q))

    fun popularAudius(g: Genre): List<Item> =
        audiusItems("https://api.audius.co/v1/tracks/trending?app_name=ZXCMUSS&limit=30&time=week" +
            (if (g.audius.isBlank()) "" else "&genre=" + enc(g.audius)))

    // ---------- умный разбор запроса ----------

    class Genre(val label: String, val audius: String, val jamendo: String, val archive: String)

    val genres = listOf(
        Genre("Популярное", "", "", ""),
        Genre("Хип-хоп", "Hip-Hop/Rap", "hiphop", "hip hop"),
        Genre("Trap", "Trap", "trap", "trap"),
        Genre("Электроника", "Electronic", "electronic", "electronic"),
        Genre("Рок", "Rock", "rock", "rock"),
        Genre("Поп", "Pop", "pop", "pop"),
        Genre("Lo-Fi", "Lo-Fi", "lofi", "lofi"),
        Genre("Hyperpop", "Hyperpop", "", "hyperpop"),
        Genre("House", "House", "house", "house"),
        Genre("Drum & Bass", "Drum & Bass", "drumnbass", "drum and bass")
    )

    private const val EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,./"
    private const val RU = "йцукенгшщзхъфывапролджэячсмитьбю."
    private val TR = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z",
        'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sch",
        'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya"
    )

    private fun swapLayout(q: String): String {
        val low = q.lowercase()
        val toRu = low.any { it in 'a'..'z' }
        return low.map { ch ->
            if (toRu) { val i = EN.indexOf(ch); if (i >= 0) RU[i] else ch }
            else { val i = RU.indexOf(ch); if (i >= 0) EN[i] else ch }
        }.joinToString("")
    }

    private fun translit(q: String): String =
        q.lowercase().map { TR[it] ?: it.toString() }.joinToString("")

    /** Варианты запроса: как набрано, не в той раскладке, транслит, без последнего слова. */
    private fun variants(q: String): List<String> {
        val base = q.trim().replace(Regex("\\s+"), " ")
        val list = ArrayList<String>()
        list.add(base)
        list.add(swapLayout(base))
        if (base.any { it in 'а'..'я' || it == 'ё' || it in 'А'..'Я' }) list.add(translit(base))
        val w = base.split(' ')
        if (w.size > 1) list.add(w.dropLast(1).joinToString(" "))
        return list.filter { it.isNotBlank() }.distinct()
    }

    fun search(source: Int, q: String, genre: Int, key: String): List<Item> {
        val g = genres[genre.coerceIn(0, genres.size - 1)]
        if (q.isBlank()) return when (source) {
            0 -> popularArchive(g)
            1 -> popularJamendo(g, key)
            else -> popularAudius(g)
        }
        for (v in variants(q)) {
            val r = when (source) {
                0 -> searchArchive(v)
                1 -> searchJamendo(v, key)
                else -> searchAudius(v)
            }
            if (r.isNotEmpty()) return r
        }
        return emptyList()
    }

    private fun parseLen(s: String): Int {
        if (s.isBlank()) return 0
        return try { s.split(':').fold(0.0) { a, x -> a * 60 + x.toDouble() }.toInt() } catch (_: Exception) { 0 }
    }

    fun archiveFiles(id: String): List<FileItem> {
        val root = JSONObject(getText("https://archive.org/metadata/" + encPath(id)))
        val files = root.optJSONArray("files") ?: return emptyList()
        val seen = HashSet<String>()
        val out = ArrayList<FileItem>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name", "")
            if (!name.lowercase().endsWith(".mp3")) continue
            val title = f.optString("title", "").ifEmpty { name.substringAfterLast('/').substringBeforeLast('.') }
            if (!seen.add(title.lowercase())) continue
            val url = "https://archive.org/download/" + encPath(id) + "/" + name.split("/").joinToString("/") { encPath(it) }
            out.add(FileItem(name, title, parseLen(f.optString("length", "")), url))
            if (out.size >= 60) break
        }
        return out
    }

    private fun jamendoItems(url: String): List<Item> {
        val root = JSONObject(getText(url))
        val headers = root.optJSONObject("headers")
        if (headers != null && headers.optString("status", "") == "failed") throw JamendoKeyException()
        val res = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Item>()
        for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            val dl = o.optString("audiodownload", "")
            if (dl.isBlank() || !o.optBoolean("audiodownload_allowed", false)) continue
            out.add(Item(1, o.optString("id", ""), o.optString("name", ""), o.optString("artist_name", ""), o.optInt("duration", 0), dl))
        }
        return out
    }

    fun searchJamendo(q: String, key: String): List<Item> =
        jamendoItems("https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(key) +
            "&format=json&limit=30&audiodlformat=mp32&search=" + enc(q))

    fun popularJamendo(g: Genre, key: String): List<Item> =
        jamendoItems("https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(key) +
            "&format=json&limit=30&audiodlformat=mp32&order=popularity_week" +
            (if (g.jamendo.isBlank()) "" else "&tags=" + enc(g.jamendo)))

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), "_").replace(Regex("\\s+"), " ").trim().take(120)

    /** Скачивает в Music/ZXCMUSS, добавляет в «Загрузки». Возвращает id трека или null. */
    fun download(ctx: Context, url: String, title: String, artist: String, onProgress: (Int) -> Unit): Long? {
        var conn: HttpURLConnection? = null
        var uri: android.net.Uri? = null
        try {
            val c = open(url)
            conn = c
            if (c.responseCode != 200) return null
            val total = c.contentLengthLong
            val ct = (c.contentType ?: "").lowercase()
            val low = url.lowercase()
            val ext: String
            val mime: String
            if (low.contains(".ogg") || ct.contains("ogg")) { ext = "ogg"; mime = "audio/ogg" }
            else if (low.contains(".flac") || ct.contains("flac")) { ext = "flac"; mime = "audio/flac" }
            else { ext = "mp3"; mime = "audio/mpeg" }
            val base = if (artist.isBlank()) title else "$artist - $title"
            val u = Importer.createAudio(ctx, safeName(base) + "." + ext, mime) ?: return null
            uri = u
            ctx.contentResolver.openOutputStream(u)?.use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            } ?: return null
            Importer.publish(ctx, u)
            val id = ContentUris.parseId(u)
            Importer.markDownloaded(ctx, id)
            return id
        } catch (e: Exception) {
            try { uri?.let { ctx.contentResolver.delete(it, null, null) } } catch (_: Exception) {}
            return null
        } finally {
            conn?.disconnect()
        }
    }
}
