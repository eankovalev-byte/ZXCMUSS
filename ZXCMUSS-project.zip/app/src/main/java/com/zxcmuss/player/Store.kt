package com.zxcmuss.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Правки треков (название, исполнитель, альбом, год, обложка). Хранятся в приложении, файлы музыки не трогаем. */
object Edits {
    private var cache: JSONObject? = null

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("zx", Context.MODE_PRIVATE)

    @Synchronized
    private fun all(ctx: Context): JSONObject {
        var c = cache
        if (c == null) {
            c = try { JSONObject(prefs(ctx).getString("edits", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            cache = c
        }
        return c!!
    }

    @Synchronized
    fun save(ctx: Context, id: Long, title: String, artist: String, album: String, year: String) {
        val o = JSONObject()
        o.put("title", title); o.put("artist", artist); o.put("album", album); o.put("year", year)
        val a = all(ctx)
        a.put(id.toString(), o)
        prefs(ctx).edit().putString("edits", a.toString()).apply()
    }

    @Synchronized
    fun reset(ctx: Context, id: Long) {
        val a = all(ctx)
        a.remove(id.toString())
        prefs(ctx).edit().putString("edits", a.toString()).apply()
        try { coverFile(ctx, id).delete() } catch (_: Exception) {}
    }

    fun coverFile(ctx: Context, id: Long): File =
        File(File(ctx.applicationContext.filesDir, "covers").apply { mkdirs() }, "$id.jpg")

    fun applyTo(ctx: Context, t: Track): Track {
        val e = all(ctx).optJSONObject(t.id.toString()) ?: return t
        val title = e.optString("title", "")
        val artist = e.optString("artist", "")
        val album = e.optString("album", "")
        return t.copy(
            title = if (title.isBlank()) t.title else title,
            artist = if (artist.isBlank()) t.artist else artist,
            album = if (album.isBlank()) t.album else album,
            year = e.optString("year", "")
        )
    }
}

/** Обложки: сначала своя (из редактора), потом встроенная в файл. */
object Covers {
    private val mem = android.util.LruCache<Long, Bitmap>(6)

    fun decode(bytes: ByteArray, max: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (_: Throwable) { null }
    }

    /** Читает картинку по Uri, уменьшает и сохраняет JPEG в файл. */
    fun importImage(ctx: Context, uri: Uri, out: File, max: Int): Boolean {
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
            val bmp = decode(bytes, max) ?: return false
            val w = bmp.width; val h = bmp.height
            val k = max.toFloat() / maxOf(w, h)
            val fin = if (k < 1f) Bitmap.createScaledBitmap(bmp, (w * k).toInt().coerceAtLeast(1), (h * k).toInt().coerceAtLeast(1), true) else bmp
            out.parentFile?.mkdirs()
            out.outputStream().use { fin.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            mem.evictAll()
            true
        } catch (_: Throwable) { false }
    }

    fun load(ctx: Context, t: Track): Bitmap? {
        val own = Edits.coverFile(ctx, t.id)
        val key = t.id
        if (!own.exists()) {
            mem.get(key)?.let { return it }
        }
        var bmp: Bitmap? = null
        try {
            if (own.exists()) bmp = BitmapFactory.decodeFile(own.path)
        } catch (_: Throwable) {}
        if (bmp == null) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, t.uri)
                val pic = r.embeddedPicture
                if (pic != null) bmp = decode(pic, 700)
            } catch (_: Throwable) {
            } finally {
                try { r.release() } catch (_: Throwable) {}
            }
        }
        if (bmp != null && !own.exists()) mem.put(key, bmp)
        return bmp
    }
}

/** Шрифты: стандартный или скачанный из интернета (Google Fonts и любые прямые ссылки на .ttf/.otf). */
object Fnt {
    class F(val name: String, val key: String, val url: String?)

    private const val GF = "https://github.com/google/fonts/raw/main/ofl/"

    val list = listOf(
        F("Стандартный", "", null),
        F("Minecraft (пиксельный)", "pixel.ttf", GF + "pressstart2p/PressStart2P-Regular.ttf"),
        F("Толстый (Russo One)", "russo.ttf", GF + "russoone/RussoOne-Regular.ttf"),
        F("Жирный широкий (Rubik Mono)", "mono.ttf", GF + "rubikmonoone/RubikMonoOne-Regular.ttf"),
        F("Рукописный (Marck Script)", "marck.ttf", GF + "marckscript/MarckScript-Regular.ttf"),
        F("Кисть (Pacifico)", "pacifico.ttf", GF + "pacifico/Pacifico-Regular.ttf"),
        F("Афиша (Lobster)", "lobster.ttf", GF + "lobster/Lobster-Regular.ttf")
    )

    @Volatile var current: Typeface? = null

    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, "fonts").apply { mkdirs() }

    fun init(ctx: Context) {
        val k = ctx.getSharedPreferences("zx", Context.MODE_PRIVATE).getString("fontFile", "") ?: ""
        current = if (k.isBlank()) null else try {
            val f = File(dir(ctx), k)
            if (f.exists()) Typeface.createFromFile(f) else null
        } catch (_: Throwable) { null }
    }

    fun face(bold: Boolean): Typeface {
        val c = current
        val st = if (bold) Typeface.BOLD else Typeface.NORMAL
        return if (c != null) Typeface.create(c, st) else Typeface.create("sans-serif-medium", st)
    }

    /** Скачивает шрифт (вызывать не в главном потоке). true, если шрифт открылся. */
    fun download(ctx: Context, url: String, key: String): Boolean {
        return try {
            val f = File(dir(ctx), key)
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 12000
            c.readTimeout = 20000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "ZXCMUSS/3.3")
            if (c.responseCode != 200) { c.disconnect(); return false }
            val tmp = File(dir(ctx), "$key.part")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            c.disconnect()
            Typeface.createFromFile(tmp)
            if (f.exists()) f.delete()
            tmp.renameTo(f)
        } catch (_: Throwable) { false }
    }
}

/** Мини-клиент для сетевых запросов ИИ. */
object Http {
    fun postJson(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw java.io.IOException("HTTP $code: " + text.take(200))
            return text
        } finally {
            c.disconnect()
        }
    }
}

/** Любой ИИ: OpenAI-совместимый API (OpenAI, OpenRouter, Groq, Ollama, Gemini…) или Anthropic. Ключ хранится только на устройстве. */
object Ai {
    fun configured(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences("zx", Context.MODE_PRIVATE)
        return !(p.getString("aiUrl", "") ?: "").isBlank() && !(p.getString("aiModel", "") ?: "").isBlank()
    }

    fun ask(ctx: Context, prompt: String): String {
        val p = ctx.getSharedPreferences("zx", Context.MODE_PRIVATE)
        val base = (p.getString("aiUrl", "") ?: "").trim().trimEnd('/')
        val model = (p.getString("aiModel", "") ?: "").trim()
        val key = (p.getString("aiKey", "") ?: "").trim()
        if (base.isEmpty() || model.isEmpty()) throw java.io.IOException("ИИ не настроен")
        if (base.contains("anthropic.com")) {
            val msg = JSONObject().put("role", "user").put("content", prompt)
            val body = JSONObject().put("model", model).put("max_tokens", 1500)
                .put("messages", JSONArray().put(msg)).toString()
            val url = if (base.endsWith("/v1/messages")) base else base.removeSuffix("/v1") + "/v1/messages"
            val res = Http.postJson(url, mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
            val arr = JSONObject(res).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text", ""))
            return sb.toString()
        }
        val msg = JSONObject().put("role", "user").put("content", prompt)
        val body = JSONObject().put("model", model).put("temperature", 0.7)
            .put("messages", JSONArray().put(msg)).toString()
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val hdr = HashMap<String, String>()
        if (key.isNotEmpty()) hdr["Authorization"] = "Bearer $key"
        val res = Http.postJson(url, hdr, body)
        return JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
    }

    /** Просит у ИИ похожие треки. Возвращает строки «Исполнитель - Название». */
    fun recommend(ctx: Context, liked: List<String>, count: Int): List<String> {
        val prompt = "Ты опытный музыкальный куратор. Вот треки, которые слушает человек:\n" +
            liked.joinToString("\n") + "\n\n" +
            "Подбери $count реально существующих треков, максимально похожих по жанру, настроению и звучанию. " +
            "Это должны быть настоящие треки настоящих исполнителей, без случайных и без тех, что уже в списке. " +
            "Ответь ТОЛЬКО JSON-массивом строк вида \"Исполнитель - Название\", без пояснений."
        val text = ask(ctx, prompt)
        val a = text.indexOf('[')
        val b = text.lastIndexOf(']')
        if (a < 0 || b <= a) return emptyList()
        val arr = JSONArray(text.substring(a, b + 1))
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) out.add(s)
        }
        return out
    }
}

/** Миксы по вашей музыке: ищем в свободных источниках только то, что реально подходит. */
object Mix {
    private fun tokens(s: String): Set<String> =
        Regex("[\\p{L}\\p{N}]+").findAll(s.lowercase()).map { it.value }.toSet()

    private fun cover(want: Set<String>, have: Set<String>): Float =
        if (want.isEmpty()) 0f else want.intersect(have).size.toFloat() / want.size

    /** Находит в Audius скачиваемые версии для строк «Исполнитель - Название». */
    fun resolve(entries: List<String>): List<WebMusic.Item> {
        val pool = Executors.newFixedThreadPool(5)
        try {
            val tasks = entries.map { e ->
                Callable<WebMusic.Item?> {
                    try {
                        val want = tokens(e)
                        var best: WebMusic.Item? = null
                        var bs = 0f
                        for (it in WebMusic.searchAudius(e)) {
                            if (it.url == null) continue
                            val sc = cover(want, tokens(it.artist + " " + it.title))
                            if (sc > bs) { bs = sc; best = it }
                        }
                        if (bs >= 0.6f) best else null
                    } catch (_: Exception) { null }
                }
            }
            val seen = HashSet<String>()
            val out = ArrayList<WebMusic.Item>()
            for (f in pool.invokeAll(tasks)) {
                val it = try { f.get() } catch (_: Exception) { null } ?: continue
                if (seen.add(it.id)) out.add(it)
            }
            return out
        } finally {
            pool.shutdown()
        }
    }

    /** Без ИИ: ещё треки тех исполнителей, которых вы чаще всего слушаете и скачиваете. */
    fun byArtists(artists: List<String>, have: Set<String>): List<WebMusic.Item> {
        val out = ArrayList<WebMusic.Item>()
        val seen = HashSet<String>()
        for (a in artists) {
            val want = tokens(a)
            if (want.isEmpty()) continue
            try {
                var n = 0
                for (it in WebMusic.searchAudius(a)) {
                    if (it.url == null) continue
                    if (cover(want, tokens(it.artist)) < 0.99f) continue
                    if (tokens(it.title).joinToString(" ") in have) continue
                    if (seen.add(it.id)) { out.add(it); n++ }
                    if (n >= 8) break
                }
            } catch (_: Exception) {}
        }
        out.shuffle()
        return out
    }

    fun key(title: String): String = tokens(title).joinToString(" ")
}
