package com.zxcmuss.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val NEON: Int get() = Theme.NEON
    private val DIM: Int get() = Theme.DIM

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var svc: PlayerService? = null
    private var resumed = false
    private var frameN = 0

    private var all: List<Track> = emptyList()
    private var shown: List<Track> = emptyList()
    private var sortMode = 0
    private var tab = 0
    private var favs = HashSet<Long>()
    private var onlineLyrics = true

    private var lrc: List<Lrc.Line> = emptyList()
    private var shownTrackId = -2L
    private var lastLyricKey = -3
    private var lastSec = -1

    // views
    private lateinit var aurora: AuroraView
    private lateinit var fish: FisheyeLayout
    private lateinit var wave: WaveFrame
    private lateinit var titleSmall: TextView
    private lateinit var artistSmall: TextView
    private lateinit var eq: MiniEq
    private lateinit var lyric: TextView
    private lateinit var viz: SpectrumView
    private lateinit var snake: SnakeSeek
    private lateinit var timeL: TextView
    private lateinit var timeR: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var shuffleBtn: ImageButton
    private lateinit var repeatBtn: ImageButton
    private lateinit var heartBtn: ImageButton
    private lateinit var libPanel: LinearLayout
    private lateinit var libCount: TextView
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var emptyBtn: Button
    private lateinit var tabAll: TextView
    private lateinit var tabFav: TextView
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniPlay: ImageButton
    private val adapter = TrackAdapter()
    private lateinit var coverImg: ImageView
    private lateinit var chipArt: TextView
    private lateinit var dlAll: TextView
    private var pendingDelete: Track? = null
    private var editCoverFor = -1L
    private var bgStamp = -1L
    private var fxSig = ""
    private var afterLoad: (() -> Unit)? = null
    private val dlPool = Executors.newFixedThreadPool(2)

    private var dl = HashSet<Long>()
    private var started = false
    private var webSource = 2
    private var webGenre = 0
    private var webLoaded = false
    private val genreChips = ArrayList<TextView>()
    private lateinit var chipAud: TextView
    private var webItems: List<WebMusic.Item> = emptyList()
    private val webProgress = HashMap<String, Int>()
    private val webDone = HashSet<String>()
    private lateinit var webPanel: LinearLayout
    private lateinit var webSearch: EditText
    private lateinit var webStatus: TextView
    private lateinit var webList: ListView
    private lateinit var chipArc: TextView
    private lateinit var chipJam: TextView
    private lateinit var tabDl: TextView
    private val webAdapter = WebAdapter()

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = (b as PlayerService.LocalBinder).service.also { it.onChange = { refresh() } }
            restoreLast()
            refresh()
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            onFrame()
            if (resumed) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("zx", MODE_PRIVATE)
        Theme.select(prefs.getInt("theme", 0))
        Fnt.init(this)
        window.statusBarColor = Theme.BG_TOP
        window.navigationBarColor = Theme.BG_BOTTOM
        window.decorView.systemUiVisibility =
            if (Theme.LIGHT) (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) else 0
        sortMode = prefs.getInt("sort", 0)
        onlineLyrics = prefs.getBoolean("online", true)
        favs = HashSet(prefs.getStringSet("fav", emptySet())!!.mapNotNull { it.toLongOrNull() })
        setContentView(buildUi())
        applyEffects()
        handleSearchIntent(intent)
        Analyzer.onReady = { id, sp -> runOnUiThread { if (id == shownTrackId) viz.spectrum = sp } }
        if (hasAudioPerm()) loadLibrary() else { requestPerms(); showLibrary(true) }
        updateEmpty()
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PlayerService::class.java), conn, Context.BIND_AUTO_CREATE)
        if (started && hasAudioPerm()) loadLibrary()
        started = true
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onPause() {
        resumed = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        super.onPause()
    }

    override fun onStop() {
        svc?.onChange = null
        try { unbindService(conn) } catch (_: Exception) {}
        svc = null
        super.onStop()
    }

    override fun onDestroy() {
        Analyzer.onReady = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webPanel.visibility == View.VISIBLE) showWeb(false)
        else if (libPanel.visibility == View.VISIBLE) showLibrary(false)
        else super.onBackPressed()
    }

    // ---------- разрешения ----------

    private fun audioPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPerm() = checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        prefs.edit().putBoolean("asked", true).apply()
        val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm())
        requestPermissions(p, 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasAudioPerm()) loadLibrary()
        updateEmpty()
    }

    // ---------- медиатека ----------

    private fun loadLibrary() {
        Thread {
            val l = Library.load(this)
            val d = Importer.downloaded(this)
            runOnUiThread {
                all = l; dl = HashSet(d); applyFilter(); restoreLast()
                afterLoad?.let { afterLoad = null; it() }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val base = when (tab) {
            1 -> all.filter { it.id in favs }
            2 -> all.filter { it.id in dl }
            else -> all
        }
        val sorted = when (sortMode) {
            0 -> base.sortedBy { it.title.lowercase() }
            1 -> base.sortedBy { it.artist.lowercase() }
            else -> base.sortedByDescending { it.dateAdded }
        }
        shown = if (q.isEmpty()) sorted else sorted.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        libCount.text = "${shown.size} из ${all.size} треков"
        updateEmpty()
    }

    private fun updateEmpty() {
        if (!::emptyBox.isInitialized) return
        val perm = hasAudioPerm()
        emptyBox.visibility = if (!perm || shown.isEmpty()) View.VISIBLE else View.GONE
        if (!perm) {
            emptyText.text = "ZXCMUSS нужен доступ к музыке на устройстве, чтобы показать ваши треки."
            emptyBtn.text = "Дать доступ"
            emptyBtn.visibility = View.VISIBLE
        } else if (all.isEmpty()) {
            emptyText.text = "Музыка не найдена. Положите mp3 в папку Music или Download и выберите ⋮ → «Обновить библиотеку»."
            emptyBtn.visibility = View.GONE
        } else if (tab == 2 && dl.isEmpty()) {
            emptyText.text = "Здесь будут скачанные и добавленные треки: меню → «Музыка из интернета» или «Поделиться» из Telegram."
            emptyBtn.visibility = View.GONE
        } else if (tab == 1 && favs.isEmpty()) {
            emptyText.text = "Здесь будут треки, отмеченные сердечком."
            emptyBtn.visibility = View.GONE
        } else {
            emptyText.text = "Ничего не найдено"
            emptyBtn.visibility = View.GONE
        }
    }

    private fun restoreLast() {
        val s = svc ?: return
        if (s.queue.isNotEmpty() || all.isEmpty()) return
        val id = prefs.getLong("lastId", -1)
        val src = if (shown.isNotEmpty()) shown else all
        val idx = src.indexOfFirst { it.id == id }
        if (idx >= 0) s.setQueue(src, idx, false, prefs.getInt("lastPos", 0))
    }

    private fun rescan() {
        Toast.makeText(this, "Обновляю библиотеку…", Toast.LENGTH_SHORT).show()
        Thread {
            val exts = setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma")
            val paths = ArrayList<String>()
            for (d in listOf(Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_DOWNLOADS)) {
                try {
                    Environment.getExternalStoragePublicDirectory(d).walkTopDown().maxDepth(5)
                        .filter { it.isFile && it.extension.lowercase() in exts }.forEach { paths.add(it.path) }
                } catch (_: Exception) {}
            }
            if (paths.isNotEmpty()) MediaScannerConnection.scanFile(this, paths.toTypedArray(), null, null)
            handler.postDelayed({ if (hasAudioPerm()) loadLibrary() }, 1500)
        }.start()
    }

    private fun toggleFav(id: Long) {
        if (!favs.remove(id)) favs.add(id)
        prefs.edit().putStringSet("fav", favs.map { it.toString() }.toSet()).apply()
        if (tab == 1) applyFilter() else adapter.notifyDataSetChanged()
        refresh()
    }

    // ---------- UI ----------

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Int) = dp(v.toFloat()).toInt()

    private fun ripple(): Drawable? {
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        val d = a.getDrawable(0); a.recycle(); return d
    }

    private fun iconBtn(res: Int, size: Int, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(res)
        background = ripple()
        scaleType = ImageView.ScaleType.CENTER
        setColorFilter(Theme.TEXT)
        layoutParams = LinearLayout.LayoutParams(dpi(size), dpi(size))
        setOnClickListener { onClick() }
    }

    private fun text(sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = Fnt.face(bold)
        includeFontPadding = false
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        aurora = AuroraView(this)
        root.addView(aurora, ViewGroup.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        fish = FisheyeLayout(this).apply { clipChildren = false }
        root.clipChildren = false
        root.addView(fish, FrameLayout.LayoutParams(-1, -1))
        fish.addView(col, FrameLayout.LayoutParams(-1, -1))

        // верхняя панель
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(20), dpi(8), dpi(8), 0)
        }
        top.addView(text(15f, Theme.TEXT, true).apply { this.text = "ZXCMUSS"; letterSpacing = 0.25f },
            LinearLayout.LayoutParams(0, -2, 1f))
        heartBtn = iconBtn(R.drawable.ic_heart, 48) { svc?.current?.let { toggleFav(it.id) } }
        top.addView(heartBtn)
        top.addView(iconBtn(R.drawable.ic_library, 48) { showLibrary(true) })
        top.addView(iconBtn(R.drawable.ic_more, 48) { showMenu() })
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        coverImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(28f)) }
            }
        }
        val coverBox = FrameLayout(this)
        coverBox.addView(coverImg, FrameLayout.LayoutParams(dpi(210), dpi(210), Gravity.CENTER))
        col.addView(coverBox, LinearLayout.LayoutParams(-1, 0, 1f))

        // карточка из «стекла» с неоновой рамкой
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(22), dpi(18), dpi(22), dpi(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                Theme.CARD
            ).apply {
                cornerRadius = dp(30f)
                setStroke(dpi(1), Theme.EDGE)
            }
        }
        val head = LinearLayout(this)
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleSmall = text(11.5f, Theme.TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        artistSmall = text(10.5f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        names.addView(titleSmall); names.addView(artistSmall)
        eq = MiniEq(this)
        head.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(eq, LinearLayout.LayoutParams(dpi(22), dpi(18)).apply { leftMargin = dpi(8) })
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        lyric = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 27f)
            setTextColor(Theme.LYRIC)
            typeface = Fnt.face(false)
            setLineSpacing(0f, 1.14f)
            minLines = 3; maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            text = "Выберите трек"
        }
        card.addView(lyric, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(16); bottomMargin = dpi(16) })

        viz = SpectrumView(this)
        card.addView(viz, LinearLayout.LayoutParams(-1, dpi(54)))
        snake = SnakeSeek(this).apply {
            onSeek = { f -> svc?.let { it.seekTo((f * it.duration).toInt()) } }
        }
        card.addView(snake, LinearLayout.LayoutParams(-1, dpi(32)))
        val times = LinearLayout(this)
        timeL = text(9.5f, DIM).apply { text = "0:00" }
        timeR = text(9.5f, DIM).apply { text = "-0:00"; gravity = Gravity.END }
        times.addView(timeL, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(timeR, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(times, LinearLayout.LayoutParams(-1, -2))
        wave = WaveFrame(this).apply { clipChildren = false; corner = dp(30f) }
        wave.addView(card, FrameLayout.LayoutParams(-1, -2))
        col.addView(wave, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dpi(14); rightMargin = dpi(14) })

        // кнопки управления
        val ctr = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dpi(28), 0, 0) }
        shuffleBtn = iconBtn(R.drawable.ic_shuffle, 52) { svc?.let { it.setShuffle(!it.shuffle) } }
        val prev = iconBtn(R.drawable.ic_prev, 56) { svc?.prev() }
        playBtn = iconBtn(R.drawable.ic_play, 92) { onPlayPressed() }.apply {
            background = GlassDrawable()
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dpi(31), dpi(31), dpi(31), dpi(31))
            setColorFilter(Theme.TEXT)
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(110).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(android.view.animation.OvershootInterpolator(2.4f)).start()
                }
                false
            }
        }
        val next = iconBtn(R.drawable.ic_next, 56) { svc?.next() }
        repeatBtn = iconBtn(R.drawable.ic_repeat, 52) { svc?.cycleRepeat() }
        for (v in listOf(shuffleBtn, prev, playBtn, next, repeatBtn)) {
            ctr.addView(v); (v.layoutParams as LinearLayout.LayoutParams).setMargins(dpi(4), 0, dpi(4), 0)
        }
        col.addView(ctr, LinearLayout.LayoutParams(-1, -2))
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1.3f))

        // ----- панель медиатеки -----
        libPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.PANEL)
            visibility = View.GONE
            isClickable = true
            setPadding(dpi(16), dpi(8), dpi(16), 0)
        }
        val lh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val lt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lt.addView(text(24f, Theme.TEXT, true).apply { text = "Музыка" })
        libCount = text(12f, DIM); lt.addView(libCount)
        lh.addView(lt, LinearLayout.LayoutParams(0, -2, 1f))
        lh.addView(iconBtn(R.drawable.ic_more, 48) { showMenu() })
        lh.addView(iconBtn(R.drawable.ic_close, 48) { showLibrary(false) })
        libPanel.addView(lh, LinearLayout.LayoutParams(-1, dpi(60)))

        val tabs = LinearLayout(this)
        tabAll = chip("Все") { tab = 0; applyFilter(); styleTabs() }
        tabFav = chip("Избранное") { tab = 1; applyFilter(); styleTabs() }
        tabDl = chip("Загрузки") { tab = 2; applyFilter(); styleTabs() }
        tabs.addView(tabAll); tabs.addView(tabFav); tabs.addView(tabDl)
        libPanel.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(10) })
        styleTabs()

        search = EditText(this).apply {
            hint = "Поиск"
            setHintTextColor(Theme.HINT)
            setTextColor(Theme.TEXT)
            setSingleLine()
            setPadding(dpi(18), 0, dpi(18), 0)
            background = GradientDrawable().apply { cornerRadius = dp(24f); setColor(Theme.accentA(0x1F)); setStroke(dpi(1), Theme.accentA(0x33)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        libPanel.addView(search, LinearLayout.LayoutParams(-1, dpi(46)).apply { bottomMargin = dpi(8) })

        val frame = FrameLayout(this)
        list = ListView(this).apply {
            divider = null; adapter = this@MainActivity.adapter
            isFastScrollEnabled = true
            setOnItemLongClickListener { _, _, pos, _ -> if (pos in shown.indices) showTrackActions(shown[pos]); true }
            setOnItemClickListener { _, _, pos, _ ->
                hideKeyboard()
                if (pos in shown.indices) {
                    ensureStarted()
                    svc?.setQueue(shown, pos, true)
                    showLibrary(false)
                }
            }
        }
        frame.addView(list, FrameLayout.LayoutParams(-1, -1))
        emptyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dpi(24), 0, dpi(24), 0) }
        emptyText = text(15f, DIM).apply { gravity = Gravity.CENTER }
        emptyBtn = Button(this).apply {
            setOnClickListener {
                if (!hasAudioPerm()) {
                    if (prefs.getBoolean("asked", false) && !shouldShowRequestPermissionRationale(audioPerm()))
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    else requestPerms()
                }
            }
        }
        emptyBox.addView(emptyText); emptyBox.addView(emptyBtn)
        frame.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        libPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        // мини-плеер внизу библиотеки
        mini = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(18), dpi(6), dpi(8), dpi(6))
            background = GradientDrawable().apply { cornerRadius = dp(28f); setColor(Theme.MINI); setStroke(dpi(1), Theme.EDGE) }
            visibility = View.GONE
            setOnClickListener { showLibrary(false) }
        }
        val mt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        miniTitle = text(14f, Theme.TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        miniSub = text(11f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        mt.addView(miniTitle); mt.addView(miniSub)
        mini.addView(mt, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = iconBtn(R.drawable.ic_play, 48) { onPlayPressed() }
        mini.addView(miniPlay)
        mini.addView(iconBtn(R.drawable.ic_next, 48) { svc?.next() })
        libPanel.addView(mini, LinearLayout.LayoutParams(-1, dpi(64)).apply { topMargin = dpi(6); bottomMargin = dpi(14) })

        root.addView(libPanel, FrameLayout.LayoutParams(-1, -1))
        buildWebPanel(root)
        return root
    }

    private fun chip(label: String, onClick: () -> Unit) = text(14f, Theme.TEXT, true).apply {
        text = label
        gravity = Gravity.CENTER
        setPadding(dpi(18), dpi(8), dpi(18), dpi(8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dpi(8) }
    }

    private fun styleChip(v: TextView, on: Boolean) {
        v.setTextColor(if (on) Theme.NEON_DARK else Theme.TEXT)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(20f)
            if (on) setColor(Theme.NEON) else { setColor(Theme.CHIP_BG); setStroke(dpi(1), Theme.CHIP_STROKE) }
        }
    }

    private fun styleTabs() {
        styleChip(tabAll, tab == 0)
        styleChip(tabFav, tab == 1)
        styleChip(tabDl, tab == 2)
    }

    private fun styleSources() {
        styleChip(chipAud, webSource == 2)
        styleChip(chipArc, webSource == 0)
        styleChip(chipJam, webSource == 1)
        styleChip(chipArt, webSource == 3)
        for (i in genreChips.indices) styleChip(genreChips[i], i == webGenre)
    }

    private fun showLibrary(on: Boolean) {
        libPanel.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) hideKeyboard() else { adapter.notifyDataSetChanged(); refresh() }
    }

    private fun hideKeyboard(v: View = search) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ---------- меню ----------

    private fun sleepLabel(): String {
        val end = svc?.sleepEndsAt ?: 0L
        if (end <= 0L) return "Выкл"
        val min = ((end - System.currentTimeMillis()) / 60000L + 1).coerceAtLeast(1)
        return "ещё $min мин"
    }

    private fun showMenu() {
        val sortNames = arrayOf("По названию", "По исполнителю", "Недавно добавленные")
        val ignoring = try { (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName) } catch (_: Exception) { false }
        Sheet(this).show("ZXCMUSS", listOf(
            Sheet.Row(R.drawable.ic_palette, "Кастомизация", "тема, эффекты, шрифты") { showCustomize() },
            Sheet.Row(R.drawable.ic_cloud, "Музыка из интернета") { showWeb(true) },
            Sheet.Row(R.drawable.ic_shuffle, "Микс по вашей музыке") { showMixMenu() },
            Sheet.Row(R.drawable.ic_add, "Редактор треков") { showEditorMenu() },
            Sheet.Row(R.drawable.ic_eq, "Эквалайзер и бас-буст", if (svc?.fxOn == true) "Вкл" else "Выкл", accent = svc?.fxOn == true) { showEq() },
            Sheet.Row(R.drawable.ic_send, "Telegram и файлы") { showImport() },
            Sheet.Row(R.drawable.ic_sort, "Сортировка", sortNames[sortMode]) { showSort(sortNames) },
            Sheet.Row(R.drawable.ic_timer, "Таймер сна", sleepLabel(), accent = (svc?.sleepEndsAt ?: 0L) > 0L) { showSleep() },
            Sheet.Row(R.drawable.ic_lyrics, "Тексты из интернета", if (onlineLyrics) "Вкл" else "Выкл", accent = onlineLyrics) {
                onlineLyrics = !onlineLyrics
                prefs.edit().putBoolean("online", onlineLyrics).apply()
                if (onlineLyrics) { shownTrackId = -2L; refresh() }
                Toast.makeText(this, if (onlineLyrics) "Тексты будут искаться в интернете" else "Тексты из интернета выключены", Toast.LENGTH_SHORT).show()
            },
            Sheet.Row(R.drawable.ic_refresh, "Работа в фоне", if (ignoring) "Разрешена" else "Настроить", accent = ignoring) { showBackground() },
            Sheet.Row(R.drawable.ic_refresh, "Обновить библиотеку") { if (hasAudioPerm()) rescan() else requestPerms() },
            Sheet.Row(R.drawable.ic_info, "О приложении") { showAbout() }
        ), signature = "@xosub донаты в тг автору")
    }

    private fun showBackground() {
        Sheet(this).show("Работа в фоне", listOf(
            Sheet.Row(R.drawable.ic_refresh, "Открыть настройки батареи") {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {} }
            }
        ), footer = "Музыка играет в фоне и при выключенном экране. Чтобы система не останавливала плеер, " +
            "найдите в списке ZXCMUSS и выберите «Не ограничивать» (или «Без ограничений»). Скачивание треков тоже продолжается в фоне.")
    }

    // ---------- кастомизация ----------

    private fun onOff(key: String, def: Boolean) = if (prefs.getBoolean(key, def)) "Вкл" else "Выкл"

    private fun showCustomize() {
        val fishOn = prefs.getBoolean("fish", true)
        val emOn = prefs.getBoolean("emoji", false)
        val bgI = prefs.getInt("bg", 0).coerceIn(0, AuroraView.BG_NAMES.size - 1)
        val fontCur = prefs.getString("fontFile", "") ?: ""
        val fontName = Fnt.list.firstOrNull { it.key == fontCur }?.name ?: "Свой"
        val modes = arrayOf("Как тема", "Матовое стекло", "Радуга")
        Sheet(this).show("Кастомизация", listOf(
            Sheet.Row(R.drawable.ic_palette, "Тема", Theme.list[Theme.index].name) { showThemes() },
            Sheet.Row(R.drawable.ic_fisheye, "Рыбий глаз", if (fishOn) prefs.getInt("fishK", 60).toString() + "%" else "Выкл", accent = fishOn) { showFish() },
            Sheet.Row(R.drawable.ic_emoji, "Смайлики", if (emOn) "Вкл" else "Выкл", accent = emOn) { showEmoji() },
            Sheet.Row(R.drawable.ic_weather, "Погода на фоне и скорость", AuroraView.BG_NAMES[bgI], accent = bgI != 0) { showBackgrounds() },
            Sheet.Row(R.drawable.ic_add, "Своя картинка на фон", if (File(filesDir, "bg.jpg").exists()) "Есть" else "Нет", accent = File(filesDir, "bg.jpg").exists()) { showBgImage() },
            Sheet.Row(R.drawable.ic_timer, "Ползунок трека", if (prefs.getInt("seek", 0) == 1) "Плоский" else "Волна") { showSeekStyle() },
            Sheet.Row(R.drawable.ic_eq, "Визуализатор (бас-полоски)", modes[prefs.getInt("vizMode", 0).coerceIn(0, 2)]) { showViz() },
            Sheet.Row(R.drawable.ic_lyrics, "Шрифт", fontName, accent = fontCur.isNotEmpty()) { showFonts() },
            Sheet.Row(R.drawable.ic_library, "Обложка трека на главной", onOff("coverMain", false), accent = prefs.getBoolean("coverMain", false)) {
                prefs.edit().putBoolean("coverMain", !prefs.getBoolean("coverMain", false)).apply()
                loadCover(svc?.current)
                Toast.makeText(this, "Обложка: " + onOff("coverMain", false), Toast.LENGTH_SHORT).show()
            },
            Sheet.Row(R.drawable.ic_lyrics, "Текст: только спетые слова", onOff("lyricHide", false), accent = prefs.getBoolean("lyricHide", false)) {
                prefs.edit().putBoolean("lyricHide", !prefs.getBoolean("lyricHide", false)).apply()
                lastLyricKey = -3
                Toast.makeText(this, "Только спетые слова: " + onOff("lyricHide", false), Toast.LENGTH_SHORT).show()
            }
        ), footer = "Все настройки внешнего вида собраны здесь.")
    }

    private fun showSeekStyle() {
        val cur = prefs.getInt("seek", 0)
        Sheet(this).show("Ползунок трека", listOf("Волна", "Плоский").mapIndexed { i, n ->
            Sheet.Row(R.drawable.ic_timer, n, checked = i == cur) { prefs.edit().putInt("seek", i).apply(); applyEffects() }
        })
    }

    private fun showViz() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modes = arrayOf("Как тема", "Матовое стекло", "Радуга")
        val chips = ArrayList<TextView>()
        val row = LinearLayout(this)
        fun restyle() {
            val m = prefs.getInt("vizMode", 0)
            for (i in chips.indices) styleChip(chips[i], i == m)
        }
        for (i in modes.indices) {
            val c = chip(modes[i]) { prefs.edit().putInt("vizMode", i).apply(); restyle(); applyEffects() }
            chips.add(c); row.addView(c)
        }
        restyle()
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) },
            LinearLayout.LayoutParams(-1, -2))
        val l1 = text(14f, DIM).apply { text = "Скорость переливания радуги: " + prefs.getInt("vizSpeed", 30) + "%"; setPadding(dpi(8), dpi(12), 0, 0) }
        box.addView(l1)
        box.addView(GlassSlider(this, false, 0, 100, false).apply {
            value = prefs.getInt("vizSpeed", 30)
            onChange = { v -> prefs.edit().putInt("vizSpeed", v).apply(); l1.text = "Скорость переливания радуги: $v%"; applyEffects() }
        }, LinearLayout.LayoutParams(-1, dpi(44)))
        fun warpText(v: Int) = "Искажение от середины: " + (if (v == 0) "сток" else "$v%")
        val l2 = text(14f, DIM).apply { text = warpText(prefs.getInt("vizWarp", 0)); setPadding(dpi(8), dpi(6), 0, 0) }
        box.addView(l2)
        box.addView(GlassSlider(this, false, 0, 100, false).apply {
            value = prefs.getInt("vizWarp", 0)
            onChange = { v -> prefs.edit().putInt("vizWarp", v).apply(); l2.text = warpText(v); applyEffects() }
        }, LinearLayout.LayoutParams(-1, dpi(44)))
        Sheet(this).show("Визуализатор", listOf(
            Sheet.Row(R.drawable.ic_refresh, "Сбросить на сток") {
                prefs.edit().remove("vizMode").remove("vizSpeed").remove("vizWarp").apply(); applyEffects()
            }
        ), footer = "Матовое стекло: прозрачные полоски с мягкой кромкой. Радуга: цвета плавно переливаются. " +
            "Искажение вытягивает полоски в середине и сжимает к краям.", extra = box)
    }

    private fun showFonts() {
        val cur = prefs.getString("fontFile", "") ?: ""
        val rows = ArrayList<Sheet.Row>()
        for (f in Fnt.list) rows.add(Sheet.Row(R.drawable.ic_lyrics, f.name, checked = f.key == cur) { chooseFont(f) })
        rows.add(Sheet.Row(R.drawable.ic_cloud, "Свой шрифт по ссылке…", checked = cur == "custom.ttf") { askFontUrl() })
        Sheet(this).show("Шрифт", rows, footer = "Шрифт скачивается один раз и хранится в приложении. " +
            "Подойдёт любая прямая ссылка на .ttf или .otf (например, с GitHub). Выбирайте шрифт с русскими буквами.")
    }

    private fun chooseFont(f: Fnt.F) {
        val u = f.url
        if (u == null) { prefs.edit().putString("fontFile", "").apply(); recreate(); return }
        Toast.makeText(this, "Скачиваю шрифт…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = Fnt.download(applicationContext, u, f.key)
            runOnUiThread {
                if (ok) { prefs.edit().putString("fontFile", f.key).apply(); recreate() }
                else Toast.makeText(this, "Не удалось скачать шрифт", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun askFontUrl() {
        val input = EditText(this).apply { hint = "https://…/Font.ttf"; setSingleLine() }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Свой шрифт")
            .setMessage("Вставьте прямую ссылку на файл шрифта (.ttf или .otf).")
            .setView(input)
            .setPositiveButton("Скачать") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    Toast.makeText(this, "Скачиваю шрифт…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val ok = Fnt.download(applicationContext, u, "custom.ttf")
                        runOnUiThread {
                            if (ok) { prefs.edit().putString("fontFile", "custom.ttf").apply(); recreate() }
                            else Toast.makeText(this, "Не удалось открыть шрифт по этой ссылке", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try { startActivityForResult(i, req) } catch (_: Exception) {}
    }

    private fun showBgImage() {
        Sheet(this).show("Своя картинка на фон", listOf(
            Sheet.Row(R.drawable.ic_add, "Выбрать картинку") { pickImage(78) },
            Sheet.Row(R.drawable.ic_refresh, "Сбросить на стандартный фон") {
                try { File(filesDir, "bg.jpg").delete() } catch (_: Exception) {}
                applyEffects()
                Toast.makeText(this, "Фон сброшен", Toast.LENGTH_SHORT).show()
            }
        ), footer = "Картинка ложится на фон плеера, а цвета выбранной темы остаются поверх неё, поэтому всё выглядит в одном стиле.")
    }

    // ---------- обложка ----------

    private fun loadCover(t: Track?) {
        if (!::coverImg.isInitialized) return
        if (t == null || !prefs.getBoolean("coverMain", false)) { coverImg.visibility = View.GONE; return }
        Thread {
            val b = Covers.load(applicationContext, t)
            runOnUiThread {
                if (shownTrackId == t.id || shownTrackId == -2L) {
                    if (b != null) { coverImg.setImageBitmap(b); coverImg.visibility = View.VISIBLE }
                    else coverImg.visibility = View.GONE
                }
            }
        }.start()
    }

    // ---------- действия с треками: правка, текст, удаление ----------

    private fun showEditorMenu() {
        val cur = svc?.current
        val rows = ArrayList<Sheet.Row>()
        if (cur != null) rows.add(Sheet.Row(R.drawable.ic_add, "Текущий трек", cur.title) { showTrackActions(cur) })
        rows.add(Sheet.Row(R.drawable.ic_library, "Выбрать трек в библиотеке") {
            showLibrary(true)
            Toast.makeText(this, "Удерживайте палец на треке, чтобы открыть редактор", Toast.LENGTH_LONG).show()
        })
        Sheet(this).show("Редактор треков", rows, footer = "Название, исполнитель, альбом, год и обложка, свой текст песни, удаление трека. " +
            "Правки хранятся в приложении, сам файл музыки не меняется.")
    }

    private fun showTrackActions(t: Track) {
        Sheet(this).show(t.title, listOf(
            Sheet.Row(R.drawable.ic_add, "Редактировать (название, автор, год, обложка)") { editTrack(t) },
            Sheet.Row(R.drawable.ic_lyrics, "Свой текст песни") { editLyrics(t) },
            Sheet.Row(R.drawable.ic_close, "Удалить трек с устройства") { confirmDelete(t) }
        ), footer = t.artist)
    }

    private fun afterEdit() {
        afterLoad = { svc?.refreshTracks(all); shownTrackId = -2L; refresh() }
        loadLibrary()
    }

    private fun editTrack(t: Track) {
        editCoverFor = t.id
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(20), dpi(8), dpi(20), 0) }
        fun field(h: String, v: String, num: Boolean): EditText = EditText(this).apply {
            hint = h
            setText(v)
            setSingleLine()
            if (num) inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val fTitle = field("Название", t.title, false)
        val fArtist = field("Исполнитель", if (t.artist == "Неизвестный исполнитель") "" else t.artist, false)
        val fAlbum = field("Альбом", t.album, false)
        val fYear = field("Год", t.year, true)
        for (f in listOf(fTitle, fArtist, fAlbum, fYear)) box.addView(f, LinearLayout.LayoutParams(-1, -2))
        val cov = Button(this).apply { text = "Выбрать обложку"; setOnClickListener { pickImage(80) } }
        box.addView(cov, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(8) })
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Редактор трека")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Сохранить") { _, _ ->
                Edits.save(this, t.id, fTitle.text.toString().trim(), fArtist.text.toString().trim(),
                    fAlbum.text.toString().trim(), fYear.text.toString().trim())
                afterEdit()
                Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Сбросить") { _, _ -> Edits.reset(this, t.id); afterEdit() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun editLyrics(t: Track) {
        val old = LyricsFetcher.cached(this, t) ?: ""
        val input = EditText(this).apply {
            hint = "Вставьте текст. Можно обычными строками или в формате LRC [00:12.30]слова"
            setText(old)
            minLines = 8
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Текст: " + t.title)
            .setView(ScrollView(this).apply { addView(input); setPadding(dpi(16), 0, dpi(16), 0) })
            .setPositiveButton("Сохранить") { _, _ ->
                val txt = input.text.toString()
                if (txt.isBlank()) LyricsFetcher.deleteFor(this, t.id) else LyricsFetcher.saveOwn(this, t, txt)
                if (svc?.current?.id == t.id) { shownTrackId = -2L; refresh() }
                Toast.makeText(this, "Текст сохранён", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Удалить текст") { _, _ ->
                LyricsFetcher.deleteFor(this, t.id)
                if (svc?.current?.id == t.id) { shownTrackId = -2L; refresh() }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmDelete(t: Track) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Удалить трек?")
            .setMessage("«${t.title}» будет удалён с устройства без возможности восстановления.")
            .setPositiveButton("Удалить") { _, _ -> deleteTrack(t) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteTrack(t: Track) {
        pendingDelete = t
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(t.uri))
                startIntentSenderForResult(pi.intentSender, 79, null, 0, 0, 0)
            } else {
                val n = contentResolver.delete(t.uri, null, null)
                if (n > 0) afterDelete(t) else Toast.makeText(this, "Не удалось удалить", Toast.LENGTH_SHORT).show()
            }
        } catch (e: SecurityException) {
            if (e is RecoverableSecurityException) {
                try { startIntentSenderForResult(e.userAction.actionIntent.intentSender, 79, null, 0, 0, 0) }
                catch (_: Exception) { Toast.makeText(this, "Нет прав на удаление", Toast.LENGTH_SHORT).show() }
            } else Toast.makeText(this, "Нет прав на удаление", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось удалить", Toast.LENGTH_SHORT).show()
        }
    }

    private fun afterDelete(t: Track) {
        favs.remove(t.id)
        prefs.edit().putStringSet("fav", favs.map { it.toString() }.toSet()).apply()
        Edits.reset(this, t.id)
        LyricsFetcher.deleteFor(this, t.id)
        svc?.dropTrack(t.id)
        Toast.makeText(this, "Трек удалён", Toast.LENGTH_SHORT).show()
        shownTrackId = -2L
        afterLoad = { refresh() }
        loadLibrary()
    }

    // ---------- миксы и ИИ ----------

    private fun showMixMenu() {
        val ai = Ai.configured(this)
        Sheet(this).show("Микс", listOf(
            Sheet.Row(R.drawable.ic_shuffle, "Микс по скачанной музыке") { buildMix(false) },
            Sheet.Row(R.drawable.ic_lyrics, "ИИ-микс (умный подбор)", if (ai) "Вкл" else "Настроить", accent = ai) {
                if (Ai.configured(this)) buildMix(true) else showAiSettings()
            },
            Sheet.Row(R.drawable.ic_info, "Настроить ИИ") { showAiSettings() }
        ), footer = "Микс строится по тому, что вы скачали и отметили сердечком. Обычный микс ищет ещё треки ваших любимых исполнителей. " +
            "ИИ-микс просит у выбранного вами ИИ похожие песни и проверяет, что они есть в свободных источниках, поэтому в списке только настоящие треки, а не случайный набор.")
    }

    private fun buildMix(useAi: Boolean) {
        val base = all.filter { it.id in dl || it.id in favs }
        val src = if (base.size >= 3) base else all
        if (src.isEmpty()) {
            Toast.makeText(this, "Сначала скачайте или добавьте в избранное несколько треков", Toast.LENGTH_LONG).show()
            return
        }
        showMixPanel(if (useAi) "ИИ подбирает треки…" else "Собираю микс…")
        val app = applicationContext
        Thread {
            var items: List<WebMusic.Item> = emptyList()
            var err = ""
            try {
                if (useAi) {
                    val liked = src.shuffled().take(40).map { it.artist + " - " + it.title }
                    val recs = Ai.recommend(app, liked, 25)
                    items = Mix.resolve(recs)
                    if (items.isEmpty()) err = "ИИ предложил треки, но их нет среди свободных источников. Попробуйте ещё раз."
                } else {
                    val cnt = HashMap<String, Int>()
                    for (t in src) if (t.artist != "Неизвестный исполнитель") cnt[t.artist] = (cnt[t.artist] ?: 0) + 1
                    val artists = cnt.entries.sortedByDescending { it.value }.take(6).map { it.key }
                    val have = src.map { Mix.key(it.title) }.toSet()
                    items = Mix.byArtists(artists, have)
                    if (items.isEmpty()) err = "Новых треков ваших исполнителей среди свободных источников нет. Попробуйте ИИ-микс."
                }
            } catch (e: Exception) {
                err = "Ошибка: " + (e.message ?: "нет соединения").take(140)
            }
            runOnUiThread { showWebItems(items, err, true) }
        }.start()
    }

    private fun showAiSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(20), dpi(4), dpi(20), 0) }
        fun field(h: String, v: String, pass: Boolean): EditText = EditText(this).apply {
            hint = h
            setText(v)
            setSingleLine()
            if (pass) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val fUrl = field("Адрес API", prefs.getString("aiUrl", "https://api.openai.com/v1") ?: "", false)
        val fModel = field("Модель (например gpt-4o-mini)", prefs.getString("aiModel", "") ?: "", false)
        val fKey = field("Ключ API", prefs.getString("aiKey", "") ?: "", true)
        for (f in listOf(fUrl, fModel, fKey)) box.addView(f, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("ИИ для миксов")
            .setMessage("Подойдёт любой ИИ. Адреса:\nOpenAI: https://api.openai.com/v1\nOpenRouter: https://openrouter.ai/api/v1\n" +
                "Groq: https://api.groq.com/openai/v1\nGemini: https://generativelanguage.googleapis.com/v1beta/openai\n" +
                "Anthropic: https://api.anthropic.com\nOllama: http://адрес:11434/v1\n\nКлюч хранится только на этом устройстве.")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("aiUrl", fUrl.text.toString().trim()).putString("aiModel", fModel.text.toString().trim())
                    .putString("aiKey", fKey.text.toString().trim()).apply()
                Toast.makeText(this, "ИИ сохранён. Меню → Микс по вашей музыке", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showThemes() {
        Sheet(this).show("Тема", Theme.list.mapIndexed { i, p ->
            Sheet.Row(R.drawable.ic_palette, p.name, checked = i == Theme.index, swatch = p.accent) {
                if (i != Theme.index) { prefs.edit().putInt("theme", i).apply(); recreate() }
            }
        })
    }

    private fun showImport() {
        Sheet(this).show("Telegram и файлы", listOf(
            Sheet.Row(R.drawable.ic_add, "Выбрать аудиофайлы") { pickAudio() }
        ), "Из Telegram: откройте аудио → «Поделиться» → ZXCMUSS. Трек сохранится в Music/ZXCMUSS и появится во вкладке «Загрузки». " +
            "Если в Telegram нажать «Сохранить в музыку», трек тоже появится в библиотеке (меню → «Обновить библиотеку»).\n\n" +
            "ВК Музыка и Яндекс Музыка: нажмите «Поделиться» на треке → ZXCMUSS, и название подставится в поиск свободной музыки.\n\n" +
            "Прямая синхронизация с аккаунтами Telegram, ВК и Яндекс невозможна: у них нет открытого доступа к личной музыке для сторонних приложений.")
    }

    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(i, 77) } catch (_: Exception) {}
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 78 && res == RESULT_OK) {
            val u = data?.data
            if (u != null) {
                val ok = Covers.importImage(applicationContext, u, File(filesDir, "bg.jpg"), 1440)
                Toast.makeText(this, if (ok) "Фон установлен" else "Не удалось открыть картинку", Toast.LENGTH_SHORT).show()
                applyEffects()
            }
        }
        if (req == 80 && res == RESULT_OK) {
            val u = data?.data
            if (u != null && editCoverFor >= 0) {
                val ok = Covers.importImage(applicationContext, u, Edits.coverFile(this, editCoverFor), 900)
                Toast.makeText(this, if (ok) "Обложка сохранена (нажмите «Сохранить»)" else "Не удалось открыть картинку", Toast.LENGTH_SHORT).show()
                if (ok && svc?.current?.id == editCoverFor) loadCover(svc?.current)
            }
        }
        if (req == 79) {
            val t = pendingDelete
            pendingDelete = null
            if (t != null && res == RESULT_OK) {
                if (Build.VERSION.SDK_INT < 30) { try { contentResolver.delete(t.uri, null, null) } catch (_: Exception) {} }
                afterDelete(t)
            }
        }
        if (req == 77 && res == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
            } else {
                val u = data.data
                if (u != null) uris.add(u)
            }
            if (uris.isNotEmpty()) {
                Toast.makeText(this, "Сохраняю музыку…", Toast.LENGTH_SHORT).show()
                Importer.importUris(this, uris) { n ->
                    runOnUiThread {
                        Toast.makeText(this, if (n > 0) "Добавлено треков: $n (вкладка «Загрузки»)" else "Не удалось сохранить файлы", Toast.LENGTH_LONG).show()
                        tab = 2; styleTabs()
                        loadLibrary()
                    }
                }
            }
        }
    }

    private fun showSort(names: Array<String>) {
        Sheet(this).show("Сортировка", names.mapIndexed { i, n ->
            Sheet.Row(R.drawable.ic_sort, n, checked = i == sortMode) {
                sortMode = i; prefs.edit().putInt("sort", i).apply(); applyFilter()
            }
        })
    }

    private fun showSleep() {
        val opts = listOf(0 to "Выключить", 15 to "15 минут", 30 to "30 минут", 45 to "45 минут", 60 to "60 минут", 90 to "90 минут")
        val rows = ArrayList<Sheet.Row>()
        for ((m, n) in opts) rows.add(Sheet.Row(R.drawable.ic_timer, n) {
            svc?.setSleepTimer(m)
            Toast.makeText(this, if (m == 0) "Таймер выключен" else "Музыка остановится через $m мин", Toast.LENGTH_SHORT).show()
        })
        rows.add(Sheet.Row(R.drawable.ic_timer, "Своё время…") { askSleepCustom() })
        Sheet(this).show("Таймер сна", rows)
    }

    private fun askSleepCustom() {
        val input = EditText(this).apply {
            hint = "Минут (от 1 до 1440)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine()
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Таймер сна")
            .setView(input)
            .setPositiveButton("Запустить") { _, _ ->
                val m = input.text.toString().trim().toIntOrNull()
                if (m != null && m in 1..1440) {
                    svc?.setSleepTimer(m)
                    Toast.makeText(this, "Музыка остановится через $m мин", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Введите число минут от 1 до 1440", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showAbout() {
        Sheet(this).show("О приложении", emptyList(),
            "ZXCMUSS 2.0\n\n" +
                "Музыку скачайте в папку Download или Music — плеер найдёт её сам. Если трек не появился, откройте меню → «Обновить библиотеку».\n\n" +
                "Тексты: ищутся в интернете (lrclib.net) по названию и исполнителю. Можно положить свой файл .lrc с тем же именем рядом с треком.")
    }

    // ---------- эффекты: рыбий глаз, смайлики, фоны ----------

    private fun applyEffects() {
        fish.strength = if (prefs.getBoolean("fish", true)) prefs.getInt("fishK", 60) / 100f * 0.5f else 0f
        val custom = (prefs.getString("emojiCustom", "") ?: "").split(" ").filter { it.isNotBlank() }
        aurora.customEmojis = custom
        aurora.emojiSet = if (prefs.getBoolean("emoji", false)) prefs.getInt("emojiSet", 0) else -1
        aurora.bgMode = prefs.getInt("bg", 0)
        aurora.bgSpeed = prefs.getInt("bgSpeed", 100) / 100f
        val sig = "" + aurora.emojiSet + "|" + aurora.bgMode + "|" + custom.joinToString("")
        if (sig != fxSig) { fxSig = sig; aurora.rebuild() }
        // своя картинка на фон
        val bgf = File(filesDir, "bg.jpg")
        val stamp = if (bgf.exists()) bgf.lastModified() else 0L
        if (stamp != bgStamp) {
            bgStamp = stamp
            val bmp = if (stamp != 0L) try { BitmapFactory.decodeFile(bgf.path) } catch (_: Throwable) { null } else null
            aurora.setBgImage(bmp)
        }
        viz.colorMode = prefs.getInt("vizMode", 0)
        viz.rainbowSpeed = prefs.getInt("vizSpeed", 30)
        viz.warp = prefs.getInt("vizWarp", 0) / 100f
        snake.style = prefs.getInt("seek", 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSearchIntent(intent)
    }

    /** «Поделиться → ZXCMUSS» из ВК / Яндекс Музыки: подставляем название трека в поиск. */
    private fun handleSearchIntent(i: Intent?) {
        if (i == null || !i.hasExtra("q")) return
        val q = i.getStringExtra("q") ?: ""
        i.removeExtra("q")
        webLoaded = true
        showWeb(true)
        webGenre = 0
        styleSources()
        webSearch.setText(q)
        if (q.isBlank()) {
            Toast.makeText(this, "В ссылке нет названия трека. Введите его вручную", Toast.LENGTH_LONG).show()
            webLoaded = false
            showWeb(true)
        } else {
            doWebSearch()
        }
    }

    private fun showFish() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(8), 0, dpi(8), dpi(8)) }
        head.addView(text(16f, Theme.TEXT).apply { text = "Рыбий глаз" }, LinearLayout.LayoutParams(0, -2, 1f))
        val pill = chip("") { }
        fun upd() {
            val on = prefs.getBoolean("fish", true)
            pill.text = if (on) "Вкл" else "Выкл"
            styleChip(pill, on)
        }
        pill.setOnClickListener {
            prefs.edit().putBoolean("fish", !prefs.getBoolean("fish", true)).apply()
            upd(); applyEffects()
        }
        upd()
        head.addView(pill)
        box.addView(head)
        val label = text(14f, DIM).apply { text = "Сила эффекта: " + prefs.getInt("fishK", 60) + "%"; setPadding(dpi(8), dpi(6), 0, 0) }
        box.addView(label)
        val sl = GlassSlider(this, false, 0, 100, false).apply {
            value = prefs.getInt("fishK", 60)
            onChange = { v ->
                prefs.edit().putInt("fishK", v).putBoolean("fish", true).apply()
                label.text = "Сила эффекта: $v%"
                upd(); applyEffects()
            }
        }
        box.addView(sl, LinearLayout.LayoutParams(-1, dpi(44)))
        Sheet(this).show("Рыбий глаз", emptyList(),
            footer = "Экран плеера искривляется как через объектив: центр выпуклый, края и углы изгибаются. Кнопки и анимации работают как обычно.", extra = box)
    }

    private val emojiAll = ("\uD83C\uDFB5 \uD83C\uDFB6 \uD83C\uDFA7 \uD83C\uDFA4 \uD83C\uDFB8 \uD83C\uDFB9 \uD83E\uDD41 \uD83C\uDFB7 \uD83C\uDFBA \uD83C\uDFBB \uD83D\uDCBF \uD83D\uDCFB " +
        "\u2728 \uD83D\uDCAB \u2B50 \uD83C\uDF1F \uD83C\uDF19 \u2600\uFE0F \uD83C\uDF08 \u2601\uFE0F \u26A1 \uD83D\uDD25 \uD83D\uDCA5 \u2744\uFE0F " +
        "\u2764\uFE0F \uD83E\uDDE1 \uD83D\uDC9B \uD83D\uDC9A \uD83D\uDC99 \uD83D\uDC9C \uD83D\uDDA4 \uD83E\uDD0D \uD83D\uDC96 \uD83D\uDC97 \uD83D\uDC9E " +
        "\uD83C\uDF38 \uD83C\uDF3A \uD83C\uDF3B \uD83C\uDF39 \uD83C\uDF40 \uD83C\uDF3F \uD83C\uDF43 \uD83C\uDF42 \uD83E\uDD8B \uD83C\uDF0A " +
        "\uD83D\uDC31 \uD83D\uDC36 \uD83E\uDD8A \uD83D\uDC3C \uD83D\uDC38 \uD83D\uDC35 \uD83D\uDC7D \uD83D\uDC7E \uD83E\uDD16 \uD83D\uDC80 \uD83D\uDC7B " +
        "\uD83D\uDE0E \uD83D\uDE0D \uD83E\uDD70 \uD83D\uDE08 \uD83E\uDD18 \uD83D\uDD2E \uD83D\uDC8E \uD83D\uDC51 \uD83C\uDF52 \uD83C\uDF53 \uD83C\uDF49 " +
        "\uD83C\uDF55 \uD83C\uDF69 \uD83C\uDF6D \uD83D\uDE80 \uD83D\uDEF8 \uD83E\uDE90 \uD83C\uDF0D \uD83C\uDFC6 \uD83C\uDFAE").split(" ")

    private fun showEmoji() {
        val on = prefs.getBoolean("emoji", false)
        val cur = prefs.getInt("emojiSet", 0)
        val rows = ArrayList<Sheet.Row>()
        rows.add(Sheet.Row(R.drawable.ic_emoji, if (on) "Выключить смайлики" else "Включить смайлики", if (on) "Вкл" else "Выкл", accent = on) {
            prefs.edit().putBoolean("emoji", !on).apply(); applyEffects()
        })
        rows.add(Sheet.Row(R.drawable.ic_emoji, "Выбрать свои смайлики…", checked = on && cur == 100) { showEmojiPicker() })
        for (i in AuroraView.SET_NAMES.indices) {
            rows.add(Sheet.Row(R.drawable.ic_emoji, AuroraView.SET_NAMES[i], checked = on && cur == i) {
                prefs.edit().putBoolean("emoji", true).putInt("emojiSet", i).apply(); applyEffects()
            })
        }
        Sheet(this).show("Смайлики", rows, footer = "Лёгкие смайлики плавают по фону и пульсируют под бас. Можно собрать свой набор.")
    }

    private fun showEmojiPicker() {
        val chosen = LinkedHashSet<String>((prefs.getString("emojiCustom", "") ?: "").split(" ").filter { it.isNotBlank() })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val info = text(14f, DIM).apply { setPadding(dpi(8), 0, dpi(8), dpi(8)) }
        fun save() {
            prefs.edit().putString("emojiCustom", chosen.joinToString(" ")).putBoolean("emoji", true).putInt("emojiSet", 100).apply()
            info.text = if (chosen.isEmpty()) "Нажимайте на смайлики, чтобы выбрать" else "Выбрано: " + chosen.size
            applyEffects()
        }
        info.text = if (chosen.isEmpty()) "Нажимайте на смайлики, чтобы выбрать" else "Выбрано: " + chosen.size
        box.addView(info)
        val perRow = 6
        var row: LinearLayout? = null
        for ((idx, e) in emojiAll.withIndex()) {
            if (idx % perRow == 0) {
                row = LinearLayout(this)
                box.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            val cell = TextView(this).apply {
                text = e
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            }
            fun paint() {
                cell.background = GradientDrawable().apply {
                    cornerRadius = dp(14f)
                    if (e in chosen) { setColor(Theme.accentA(0x55)); setStroke(dpi(2), Theme.NEON) } else setColor(Theme.accentA(0x12))
                }
            }
            paint()
            cell.setOnClickListener {
                if (!chosen.remove(e)) chosen.add(e)
                paint(); save()
            }
            row?.addView(cell, LinearLayout.LayoutParams(0, dpi(52), 1f).apply { setMargins(dpi(3), dpi(3), dpi(3), dpi(3)) })
        }
        Sheet(this).show("Свои смайлики", listOf(
            Sheet.Row(R.drawable.ic_refresh, "Очистить выбор") { prefs.edit().putString("emojiCustom", "").apply(); applyEffects() }
        ), extra = box)
    }

    private fun showBackgrounds() {
        val cur = prefs.getInt("bg", 0)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val l = text(14f, DIM).apply { text = "Скорость: " + prefs.getInt("bgSpeed", 100) + "%"; setPadding(dpi(8), dpi(6), 0, 0) }
        box.addView(l)
        box.addView(GlassSlider(this, false, 25, 300, false).apply {
            value = prefs.getInt("bgSpeed", 100)
            onChange = { v -> prefs.edit().putInt("bgSpeed", v).apply(); l.text = "Скорость: $v%"; applyEffects() }
        }, LinearLayout.LayoutParams(-1, dpi(44)))
        Sheet(this).show("Погода на фоне", AuroraView.BG_NAMES.mapIndexed { i, n ->
            Sheet.Row(R.drawable.ic_weather, n, checked = i == cur) {
                prefs.edit().putInt("bg", i).apply(); applyEffects()
            }
        }, footer = "Ползунок меняет скорость дождя, снега, звёзд, светлячков и смайликов.", extra = box)
    }

    // ---------- эквалайзер ----------

    private class Preset(val name: String, val bands: IntArray, val bass: Int)

    private val presets = listOf(
        Preset("Плоский", intArrayOf(0, 0, 0, 0, 0), 0),
        Preset("Бас-буст", intArrayOf(80, 50, 0, -10, 0), 800),
        Preset("Глубокий бас", intArrayOf(100, 70, 10, -20, -10), 1000),
        Preset("Рок", intArrayOf(45, 25, -15, 25, 45), 200),
        Preset("Поп", intArrayOf(-10, 25, 40, 25, -10), 100),
        Preset("Вокал", intArrayOf(-30, 0, 50, 35, 0), 0),
        Preset("Электро", intArrayOf(60, 30, 0, 25, 50), 500)
    )

    private fun presetAt(p: Preset, i: Int, n: Int): Int =
        if (n <= 1) p.bands[0] else p.bands[Math.round(i * 4f / (n - 1))]

    private fun showEq() {
        val s = svc
        if (s == null) { Toast.makeText(this, "Плеер ещё запускается, попробуйте снова", Toast.LENGTH_SHORT).show(); return }
        val n = s.eqBandCount()
        val sliders = ArrayList<GlassSlider>()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(8), 0, dpi(8), dpi(8)) }
        head.addView(text(16f, Theme.TEXT).apply { text = "Эквалайзер" }, LinearLayout.LayoutParams(0, -2, 1f))
        val onPill = chip("") { }
        fun pillUpdate() { onPill.text = if (s.fxOn) "Вкл" else "Выкл"; styleChip(onPill, s.fxOn) }
        onPill.setOnClickListener { s.setFx(!s.fxOn); pillUpdate() }
        pillUpdate()
        head.addView(onPill)
        box.addView(head)

        val pr = LinearLayout(this)
        val bass = GlassSlider(this, false, 0, 1000, false)
        val bassVal = text(14f, NEON, true)
        presets.forEach { p ->
            val c = chip(p.name) {
                s.setFx(true); pillUpdate()
                for (i in 0 until n) { val v = presetAt(p, i, n); s.setEqBand(i, v); sliders[i].value = v }
                s.setBass(p.bass); bass.value = p.bass; bassVal.text = (p.bass / 10).toString() + "%"
            }
            c.setPadding(dpi(14), dpi(6), dpi(14), dpi(6))
            styleChip(c, false)
            pr.addView(c)
        }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(pr) },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(6) })

        val bands = LinearLayout(this)
        for (i in 0 until n) {
            val f = s.eqFreq(i)
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val sl = GlassSlider(this, true, -100, 100, true).apply {
                value = s.eqPct(i)
                onChange = { v -> s.setFx(true); pillUpdate(); s.setEqBand(i, v) }
            }
            sliders.add(sl)
            col.addView(sl, LinearLayout.LayoutParams(dpi(48), dpi(170)))
            col.addView(text(11f, DIM).apply { text = if (f >= 1000) (if (f % 1000 == 0) "${f / 1000}k" else "%.1fk".format(f / 1000f)) else "$f" })
            bands.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        box.addView(bands, LinearLayout.LayoutParams(-1, -2))

        val bh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(8), dpi(14), dpi(8), 0) }
        bh.addView(text(16f, Theme.TEXT).apply { text = "Бас-буст" }, LinearLayout.LayoutParams(0, -2, 1f))
        bassVal.text = (s.bassLevel / 10).toString() + "%"
        bh.addView(bassVal)
        box.addView(bh)
        bass.value = s.bassLevel
        bass.onChange = { v -> s.setFx(true); pillUpdate(); s.setBass(v); bassVal.text = (v / 10).toString() + "%" }
        box.addView(bass, LinearLayout.LayoutParams(-1, dpi(44)))

        Sheet(this).show("Эквалайзер", emptyList(), extra = box)
    }

    // ---------- музыка из интернета ----------

    private class WHolder(val title: TextView, val sub: TextView, val state: TextView)

    private fun buildWebPanel(root: FrameLayout) {
        webPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.PANEL)
            visibility = View.GONE
            isClickable = true
            setPadding(dpi(16), dpi(8), dpi(16), 0)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(text(22f, Theme.TEXT, true).apply { text = "Музыка из интернета" })
        ht.addView(text(11.5f, DIM).apply { text = "Только свободная и бесплатная музыка (Creative Commons)" })
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(iconBtn(R.drawable.ic_close, 48) { showWeb(false) })
        webPanel.addView(head, LinearLayout.LayoutParams(-1, dpi(64)))

        val chips = LinearLayout(this)
        chipAud = chip("Audius") { setSource(2) }
        chipArc = chip("Archive") { setSource(0) }
        chipJam = chip("Jamendo") { setSource(1) }
        chipArt = chip("Исполнители") { setSource(3) }
        chips.addView(chipAud); chips.addView(chipArc); chips.addView(chipJam); chips.addView(chipArt)
        webPanel.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(6); bottomMargin = dpi(8) })

        val gRow = LinearLayout(this)
        WebMusic.genres.forEachIndexed { i, g ->
            val c = chip(g.label) { webGenre = i; styleSources(); webSearch.setText(""); doWebSearch() }
            c.setPadding(dpi(14), dpi(6), dpi(14), dpi(6))
            genreChips.add(c); gRow.addView(c)
        }
        webPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(gRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpi(10) })
        styleSources()

        webSearch = EditText(this).apply {
            hint = "Песня или исполнитель (можно неточно)"
            setHintTextColor(Theme.HINT)
            setTextColor(Theme.TEXT)
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dpi(18), 0, dpi(18), 0)
            background = GradientDrawable().apply { cornerRadius = dp(24f); setColor(Theme.accentA(0x1F)); setStroke(dpi(1), Theme.accentA(0x33)) }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { doWebSearch(); true } else false
            }
        }
        webPanel.addView(webSearch, LinearLayout.LayoutParams(-1, dpi(46)).apply { bottomMargin = dpi(8) })
        dlAll = chip("Скачать всё") { downloadAll() }.apply { visibility = View.GONE }
        webPanel.addView(dlAll, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dpi(8) })

        webStatus = text(14f, DIM).apply {
            gravity = Gravity.CENTER
            setPadding(dpi(16), dpi(24), dpi(16), dpi(8))
            text = "Загружаю популярное…"
        }
        webPanel.addView(webStatus, LinearLayout.LayoutParams(-1, -2))

        webList = ListView(this).apply {
            divider = null
            adapter = this@MainActivity.webAdapter
            setOnItemClickListener { _, _, pos, _ -> if (pos in webItems.indices) onWebItem(webItems[pos]) }
        }
        webPanel.addView(webList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(webPanel, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showWeb(on: Boolean) {
        webPanel.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) hideKeyboard(webSearch)
        else if (!webLoaded) { webLoaded = true; doWebSearch() }
    }

    private fun setSource(i: Int) {
        webSource = i
        styleSources()
        if (webSearch.text.toString().isNotBlank()) doWebSearch()
    }

    private fun doWebSearch() {
        val q = webSearch.text.toString().trim()
        hideKeyboard(webSearch)
        val src = webSource
        val key = prefs.getString("jamendo", "") ?: ""
        if (src == 1 && key.isBlank()) { askJamendoKey(); return }
        dlAll.visibility = View.GONE
        if (src == 3 && q.isBlank()) {
            webItems = emptyList(); webAdapter.notifyDataSetChanged()
            webStatus.text = "Введите имя исполнителя и нажмите «Поиск» на клавиатуре"
            webStatus.visibility = View.VISIBLE
            return
        }
        webStatus.text = "Ищу…"
        webStatus.visibility = View.VISIBLE
        webItems = emptyList()
        webAdapter.notifyDataSetChanged()
        Thread {
            var res: List<WebMusic.Item>? = null
            var err = ""
            try {
                res = if (src == 3) WebMusic.searchArtists(q) else WebMusic.search(src, q, webGenre, key)
            } catch (e: JamendoKeyException) {
                prefs.edit().remove("jamendo").apply()
                err = "Ключ Jamendo не подошёл. Нажмите «Jamendo» и введите ключ заново."
            } catch (e: Exception) {
                err = "Нет соединения или сервис не отвечает."
            }
            runOnUiThread {
                if (webSource == src) {
                    val r = res
                    if (r == null) {
                        webStatus.text = err
                        webStatus.visibility = View.VISIBLE
                    } else if (r.isEmpty()) {
                        webStatus.text = "Ничего не найдено"
                        webStatus.visibility = View.VISIBLE
                    } else {
                        webStatus.visibility = View.GONE
                        webItems = r
                        webAdapter.notifyDataSetChanged()
                    }
                }
            }
        }.start()
    }

    private fun askJamendoKey() {
        val input = EditText(this).apply {
            hint = "Client ID"
            setSingleLine()
            setText(prefs.getString("jamendo", "") ?: "")
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Ключ Jamendo")
            .setMessage("Jamendo — музыка под лицензией Creative Commons. Нужен бесплатный ключ (Client ID): создайте приложение на devportal.jamendo.com и вставьте ключ сюда.")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("jamendo", input.text.toString().trim()).apply()
                doWebSearch()
            }
            .setNeutralButton("Открыть сайт") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://devportal.jamendo.com/"))) } catch (_: Exception) {}
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun openArtist(item: WebMusic.Item) {
        webStatus.text = "Загружаю треки…"
        webStatus.visibility = View.VISIBLE
        webItems = emptyList(); webAdapter.notifyDataSetChanged()
        Thread {
            val r: List<WebMusic.Item>? = try { WebMusic.artistTracks(item.id) } catch (_: Exception) { null }
            runOnUiThread {
                if (r == null) webStatus.text = "Не удалось загрузить треки"
                else if (r.isEmpty()) webStatus.text = "У этого автора нет треков"
                else {
                    webStatus.visibility = View.GONE
                    webItems = r; webAdapter.notifyDataSetChanged()
                    dlAll.visibility = View.VISIBLE
                    Toast.makeText(this, "Чтобы вернуться к списку, нажмите «Исполнители»", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun downloadAll() {
        for (it in webItems) {
            val u = it.url ?: continue
            if (it.source == 0 || it.source == 3) continue
            startDownload(webKey(it), u, it.title, it.artist)
        }
    }

    private fun showWebItems(items: List<WebMusic.Item>, err: String, mix: Boolean) {
        if (items.isEmpty()) {
            webStatus.text = if (err.isEmpty()) "Ничего не найдено" else err
            webStatus.visibility = View.VISIBLE
            dlAll.visibility = View.GONE
        } else {
            webStatus.visibility = View.GONE
            webItems = items; webAdapter.notifyDataSetChanged()
            dlAll.visibility = if (mix) View.VISIBLE else View.GONE
        }
    }

    private fun showMixPanel(msg: String) {
        webLoaded = true
        showWeb(true)
        webItems = emptyList(); webAdapter.notifyDataSetChanged()
        webStatus.text = msg
        webStatus.visibility = View.VISIBLE
        dlAll.visibility = View.GONE
    }

    private fun onWebItem(item: WebMusic.Item) {
        if (item.source == 3) openArtist(item)
        else if (item.source == 0) openArchiveItem(item)
        else {
            val u = item.url
            if (u != null) startDownload(webKey(item), u, item.title, item.artist)
            else Toast.makeText(this, "Автор закрыл скачивание этого трека", Toast.LENGTH_LONG).show()
        }
    }

    private fun webKey(it: WebMusic.Item) = (if (it.source == 1) "j:" else "x:") + it.id

    private fun fmtSec(sec: Int): String = if (sec > 0) fmt(sec * 1000) else ""

    private fun openArchiveItem(item: WebMusic.Item) {
        Toast.makeText(this, "Загружаю список треков…", Toast.LENGTH_SHORT).show()
        Thread {
            val files: List<WebMusic.FileItem>? = try { WebMusic.archiveFiles(item.id) } catch (e: Exception) { null }
            runOnUiThread {
                if (files == null) Toast.makeText(this, "Не удалось загрузить список", Toast.LENGTH_SHORT).show()
                else if (files.isEmpty()) Toast.makeText(this, "В этой записи нет mp3-треков", Toast.LENGTH_SHORT).show()
                else Sheet(this).show(item.title, files.map { f ->
                    Sheet.Row(R.drawable.ic_download, f.title, fmtSec(f.durationSec)) {
                        startDownload("a:" + item.id + "/" + f.name, f.url, f.title, item.artist)
                    }
                })
            }
        }.start()
    }

    private fun startDownload(key: String, url: String, title: String, artist: String) {
        if (webProgress.containsKey(key)) return
        if (webDone.contains(key)) {
            Toast.makeText(this, "Уже скачано", Toast.LENGTH_SHORT).show()
            return
        }
        webProgress[key] = 0
        webAdapter.notifyDataSetChanged()
        Toast.makeText(this, "Скачиваю: $title", Toast.LENGTH_SHORT).show()
        dlPool.execute {
            var last = -1
            val id = WebMusic.download(applicationContext, url, title, artist) { p ->
                if (p != last) {
                    last = p
                    runOnUiThread { webProgress[key] = p; webAdapter.notifyDataSetChanged() }
                }
            }
            runOnUiThread {
                webProgress.remove(key)
                if (id != null) {
                    webDone.add(key)
                    Toast.makeText(this, "Скачано и добавлено в «Загрузки»", Toast.LENGTH_LONG).show()
                    loadLibrary()
                } else {
                    Toast.makeText(this, "Не удалось скачать", Toast.LENGTH_SHORT).show()
                }
                webAdapter.notifyDataSetChanged()
            }
        }
    }

    private inner class WebAdapter : BaseAdapter() {
        override fun getCount() = webItems.size
        override fun getItem(p: Int) = webItems[p]
        override fun getItemId(p: Int) = p.toLong()

        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val h: WHolder
            if (cv == null) {
                row = LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(8), dpi(10), dpi(8), dpi(10))
                }
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                val tt = text(16f, Theme.TEXT).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                val sub = text(13f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                val st = text(13f, NEON, true)
                col.addView(tt); col.addView(sub)
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(st, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dpi(10) })
                h = WHolder(tt, sub, st)
                row.tag = h
            } else {
                row = cv as LinearLayout
                h = row.tag as WHolder
            }
            val it = webItems[p]
            h.title.text = it.title
            h.sub.text = listOf(it.artist, fmtSec(it.durationSec)).filter { x -> x.isNotEmpty() }.joinToString(" · ")
            if (it.source == 0) h.state.text = "Треки ›"
            else if (it.source == 3) h.state.text = "Открыть ›"
            else {
                val key = webKey(it)
                val pr = webProgress[key]
                h.state.text = if (pr != null) "$pr%" else if (webDone.contains(key)) "✓" else if (it.url == null) "—" else "Скачать"
            }
            return row
        }
    }

    // ---------- воспроизведение / обновление экрана ----------

    private fun ensureStarted() {
        val i = Intent(this, PlayerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun onPlayPressed() {
        val s = svc ?: return
        if (s.current == null) {
            val src = if (shown.isNotEmpty()) shown else all
            if (src.isNotEmpty()) { ensureStarted(); s.setQueue(src, 0, true) } else showLibrary(true)
        } else { ensureStarted(); s.toggle() }
    }

    private fun loadLyrics(t: Track?) {
        lrc = emptyList()
        lastLyricKey = -3
        if (t == null) return
        val local = Lrc.load(t.path)
        if (local.isNotEmpty()) { lrc = local; return }
        val cached = LyricsFetcher.cached(this, t)
        if (cached != null) { lrc = Lrc.parse(cached); return }
        if (!onlineLyrics) return
        LyricsFetcher.fetch(applicationContext, t) { txt ->
            runOnUiThread {
                if (shownTrackId == t.id && txt != null) { lrc = Lrc.parse(txt); lastLyricKey = -3 }
            }
        }
    }

    private fun refresh() {
        val s = svc ?: return
        val t = s.current
        if ((t?.id ?: -1L) != shownTrackId) {
            shownTrackId = t?.id ?: -1L
            titleSmall.text = t?.title ?: "ZXCMUSS"
            artistSmall.text = t?.artist ?: "Музыкальный плеер"
            lastSec = -1
            viz.spectrum = null
            if (t != null) {
                val sp = Analyzer.cached(t.id)
                if (sp != null) viz.spectrum = sp else Analyzer.request(applicationContext, t)
            }
            loadLyrics(t)
            loadCover(t)
            if (lrc.isEmpty()) lyric.text = t?.title ?: "Выберите трек"
            adapter.notifyDataSetChanged()
        }
        val playing = s.isPlaying
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        miniPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        shuffleBtn.setColorFilter(if (s.shuffle) NEON else DIM)
        repeatBtn.setImageResource(if (s.repeat == 2) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatBtn.setColorFilter(if (s.repeat != 0) NEON else DIM)
        val fav = t != null && t.id in favs
        heartBtn.setImageResource(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
        heartBtn.setColorFilter(if (fav) NEON else Theme.TEXT)
        mini.visibility = if (t != null) View.VISIBLE else View.GONE
        miniTitle.text = t?.title ?: ""
        miniSub.text = t?.artist ?: ""
    }

    private fun fmt(ms: Int): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    /** Вызывается каждый кадр: визуализатор, змейка, фон, раз в 4 кадра — тексты. */
    private fun onFrame() {
        if (libPanel.visibility == View.VISIBLE || webPanel.visibility == View.VISIBLE) return
        frameN++
        val s = svc
        val pos = s?.position ?: 0
        val dur = s?.duration ?: 0
        val playing = s?.isPlaying == true

        viz.step(pos, playing)
        eq.set(viz.bass, viz.mid, viz.high, (viz.mid + viz.high) / 2f)
        if (dur > 0) snake.setProgress(pos.toFloat() / dur)
        snake.frame(playing)
        wave.feed(viz.bass, viz.bassRaw)
        if (frameN % 2 == 0) {
            aurora.energy += (viz.bass - aurora.energy) * 0.3f
            aurora.invalidate()
        }
        if (frameN % 4 == 0) {
            val sec = pos / 1000
            if (sec != lastSec && !snake.dragging) {
                lastSec = sec
                timeL.text = fmt(pos)
                timeR.text = "-" + fmt(dur - pos)
            }
            updateLyrics(pos)
        }
    }

    private fun updateLyrics(pos: Int) {
        if (lrc.isEmpty()) return
        val i = lrc.indexOfLast { it.t <= pos }
        if (i < 0) {
            if (lastLyricKey != -1) { lastLyricKey = -1; lyric.text = "♪" }
            return
        }
        val line = lrc[i]
        val end = lrc.getOrNull(i + 1)?.t ?: (line.t + 4000)
        val words = line.text.split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return
        val frac = (pos - line.t).toFloat() / (end - line.t).coerceAtLeast(1)
        val w = (frac * words.size).toInt().coerceIn(0, words.size - 1)
        val key = i * 1000 + w
        if (key == lastLyricKey) return
        lastLyricKey = key
        val sb = SpannableStringBuilder()
        val shownWords = if (prefs.getBoolean("lyricHide", false)) words.subList(0, w + 1) else words
        shownWords.forEachIndexed { idx, word ->
            val st = sb.length
            sb.append(word)
            val en = sb.length
            if (idx > w) sb.setSpan(ForegroundColorSpan(Theme.LYRIC_DIM), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(PillSpan(dp(5f), dp(1.5f), idx == w), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (idx < shownWords.size - 1) sb.append(" ")
        }
        lyric.text = sb
    }

    // ---------- список треков ----------

    private class Holder(val title: TextView, val sub: TextView, val heart: ImageButton)

    private inner class TrackAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = shown[p].id

        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val h: Holder
            if (cv == null) {
                row = LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(8), dpi(6), dpi(2), dpi(6))
                }
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                val tt = text(16f, Theme.TEXT).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                val sub = text(13f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                col.addView(tt); col.addView(sub)
                val heart = ImageButton(this@MainActivity).apply {
                    background = ripple()
                    scaleType = ImageView.ScaleType.CENTER
                    isFocusable = false
                    layoutParams = LinearLayout.LayoutParams(dpi(46), dpi(46))
                    setOnClickListener { v -> val pos = v.tag as? Int; if (pos != null && pos in shown.indices) toggleFav(shown[pos].id) }
                }
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(heart)
                h = Holder(tt, sub, heart)
                row.tag = h
            } else {
                row = cv as LinearLayout
                h = row.tag as Holder
            }
            val t = shown[p]
            val cur = t.id == svc?.current?.id
            val fav = t.id in favs
            h.title.text = t.title
            h.title.setTextColor(if (cur) NEON else Theme.TEXT)
            h.sub.text = "${t.artist} · ${fmt(t.durationMs.toInt())}" + (if (t.year.isNotBlank()) " · ${t.year}" else "")
            h.heart.tag = p
            h.heart.setImageResource(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
            h.heart.setColorFilter(if (fav) NEON else Theme.HEART_OFF)
            return row
        }
    }
}
