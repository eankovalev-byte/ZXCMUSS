package com.zxcmuss.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val MINT = 0xFFD9F5E6.toInt()
    private val GREEN = 0xFF3DDC97.toInt()
    private val DIM = 0x99FFFFFF.toInt()

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var svc: PlayerService? = null

    private var all: List<Track> = emptyList()
    private var shown: List<Track> = emptyList()
    private var sortMode = 0
    private var lrc: List<Lrc.Line> = emptyList()
    private var shownTrackId = -2L
    private var lastLyricKey = -3
    private var lastSec = -1

    // views
    private lateinit var bokeh: BokehView
    private lateinit var titleSmall: TextView
    private lateinit var artistSmall: TextView
    private lateinit var counter: TextView
    private lateinit var lyric: TextView
    private lateinit var wave: WaveView
    private lateinit var seek: SeekLine
    private lateinit var timeL: TextView
    private lateinit var timeR: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var shuffleBtn: ImageButton
    private lateinit var repeatBtn: ImageButton
    private lateinit var libPanel: LinearLayout
    private lateinit var libCount: TextView
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var emptyBtn: Button
    private val adapter = TrackAdapter()

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = (b as PlayerService.LocalBinder).service.also { it.onChange = { refresh() } }
            restoreLast()
            refresh()
        }
        override fun onServiceDisconnected(n: ComponentName?) { svc = null }
    }

    private val tickRun = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 66) }
    }

    // ---------- жизненный цикл ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("zx", MODE_PRIVATE)
        sortMode = prefs.getInt("sort", 0)
        setContentView(buildUi())
        if (hasAudioPerm()) loadLibrary() else { requestPerms(); showLibrary(true) }
        updateEmpty()
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PlayerService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        bokeh.running = true
        handler.post(tickRun)
    }

    override fun onPause() {
        bokeh.running = false
        handler.removeCallbacks(tickRun)
        super.onPause()
    }

    override fun onStop() {
        svc?.onChange = null
        try { unbindService(conn) } catch (_: Exception) {}
        svc = null
        super.onStop()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (libPanel.visibility == View.VISIBLE) showLibrary(false) else super.onBackPressed()
    }

    // ---------- разрешения ----------

    private fun audioPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPerm() = checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        prefs.edit().putBoolean("asked", true).apply()
        val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm())
        requestPermissions(p, 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasAudioPerm()) loadLibrary()
        updateEmpty()
    }

    // ---------- медиатека ----------

    private fun loadLibrary() {
        Thread {
            val l = Library.load(this)
            runOnUiThread { all = l; applyFilter(); restoreLast() }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val sorted = when (sortMode) {
            0 -> all.sortedBy { it.title.lowercase() }
            1 -> all.sortedBy { it.artist.lowercase() }
            else -> all.sortedByDescending { it.dateAdded }
        }
        shown = if (q.isEmpty()) sorted else sorted.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        libCount.text = "${shown.size} из ${all.size} треков"
        updateEmpty()
    }

    private fun updateEmpty() {
        if (!::emptyBox.isInitialized) return
        val perm = hasAudioPerm()
        emptyBox.visibility = if (!perm || shown.isEmpty()) View.VISIBLE else View.GONE
        if (!perm) {
            emptyText.text = "ZXCMUSS нужен доступ к музыке на устройстве, чтобы показать ваши треки."
            emptyBtn.text = "Дать доступ"
            emptyBtn.visibility = View.VISIBLE
        } else if (all.isEmpty()) {
            emptyText.text = "Музыка не найдена. Положите mp3 в папку Music или Download и нажмите ⋮ → «Обновить библиотеку»."
            emptyBtn.visibility = View.GONE
        } else {
            emptyText.text = "Ничего не найдено"
            emptyBtn.visibility = View.GONE
        }
    }

    private fun restoreLast() {
        val s = svc ?: return
        if (s.queue.isNotEmpty() || shown.isEmpty()) return
        val id = prefs.getLong("lastId", -1)
        val idx = shown.indexOfFirst { it.id == id }
        if (idx >= 0) s.setQueue(shown, idx, false, prefs.getInt("lastPos", 0))
    }

    private fun rescan() {
        Toast.makeText(this, "Обновляю библиотеку…", Toast.LENGTH_SHORT).show()
        Thread {
            val exts = setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma")
            val paths = ArrayList<String>()
            for (d in listOf(Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_DOWNLOADS)) {
                try {
                    Environment.getExternalStoragePublicDirectory(d).walkTopDown().maxDepth(5)
                        .filter { it.isFile && it.extension.lowercase() in exts }.forEach { paths.add(it.path) }
                } catch (_: Exception) {}
            }
            if (paths.isNotEmpty()) MediaScannerConnection.scanFile(this, paths.toTypedArray(), null, null)
            handler.postDelayed({ if (hasAudioPerm()) loadLibrary() }, 1500)
        }.start()
    }

    // ---------- UI ----------

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Int) = dp(v.toFloat()).toInt()

    private fun ripple(): Drawable? {
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        val d = a.getDrawable(0); a.recycle(); return d
    }

    private fun iconBtn(res: Int, size: Int, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(res)
        background = ripple()
        scaleType = ImageView.ScaleType.CENTER
        setColorFilter(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(dpi(size), dpi(size))
        setOnClickListener { onClick() }
    }

    private fun text(sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = false
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        bokeh = BokehView(this)
        root.addView(bokeh, ViewGroup.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // верхняя панель
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(20), dpi(8), dpi(8), 0)
        }
        top.addView(text(15f, Color.WHITE, true).apply { this.text = "ZXCMUSS"; letterSpacing = 0.25f },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(iconBtn(R.drawable.ic_library, 48) { showLibrary(true) })
        top.addView(iconBtn(R.drawable.ic_more, 48) { showMenu() })
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        // стеклянная карточка
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(20), dpi(16), dpi(20), dpi(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(28f)
                setColor(0x66080F0B)
                setStroke(dpi(1), 0x33FFFFFF)
            }
        }
        val head = LinearLayout(this)
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleSmall = text(11f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        artistSmall = text(10f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        names.addView(titleSmall); names.addView(artistSmall)
        counter = text(11f, DIM)
        head.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(counter)
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        lyric = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 27f)
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setLineSpacing(0f, 1.12f)
            minLines = 3; maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            text = "Выберите трек"
        }
        card.addView(lyric, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dpi(14); bottomMargin = dpi(14) })

        wave = WaveView(this)
        card.addView(wave, LinearLayout.LayoutParams(-1, dpi(46)))
        seek = SeekLine(this).apply {
            onSeek = { f -> svc?.let { it.seekTo((f * it.duration).toInt()) } }
        }
        card.addView(seek, LinearLayout.LayoutParams(-1, dpi(26)))
        val times = LinearLayout(this)
        timeL = text(9f, DIM).apply { text = "0:00" }
        timeR = text(9f, DIM).apply { text = "-0:00"; gravity = Gravity.END }
        times.addView(timeL, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(timeR, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(times, LinearLayout.LayoutParams(-1, -2))
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dpi(14); rightMargin = dpi(14) })

        // кнопки управления
        val ctr = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dpi(26), 0, 0) }
        shuffleBtn = iconBtn(R.drawable.ic_shuffle, 52) { svc?.let { it.setShuffle(!it.shuffle) } }
        val prev = iconBtn(R.drawable.ic_prev, 56) { svc?.prev() }
        playBtn = iconBtn(R.drawable.ic_play, 72) { onPlayPressed() }.apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(MINT) }
            setColorFilter(0xFF04140B.toInt())
        }
        val next = iconBtn(R.drawable.ic_next, 56) { svc?.next() }
        repeatBtn = iconBtn(R.drawable.ic_repeat, 52) { svc?.cycleRepeat() }
        for (v in listOf(shuffleBtn, prev, playBtn, next, repeatBtn)) {
            ctr.addView(v); (v.layoutParams as LinearLayout.LayoutParams).setMargins(dpi(4), 0, dpi(4), 0)
        }
        col.addView(ctr, LinearLayout.LayoutParams(-1, -2))
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1.3f))

        // панель медиатеки
        libPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF2030805.toInt())
            visibility = View.GONE
            isClickable = true
            setPadding(dpi(16), dpi(8), dpi(16), 0)
        }
        val lh = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val lt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lt.addView(text(22f, Color.WHITE, true).apply { text = "Музыка" })
        libCount = text(12f, DIM); lt.addView(libCount)
        lh.addView(lt, LinearLayout.LayoutParams(0, -2, 1f))
        lh.addView(iconBtn(R.drawable.ic_more, 48) { showMenu() })
        lh.addView(iconBtn(R.drawable.ic_close, 48) { showLibrary(false) })
        libPanel.addView(lh, LinearLayout.LayoutParams(-1, dpi(56)))

        search = EditText(this).apply {
            hint = "Поиск"
            setHintTextColor(0x66FFFFFF)
            setTextColor(Color.WHITE)
            setSingleLine()
            setPadding(dpi(16), 0, dpi(16), 0)
            background = GradientDrawable().apply { cornerRadius = dp(22f); setColor(0x22FFFFFF) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        libPanel.addView(search, LinearLayout.LayoutParams(-1, dpi(44)).apply { bottomMargin = dpi(8) })

        val frame = FrameLayout(this)
        list = ListView(this).apply {
            divider = null; adapter = this@MainActivity.adapter
            isFastScrollEnabled = true
            setOnItemClickListener { _, _, pos, _ ->
                hideKeyboard()
                if (pos in shown.indices) {
                    ensureStarted()
                    svc?.setQueue(shown, pos, true)
                    showLibrary(false)
                }
            }
        }
        frame.addView(list, FrameLayout.LayoutParams(-1, -1))
        emptyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dpi(24), 0, dpi(24), 0) }
        emptyText = text(15f, DIM).apply { gravity = Gravity.CENTER }
        emptyBtn = Button(this).apply {
            setOnClickListener {
                if (!hasAudioPerm()) {
                    if (prefs.getBoolean("asked", false) && !shouldShowRequestPermissionRationale(audioPerm()))
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    else requestPerms()
                }
            }
        }
        emptyBox.addView(emptyText); emptyBox.addView(emptyBtn)
        frame.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        libPanel.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(libPanel, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private fun showLibrary(on: Boolean) {
        libPanel.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) hideKeyboard() else adapter.notifyDataSetChanged()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun showMenu() {
        dialog().setItems(arrayOf("Сортировка", "Таймер сна", "Обновить библиотеку", "О приложении")) { _, w ->
            when (w) {
                0 -> dialog().setTitle("Сортировка").setItems(arrayOf("По названию", "По исполнителю", "Недавно добавленные")) { _, i ->
                    sortMode = i; prefs.edit().putInt("sort", i).apply(); applyFilter()
                }.show()
                1 -> dialog().setTitle("Таймер сна").setItems(arrayOf("Выключить", "15 минут", "30 минут", "45 минут", "60 минут")) { _, i ->
                    val m = intArrayOf(0, 15, 30, 45, 60)[i]
                    svc?.setSleepTimer(m)
                    Toast.makeText(this, if (m == 0) "Таймер выключен" else "Остановка через $m мин", Toast.LENGTH_SHORT).show()
                }.show()
                2 -> if (hasAudioPerm()) rescan() else requestPerms()
                3 -> dialog().setTitle("ZXCMUSS 1.0").setMessage(
                    "Как добавить музыку: скачайте mp3 любым способом (браузер, мессенджер, загрузчик) в папку Download или Music — " +
                        "плеер сам найдёт треки на устройстве. Нажмите «Обновить библиотеку», если трек не появился.\n\n" +
                        "Тексты песен: положите файл .lrc с тем же именем рядом с треком."
                ).setPositiveButton("OK", null).show()
            }
        }.show()
    }

    // ---------- воспроизведение / обновление экрана ----------

    private fun ensureStarted() {
        val i = Intent(this, PlayerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun onPlayPressed() {
        val s = svc ?: return
        if (s.current == null) {
            if (shown.isNotEmpty()) { ensureStarted(); s.setQueue(shown, 0, true) } else showLibrary(true)
        } else { ensureStarted(); s.toggle() }
    }

    private fun refresh() {
        val s = svc ?: return
        val t = s.current
        if ((t?.id ?: -1L) != shownTrackId) {
            shownTrackId = t?.id ?: -1L
            titleSmall.text = t?.title ?: "ZXCMUSS"
            artistSmall.text = t?.artist ?: "Музыкальный плеер"
            counter.text = if (t != null) "${s.index + 1} / ${s.queue.size}" else ""
            lrc = Lrc.load(t?.path)
            lastLyricKey = -3
            if (lrc.isEmpty()) lyric.text = t?.title ?: "Выберите трек"
            wave.setSeed(shownTrackId)
            adapter.notifyDataSetChanged()
        }
        playBtn.setImageResource(if (s.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        shuffleBtn.setColorFilter(if (s.shuffle) GREEN else DIM)
        repeatBtn.setImageResource(if (s.repeat == 2) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatBtn.setColorFilter(if (s.repeat != 0) GREEN else DIM)
        tick()
    }

    private fun fmt(ms: Int): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun tick() {
        val s = svc ?: return
        val dur = s.duration
        val pos = s.position
        if (dur > 0) seek.setProgress(pos.toFloat() / dur)
        val sec = pos / 1000
        if (sec != lastSec && !seek.dragging) {
            lastSec = sec
            timeL.text = fmt(pos)
            timeR.text = "-" + fmt(dur - pos)
        }
        wave.update(if (dur > 0) pos.toFloat() / dur else 0f, s.isPlaying)
        updateLyrics(pos)
    }

    private fun updateLyrics(pos: Int) {
        if (lrc.isEmpty()) return
        val i = lrc.indexOfLast { it.t <= pos }
        if (i < 0) {
            if (lastLyricKey != -1) { lastLyricKey = -1; lyric.text = "♪" }
            return
        }
        val line = lrc[i]
        val end = lrc.getOrNull(i + 1)?.t ?: (line.t + 4000)
        val words = line.text.split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return
        val frac = (pos - line.t).toFloat() / (end - line.t).coerceAtLeast(1)
        val w = (frac * words.size).toInt().coerceIn(0, words.size - 1)
        val key = i * 1000 + w
        if (key == lastLyricKey) return
        lastLyricKey = key
        val sb = SpannableStringBuilder()
        words.forEachIndexed { idx, word ->
            val st = sb.length
            sb.append(word)
            val en = sb.length
            if (idx == w) sb.setSpan(PillSpan(dp(8f), dp(2f)), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            else if (idx > w) sb.setSpan(ForegroundColorSpan(0x80FFFFFF.toInt()), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (idx < words.size - 1) sb.append(" ")
        }
        lyric.text = sb
    }

    // ---------- список треков ----------

    private inner class TrackAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = shown[p].id

        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val tt: TextView
            val sub: TextView
            if (cv == null) {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dpi(8), dpi(10), dpi(8), dpi(10))
                }
                tt = text(16f, Color.WHITE).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; tag = "t" }
                sub = text(13f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; tag = "s" }
                row.addView(tt); row.addView(sub)
            } else {
                row = cv as LinearLayout
                tt = row.findViewWithTag("t"); sub = row.findViewWithTag("s")
            }
            val t = shown[p]
            val cur = t.id == svc?.current?.id
            tt.text = t.title
            tt.setTextColor(if (cur) GREEN else Color.WHITE)
            sub.text = "${t.artist} · ${fmt(t.durationMs.toInt())}"
            return row
        }
    }
}
