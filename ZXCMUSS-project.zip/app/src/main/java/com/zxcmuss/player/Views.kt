package com.zxcmuss.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.style.ReplacementSpan
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

object Theme {
    val NEON = 0xFF2BFD89.toInt()
    val NEON_DARK = 0xFF00170A.toInt()
    val DIM = 0x99FFFFFF.toInt()
    val EDGE = 0x99B7F5D1.toInt()
}

/** Фон: чёрно-зелёная дымка как на видео, чуть «дышит» и пульсирует от баса. */
class AuroraView(c: Context) : View(c) {
    private val bg = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lg: LinearGradient? = null
    private val m = Matrix()
    var energy = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val stops = floatArrayOf(0f, .09f, .125f, .16f, .22f, .25f, .31f, .40f, .50f, .60f, .66f, .69f, .75f, .78f, .84f, .90f, 1f)
        val cols = intArrayOf(
            Color.rgb(0, 3, 0), Color.rgb(0, 11, 0), Color.rgb(0, 16, 2), Color.rgb(5, 25, 11),
            Color.rgb(12, 39, 21), Color.rgb(19, 51, 31), Color.rgb(8, 43, 22), Color.rgb(9, 44, 23),
            Color.rgb(2, 37, 16), Color.rgb(0, 27, 11), Color.rgb(0, 22, 6), Color.rgb(3, 28, 12),
            Color.rgb(23, 50, 34), Color.rgb(25, 52, 36), Color.rgb(1, 26, 10), Color.rgb(0, 17, 2), Color.rgb(0, 13, 0)
        )
        lg = LinearGradient(0f, 0f, 0f, h.toFloat(), cols, stops, Shader.TileMode.CLAMP)
        bg.shader = lg
        glow.shader = RadialGradient(
            w / 2f, h * 0.46f, w * 1.15f,
            Color.argb(255, 43, 253, 137), Color.argb(0, 43, 253, 137), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val t = System.nanoTime() / 1e9f
        m.setTranslate(0f, sin(t * 0.35f) * height * 0.012f)
        lg?.setLocalMatrix(m)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        glow.alpha = (10 + 70 * energy).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)
    }
}

/** «Таблетка» под текущим словом: рисуется вокруг слова, не сдвигая соседние. */
class PillSpan(private val padX: Float, private val padY: Float) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
        paint.measureText(text, start, end).toInt()

    override fun draw(canvas: Canvas, text: CharSequence, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val w = paint.measureText(text, start, end)
        val old = paint.color
        val fm = paint.fontMetrics
        val rect = RectF(x - padX, y + fm.ascent - padY, x + w + padX, y + fm.descent + padY)
        paint.color = Theme.NEON
        canvas.drawRoundRect(rect, rect.height() / 2.4f, rect.height() / 2.4f, paint)
        paint.color = Theme.NEON_DARK
        canvas.drawText(text, start, end, x, y.toFloat(), paint)
        paint.color = old
    }
}

/** Визуализатор: настоящий спектр трека, синхронно с позицией. Низкие частоты в центре. */
class SpectrumView(c: Context) : View(c) {
    var spectrum: Spectrum? = null
    private val n = Analyzer.BANDS
    private val level = FloatArray(n)
    var bass = 0f; private set
    var mid = 0f; private set
    var high = 0f; private set
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val d = resources.displayMetrics.density

    private fun avg(lo: Int, hi: Int): Float {
        var s = 0f
        for (i in lo until hi) s += level[i]
        return s / (hi - lo).coerceAtLeast(1)
    }

    fun step(posMs: Int, playing: Boolean) {
        val sp = spectrum
        val t = System.nanoTime() / 1e9f
        var f0 = 0
        var f1 = 0
        var fr = 0f
        val real = sp != null && sp.bands == n && sp.frames > 1
        if (sp != null && real) {
            val x = (posMs + 25) * sp.fps / 1000f
            f0 = x.toInt().coerceIn(0, sp.frames - 1)
            f1 = (f0 + 1).coerceAtMost(sp.frames - 1)
            fr = (x - f0).coerceIn(0f, 1f)
        }
        for (i in 0 until n) {
            val target: Float = when {
                !playing -> 0f
                real && sp != null -> {
                    val a = (sp.data[f0 * n + i].toInt() and 0xFF) / 255f
                    val b = (sp.data[f1 * n + i].toInt() and 0xFF) / 255f
                    a + (b - a) * fr
                }
                else -> 0.2f + 0.16f * (0.5f + 0.5f * sin(t * 4.5f + i * 0.55f))
            }
            val cur = level[i]
            level[i] = if (target > cur) cur + (target - cur) * 0.6f else cur + (target - cur) * 0.14f
        }
        bass = avg(0, n / 9)
        mid = avg(n * 3 / 9, n * 5 / 9)
        high = avg(n * 6 / 9, n)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / (n * 2)
        paint.strokeWidth = step * 0.46f
        val cx = w / 2f
        val minH = 3f * d
        for (i in 0 until n) {
            val l = level[i].coerceIn(0f, 1f)
            val bh = minH + (h - minH) * l.pow(0.9f)
            paint.color = Color.argb((100 + 155 * l).toInt().coerceAtMost(255), 43, 253, 137)
            val dx = step * (i + 0.5f)
            canvas.drawLine(cx - dx, (h - bh) / 2f, cx - dx, (h + bh) / 2f, paint)
            canvas.drawLine(cx + dx, (h - bh) / 2f, cx + dx, (h + bh) / 2f, paint)
        }
    }
}

/** Мини-эквалайзер в углу карточки (как на видео). */
class MiniEq(c: Context) : View(c) {
    private val v = FloatArray(4) { 0.3f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; color = Theme.NEON }
    private val d = resources.displayMetrics.density

    fun set(a: Float, b: Float, c2: Float, e: Float) {
        v[0] = a; v[1] = b; v[2] = c2; v[3] = e
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        paint.strokeWidth = 3f * d
        val gap = width / 4f
        for (i in 0 until 4) {
            val bh = 4f * d + (h - 4f * d) * v[i].coerceIn(0f, 1f)
            val x = gap * (i + 0.5f)
            canvas.drawLine(x, (h - bh) / 2f, x, (h + bh) / 2f, paint)
        }
    }
}

/** Полоска трека-«змейка»: волнистая пройденная часть, прямая оставшаяся, маркер на позиции. */
class SnakeSeek(c: Context) : View(c) {
    private var progress = 0f
    var dragging = false
        private set
    var onSeek: ((Float) -> Unit)? = null
    private var phase = 0f
    private var amp = 0f
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun setProgress(p: Float) { if (!dragging) progress = p.coerceIn(0f, 1f) }

    fun frame(playing: Boolean) {
        val target = if (dragging) 3.4f * d else if (playing) 2.6f * d else 0.9f * d
        amp += (target - amp) * 0.12f
        if (playing || dragging) phase += 0.9f * d
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height / 2f
        val pad = 6f * d
        val w = width - 2 * pad
        val xp = pad + w * progress
        val k = (2.0 * PI / (16f * d)).toFloat()

        line.strokeWidth = 1.6f * d
        line.color = Color.argb(95, 170, 225, 195)
        canvas.drawLine(xp, cy, pad + w, cy, line)

        path.reset()
        var x = pad
        path.moveTo(x, cy + amp * sin((x - phase) * k))
        while (x < xp) {
            x += 2.5f * d
            val xx = if (x > xp) xp else x
            path.lineTo(xx, cy + amp * sin((xx - phase) * k))
        }
        line.strokeWidth = 7f * d
        line.color = Color.argb(46, 43, 253, 137)
        canvas.drawPath(path, line)
        line.strokeWidth = 2.4f * d
        line.color = Theme.NEON
        canvas.drawPath(path, line)

        val mh = if (dragging) 24f * d else 17f * d
        line.strokeWidth = 3.4f * d
        canvas.drawLine(xp, cy - mh / 2f, xp, cy + mh / 2f, line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pad = 6f * d
        val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent.requestDisallowInterceptTouchEvent(true); dragging = true; progress = f }
            MotionEvent.ACTION_MOVE -> progress = f
            MotionEvent.ACTION_UP -> { dragging = false; progress = f; onSeek?.invoke(f) }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        invalidate()
        return true
    }
}
