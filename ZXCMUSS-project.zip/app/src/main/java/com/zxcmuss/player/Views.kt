package com.zxcmuss.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.style.ReplacementSpan
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin
import java.util.Random

/** Фон: медленно плывущие размытые зелёные круги («боке») на чёрном. */
class BokehView(c: Context) : View(c) {
    private class Blob(val x: Float, val y: Float, val r: Float, val color: Int, val sx: Float, val sy: Float, val ph: Float) {
        var paint: Paint? = null
    }

    private val blobs = listOf(
        Blob(0.78f, 0.10f, 0.20f, 0xFF0E6B35.toInt(), 0.31f, 0.23f, 0.0f),
        Blob(0.30f, 0.14f, 0.17f, 0xFF117A4B.toInt(), 0.27f, 0.35f, 1.7f),
        Blob(0.22f, 0.36f, 0.21f, 0xFF16905F.toInt(), 0.22f, 0.29f, 3.1f),
        Blob(0.80f, 0.42f, 0.24f, 0xFF1FB07F.toInt(), 0.19f, 0.25f, 4.4f),
        Blob(0.15f, 0.72f, 0.20f, 0xFF0E5E30.toInt(), 0.33f, 0.21f, 2.2f),
        Blob(0.62f, 0.78f, 0.26f, 0xFF1A8F6A.toInt(), 0.24f, 0.30f, 5.3f),
        Blob(0.90f, 0.93f, 0.18f, 0xFF22C58A.toInt(), 0.28f, 0.26f, 0.9f)
    )
    var running = false
        set(v) { field = v; if (v) postInvalidateOnAnimation() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val base = min(w, h).toFloat()
        for (b in blobs) {
            val r = b.r * base * 1.6f
            b.paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    0f, 0f, r, intArrayOf(b.color, b.color, b.color and 0x00FFFFFF),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF020604.toInt())
        val t = System.nanoTime() / 1e9f
        val base = min(width, height).toFloat()
        for (b in blobs) {
            val p = b.paint ?: continue
            val cx = (b.x + 0.05f * sin(t * b.sx + b.ph)) * width
            val cy = (b.y + 0.04f * sin(t * b.sy + b.ph * 1.3f)) * height
            canvas.save(); canvas.translate(cx, cy)
            canvas.drawCircle(0f, 0f, b.r * base * 1.6f, p)
            canvas.restore()
        }
        if (running) postInvalidateDelayed(40)
    }
}

/** «Таблетка» под текущим словом: рисуется вокруг слова, не сдвигая соседние. */
class PillSpan(private val padX: Float, private val padY: Float) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
        paint.measureText(text, start, end).toInt()

    override fun draw(canvas: Canvas, text: CharSequence, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val w = paint.measureText(text, start, end)
        val old = paint.color
        val fm = paint.fontMetrics
        val rect = RectF(x - padX, y + fm.ascent - padY, x + w + padX, y + fm.descent + padY)
        paint.color = 0xFFD9F5E6.toInt()
        canvas.drawRoundRect(rect, rect.height() / 2.6f, rect.height() / 2.6f, paint)
        paint.color = 0xFF04140B.toInt()
        canvas.drawText(text, start, end, x, y.toFloat(), paint)
        paint.color = old
    }
}

/** Вертикальные штрихи-«волна». Высоты зависят от id трека и слегка пульсируют при игре. */
class WaveView(c: Context) : View(c) {
    private val n = 64
    private var base = FloatArray(n) { 0.5f }
    private var progress = 0f
    private var playing = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }

    fun setSeed(seed: Long) {
        val rnd = Random(seed)
        val raw = FloatArray(n) { 0.25f + rnd.nextFloat() * 0.75f }
        base = FloatArray(n) { i ->
            val a = raw[(i - 1).coerceAtLeast(0)]; val b = raw[i]; val d = raw[(i + 1).coerceAtMost(n - 1)]
            (a + 2 * b + d) / 4f
        }
        invalidate()
    }

    fun update(p: Float, isPlaying: Boolean) {
        progress = p; playing = isPlaying; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val step = w / n
        paint.strokeWidth = step * 0.34f
        val t = System.nanoTime() / 1e9
        for (i in 0 until n) {
            val pulse = if (playing) (0.72 + 0.28 * sin(t * 4.0 + i * 0.8)).toFloat() else 0.85f
            val bh = (h * 0.12f + h * 0.88f * base[i] * pulse).coerceAtMost(h)
            val x = step * (i + 0.5f)
            paint.color = if (i.toFloat() / n < progress) 0xFFFFFFFF.toInt() else 0x8CFFFFFF.toInt()
            canvas.drawLine(x, (h - bh) / 2f, x, (h + bh) / 2f, paint)
        }
    }
}

/** Тонкая линия прогресса с точкой. Перемотка касанием/перетаскиванием. */
class SeekLine(c: Context) : View(c) {
    private var progress = 0f
    var dragging = false
        private set
    var onSeek: ((Float) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    fun setProgress(p: Float) { if (!dragging) { progress = p.coerceIn(0f, 1f); invalidate() } }

    override fun onDraw(canvas: Canvas) {
        val cy = height / 2f
        val pad = 3 * d
        val w = width - 2 * pad
        paint.strokeWidth = 1.5f * d
        paint.color = 0x4DFFFFFF
        canvas.drawLine(pad, cy, pad + w, cy, paint)
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawLine(pad, cy, pad + w * progress, cy, paint)
        canvas.drawCircle(pad + w * progress, cy, (if (dragging) 5f else 3.2f) * d, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pad = 3 * d
        val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent.requestDisallowInterceptTouchEvent(true); dragging = true; progress = f }
            MotionEvent.ACTION_MOVE -> progress = f
            MotionEvent.ACTION_UP -> { dragging = false; progress = f; onSeek?.invoke(f) }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        invalidate()
        return true
    }
}
