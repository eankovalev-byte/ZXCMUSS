package com.zxcmuss.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.SweepGradient
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.style.ReplacementSpan
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** Фон: дымка, пульсирует от баса. Поверх — плавающие смайлики и погодные эффекты (дождь, снег, звёзды, светлячки). */
class AuroraView(c: Context) : View(c) {
    private val bg = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lg: LinearGradient? = null
    private val m = Matrix()
    var energy = 0f

    /** -1 — смайлики выключены, иначе номер набора */
    var emojiSet = -1
    /** 0 — нет, 1 — дождь, 2 — снег, 3 — звёзды, 4 — светлячки */
    var bgMode = 0

    private class Pt(var x: Float, var y: Float, var vx: Float, var vy: Float, var s: Float, var ph: Float,
                     var ch: String = "", var rot: Float = 0f, var rs: Float = 0f)

    private val d = c.resources.displayMetrics.density
    private val emos = ArrayList<Pt>()
    private val bgp = ArrayList<Pt>()
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val pp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(11)
    private var lastT = 0L

    companion object {
        val SET_NAMES = arrayOf("Микс", "Сердца", "Космос", "Природа", "Энергия")
        val SETS = arrayOf(
            arrayOf("\uD83C\uDFB5", "\uD83C\uDFB6", "\u2728", "\uD83D\uDCAB", "\u2B50", "\uD83D\uDD25", "\uD83C\uDF19", "\uD83C\uDFA7", "\uD83D\uDCBF", "\uD83C\uDF38", "\u2764\uFE0F", "\uD83C\uDF40"),
            arrayOf("\u2764\uFE0F", "\uD83D\uDC9C", "\uD83D\uDC99", "\uD83D\uDC9A", "\uD83D\uDC9B", "\uD83E\uDDE1", "\uD83D\uDDA4", "\uD83E\uDD0D", "\uD83D\uDC96", "\uD83D\uDC97", "\uD83D\uDC9E"),
            arrayOf("\u2B50", "\uD83C\uDF1F", "\u2728", "\uD83D\uDCAB", "\uD83C\uDF19", "\uD83E\uDE90", "\u2604\uFE0F", "\uD83C\uDF20", "\uD83D\uDE80"),
            arrayOf("\uD83C\uDF38", "\uD83C\uDF40", "\uD83C\uDF3F", "\uD83C\uDF43", "\uD83C\uDF3A", "\uD83E\uDD8B", "\uD83C\uDF3B", "\uD83C\uDF42", "\u2744\uFE0F", "\uD83C\uDF0A"),
            arrayOf("\uD83D\uDD25", "\u26A1", "\uD83D\uDCA5", "\u2728", "\uD83C\uDFB8", "\uD83E\uDD41", "\uD83C\uDFA4", "\uD83C\uDFA7", "\uD83D\uDCBF", "\uD83C\uDFB6")
        )
        val BG_NAMES = arrayOf("Нет", "Дождь", "Снег", "Звёзды", "Светлячки")
    }

    private fun r(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    fun rebuild() {
        emos.clear(); bgp.clear()
        if (width == 0) return
        val w = width.toFloat(); val h = height.toFloat()
        if (emojiSet in SETS.indices) {
            val set = SETS[emojiSet]
            repeat(16) {
                emos.add(Pt(r(0f, w), r(0f, h), r(-7f, 7f) * d, r(-9f, 4f) * d, r(15f, 30f) * d, r(0f, 6.28f),
                    set[rnd.nextInt(set.size)], r(-25f, 25f), r(-6f, 6f)))
            }
        }
        when (bgMode) {
            1 -> repeat(80) { bgp.add(Pt(r(0f, w), r(0f, h), r(-70f, -40f) * d, r(650f, 1100f) * d, r(14f, 30f) * d, r(0f, 1f))) }
            2 -> repeat(70) { bgp.add(Pt(r(0f, w), r(0f, h), r(-12f, 12f) * d, r(28f, 70f) * d, r(1.5f, 4f) * d, r(0f, 6.28f))) }
            3 -> repeat(85) { bgp.add(Pt(r(0f, w), r(0f, h * 0.9f), 0f, 0f, r(0.7f, 2.1f) * d, r(0f, 6.28f))) }
            4 -> repeat(24) { bgp.add(Pt(r(0f, w), r(0f, h), r(-18f, 18f) * d, r(-18f, 18f) * d, r(2f, 4.2f) * d, r(0f, 6.28f))) }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        lg = LinearGradient(0f, 0f, 0f, h.toFloat(), Theme.BG_STOPS, Theme.STOPS, Shader.TileMode.CLAMP)
        bg.shader = lg
        val a = Theme.NEON
        glow.shader = RadialGradient(
            w / 2f, h * 0.46f, w * 1.15f,
            Color.argb(255, Color.red(a), Color.green(a), Color.blue(a)),
            Color.argb(0, Color.red(a), Color.green(a), Color.blue(a)), Shader.TileMode.CLAMP
        )
        rebuild()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val t = now / 1e9f
        val dt = if (lastT == 0L) 0.033f else ((now - lastT) / 1e9f).coerceIn(0f, 0.06f)
        lastT = now
        m.setTranslate(0f, sin(t * 0.35f) * height * 0.012f)
        lg?.setLocalMatrix(m)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        glow.alpha = ((10 + 70 * energy) * Theme.GLOW).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)

        val w = width.toFloat(); val h = height.toFloat()
        val en = (energy * 1.6f).coerceIn(0f, 1f)
        val fxCol = if (Theme.LIGHT) Theme.NEON else Color.WHITE

        when (bgMode) {
            1 -> {
                pp.style = Paint.Style.STROKE
                pp.strokeWidth = 1.3f * d
                pp.strokeCap = Paint.Cap.ROUND
                for (p in bgp) {
                    p.x += p.vx * dt * (1f + en * 0.5f); p.y += p.vy * dt * (1f + en * 0.5f)
                    if (p.y > h + p.s) { p.y = -p.s; p.x = r(0f, w + 80f * d) }
                    if (p.x < -20f * d) p.x += w + 40f * d
                    val k = p.s / p.vy
                    pp.color = fxCol
                    pp.alpha = (60 + 90 * p.ph + 50 * en).toInt().coerceIn(0, 255)
                    canvas.drawLine(p.x, p.y, p.x + p.vx * k, p.y + p.s, pp)
                }
            }
            2 -> {
                pp.style = Paint.Style.FILL
                for (p in bgp) {
                    p.y += p.vy * dt; p.x += (p.vx + sin(t * 0.7f + p.ph) * 14f * d) * dt
                    if (p.y > h + 10f) { p.y = -10f; p.x = r(0f, w) }
                    if (p.x < -10f) p.x = w + 10f
                    if (p.x > w + 10f) p.x = -10f
                    pp.color = fxCol
                    pp.alpha = (150 + 60 * en).toInt().coerceIn(0, 255)
                    canvas.drawCircle(p.x, p.y, p.s * (1f + en * 0.25f), pp)
                }
            }
            3 -> {
                pp.style = Paint.Style.FILL
                for (p in bgp) {
                    val tw = 0.5f + 0.5f * sin(t * (0.8f + p.s * 0.2f) + p.ph)
                    pp.color = fxCol
                    pp.alpha = (70 + 170 * tw * (0.7f + 0.3f * en)).toInt().coerceIn(0, 255)
                    canvas.drawCircle(p.x, p.y, p.s * (1f + en * 0.5f), pp)
                }
            }
            4 -> {
                for (p in bgp) {
                    p.x += (p.vx + sin(t * 0.5f + p.ph) * 10f * d) * dt
                    p.y += (p.vy + cos(t * 0.4f + p.ph * 1.3f) * 10f * d) * dt
                    if (p.x < -20f) p.x = w + 20f
                    if (p.x > w + 20f) p.x = -20f
                    if (p.y < -20f) p.y = h + 20f
                    if (p.y > h + 20f) p.y = -20f
                    val tw = 0.45f + 0.55f * sin(t * 0.9f + p.ph)
                    val rad = p.s * 4f * (1f + en * 0.6f)
                    val a = Theme.NEON
                    pp.style = Paint.Style.FILL
                    pp.shader = RadialGradient(p.x, p.y, rad,
                        Color.argb((200 * tw.coerceIn(0.1f, 1f)).toInt(), Color.red(a), Color.green(a), Color.blue(a)),
                        Color.argb(0, Color.red(a), Color.green(a), Color.blue(a)), Shader.TileMode.CLAMP)
                    canvas.drawCircle(p.x, p.y, rad, pp)
                    pp.shader = null
                }
            }
        }

        if (emos.isNotEmpty()) {
            for (e in emos) {
                e.x += (e.vx + sin(t * 0.5f + e.ph) * 6f * d) * dt
                e.y += (e.vy + cos(t * 0.4f + e.ph) * 5f * d) * dt
                val mg = e.s
                if (e.x < -mg) e.x = w + mg
                if (e.x > w + mg) e.x = -mg
                if (e.y < -mg) e.y = h + mg
                if (e.y > h + mg) e.y = -mg
                e.rot += e.rs * dt
                tp.textSize = e.s
                tp.alpha = (170 + 60 * en).toInt().coerceIn(0, 255)
                val sc = 1f + 0.6f * en * (0.65f + 0.35f * sin(e.ph * 3f))
                canvas.save()
                canvas.translate(e.x, e.y)
                canvas.rotate(e.rot)
                canvas.scale(sc, sc)
                canvas.drawText(e.ch, 0f, e.s * 0.35f, tp)
                canvas.restore()
            }
        }
    }
}

/**
 * Подсветка слова. Каждое слово получает одинаковые поля слева и справа (текст не «прыгает»),
 * а у текущего слова внутри этих полей рисуется ровная таблетка — ничего не обрезается и не налезает на соседей.
 */
class PillSpan(private val padX: Float, private val padY: Float, private val active: Boolean) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
        (paint.measureText(text, start, end) + 2f * padX).toInt()

    override fun draw(canvas: Canvas, text: CharSequence, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val w = paint.measureText(text, start, end)
        val old = paint.color
        if (active) {
            val fm = paint.fontMetrics
            val lineH = fm.descent - fm.ascent
            val cy = y + (fm.ascent + fm.descent) / 2f + lineH * 0.03f
            val half = lineH * 0.46f + padY
            val rect = RectF(x, cy - half, x + w + 2f * padX, cy + half)
            paint.color = Theme.NEON
            canvas.drawRoundRect(rect, rect.height() / 2.2f, rect.height() / 2.2f, paint)
            paint.color = Theme.NEON_DARK
        }
        canvas.drawText(text, start, end, x + padX, y.toFloat(), paint)
        paint.color = old
    }
}

/** Визуализатор: настоящий спектр трека, синхронно с позицией. Низкие частоты в центре. */
class SpectrumView(c: Context) : View(c) {
    var spectrum: Spectrum? = null
    private val n = Analyzer.BANDS
    private val level = FloatArray(n)
    var bass = 0f; private set
    var mid = 0f; private set
    var high = 0f; private set
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val d = resources.displayMetrics.density

    private fun avg(lo: Int, hi: Int): Float {
        var s = 0f
        for (i in lo until hi) s += level[i]
        return s / (hi - lo).coerceAtLeast(1)
    }

    fun step(posMs: Int, playing: Boolean) {
        val sp = spectrum
        val t = System.nanoTime() / 1e9f
        var f0 = 0
        var f1 = 0
        var fr = 0f
        val real = sp != null && sp.bands == n && sp.frames > 1
        if (sp != null && real) {
            val x = (posMs + 25) * sp.fps / 1000f
            f0 = x.toInt().coerceIn(0, sp.frames - 1)
            f1 = (f0 + 1).coerceAtMost(sp.frames - 1)
            fr = (x - f0).coerceIn(0f, 1f)
        }
        for (i in 0 until n) {
            val target: Float = when {
                !playing -> 0f
                real && sp != null -> {
                    val a = (sp.data[f0 * n + i].toInt() and 0xFF) / 255f
                    val b = (sp.data[f1 * n + i].toInt() and 0xFF) / 255f
                    a + (b - a) * fr
                }
                else -> 0.2f + 0.16f * (0.5f + 0.5f * sin(t * 4.5f + i * 0.55f))
            }
            val cur = level[i]
            level[i] = if (target > cur) cur + (target - cur) * 0.6f else cur + (target - cur) * 0.14f
        }
        bass = avg(0, n / 9)
        mid = avg(n * 3 / 9, n * 5 / 9)
        high = avg(n * 6 / 9, n)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / (n * 2)
        paint.strokeWidth = step * 0.46f
        val cx = w / 2f
        val minH = 3f * d
        for (i in 0 until n) {
            val l = level[i].coerceIn(0f, 1f)
            val bh = minH + (h - minH) * l.pow(0.9f)
            paint.color = Color.argb((100 + 155 * l).toInt().coerceAtMost(255), Color.red(Theme.NEON), Color.green(Theme.NEON), Color.blue(Theme.NEON))
            val dx = step * (i + 0.5f)
            canvas.drawLine(cx - dx, (h - bh) / 2f, cx - dx, (h + bh) / 2f, paint)
            canvas.drawLine(cx + dx, (h - bh) / 2f, cx + dx, (h + bh) / 2f, paint)
        }
    }
}

/** Мини-эквалайзер в углу карточки (как на видео). */
class MiniEq(c: Context) : View(c) {
    private val v = FloatArray(4) { 0.3f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; color = Theme.NEON }
    private val d = resources.displayMetrics.density

    fun set(a: Float, b: Float, c2: Float, e: Float) {
        v[0] = a; v[1] = b; v[2] = c2; v[3] = e
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        paint.strokeWidth = 3f * d
        val gap = width / 4f
        for (i in 0 until 4) {
            val bh = 4f * d + (h - 4f * d) * v[i].coerceIn(0f, 1f)
            val x = gap * (i + 0.5f)
            canvas.drawLine(x, (h - bh) / 2f, x, (h + bh) / 2f, paint)
        }
    }
}

/** Полоска трека-«змейка»: волнистая пройденная часть, прямая оставшаяся, маркер на позиции. */
class SnakeSeek(c: Context) : View(c) {
    private var progress = 0f
    var dragging = false
        private set
    var onSeek: ((Float) -> Unit)? = null
    private var phase = 0f
    private var amp = 0f
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun setProgress(p: Float) { if (!dragging) progress = p.coerceIn(0f, 1f) }

    fun frame(playing: Boolean) {
        val target = if (dragging) 3.4f * d else if (playing) 2.6f * d else 0.9f * d
        amp += (target - amp) * 0.12f
        if (playing || dragging) phase += 0.9f * d
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height / 2f
        val pad = 6f * d
        val w = width - 2 * pad
        val xp = pad + w * progress
        val k = (2.0 * PI / (16f * d)).toFloat()

        line.strokeWidth = 1.6f * d
        line.color = Theme.LINE
        canvas.drawLine(xp, cy, pad + w, cy, line)

        path.reset()
        var x = pad
        path.moveTo(x, cy + amp * sin((x - phase) * k))
        while (x < xp) {
            x += 2.5f * d
            val xx = if (x > xp) xp else x
            path.lineTo(xx, cy + amp * sin((xx - phase) * k))
        }
        line.strokeWidth = 7f * d
        line.color = Theme.accentA(46)
        canvas.drawPath(path, line)
        line.strokeWidth = 2.4f * d
        line.color = Theme.NEON
        canvas.drawPath(path, line)

        val mh = if (dragging) 24f * d else 17f * d
        line.strokeWidth = 3.4f * d
        canvas.drawLine(xp, cy - mh / 2f, xp, cy + mh / 2f, line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pad = 6f * d
        val f = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent.requestDisallowInterceptTouchEvent(true); dragging = true; progress = f }
            MotionEvent.ACTION_MOVE -> progress = f
            MotionEvent.ACTION_UP -> { dragging = false; progress = f; onSeek?.invoke(f) }
            MotionEvent.ACTION_CANCEL -> dragging = false
        }
        invalidate()
        return true
    }
}


/** «Жидкое стекло» в стиле iOS 26: матовая полупрозрачная линза с бликом и светящейся кромкой. */
class GlassDrawable : android.graphics.drawable.Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun white(a: Int) = Color.argb(a, 255, 255, 255)

    override fun draw(c: Canvas) {
        val b = bounds
        val cx = b.exactCenterX(); val cy = b.exactCenterY()
        val half = minOf(b.width(), b.height()) / 2f
        val r = half * 0.80f
        val acc = Theme.NEON
        val light = Theme.LIGHT

        // мягкое свечение вокруг
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(cx, cy + half * 0.06f, half,
            intArrayOf(Theme.alpha(acc, 0x66), Theme.alpha(acc, 0x22), Theme.alpha(acc, 0x00)),
            floatArrayOf(0.55f, 0.82f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, half, p)

        // тело линзы
        p.reset(); p.isAntiAlias = true
        val top = if (light) Theme.alpha(acc, 0x88) else white(0x52)
        val mid = Theme.alpha(acc, if (light) 0x66 else 0x3A)
        val bot = if (light) Theme.alpha(acc, 0x99) else white(0x1C)
        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, intArrayOf(top, mid, bot), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)

        // преломление у краёв: кромка светлее, центр прозрачнее
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(cx, cy, r, intArrayOf(white(0x00), white(0x00), white(0x38)), floatArrayOf(0f, 0.68f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)

        // верхний блик
        c.save()
        val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        c.clipPath(clip)
        p.reset(); p.isAntiAlias = true
        val hl = RectF(cx - r * 0.74f, cy - r * 0.96f, cx + r * 0.74f, cy - r * 0.08f)
        p.shader = LinearGradient(0f, hl.top, 0f, hl.bottom, white(0x7A), white(0x00), Shader.TileMode.CLAMP)
        c.drawOval(hl, p)
        // нижний отсвет
        val lo = RectF(cx - r * 0.55f, cy + r * 0.45f, cx + r * 0.55f, cy + r * 1.25f)
        p.shader = LinearGradient(0f, lo.bottom, 0f, lo.top, Theme.alpha(acc, 0x66), Theme.alpha(acc, 0x00), Shader.TileMode.CLAMP)
        c.drawOval(lo, p)
        c.restore()

        // светящаяся кромка (ярче по диагонали)
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(2f, r * 0.028f)
        val sw = SweepGradient(cx, cy,
            intArrayOf(white(0x30), white(0xD0), white(0x18), white(0x10), white(0xE6), white(0x30)),
            floatArrayOf(0f, 0.13f, 0.28f, 0.5f, 0.63f, 1f))
        p.shader = sw
        c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Стеклянный ползунок для эквалайзера (вертикальный) и баса (горизонтальный). */
class GlassSlider(ctx: Context, private val vertical: Boolean, private val min: Int, private val max: Int, private val fromCenter: Boolean) : View(ctx) {
    var value = 0
        set(v) { field = v.coerceIn(min, max); invalidate() }
    var onChange: ((Int) -> Unit)? = null
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun frac(v: Int) = (v - min).toFloat() / (max - min)

    override fun onDraw(c: Canvas) {
        val pad = 16f * d
        val w = width.toFloat(); val h = height.toFloat()
        val a0: Float; val a1: Float
        if (vertical) { a0 = h - pad; a1 = pad } else { a0 = pad; a1 = w - pad }
        fun pos(f: Float) = a0 + (a1 - a0) * f
        val zero = pos(if (fromCenter) frac(0) else 0f)
        val cur = pos(frac(value))
        val mid = if (vertical) w / 2f else h / 2f

        p.reset(); p.isAntiAlias = true
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 6f * d
        p.color = Theme.accentA(0x33)
        if (vertical) c.drawLine(mid, a0, mid, a1, p) else c.drawLine(a0, mid, a1, mid, p)
        p.color = Theme.NEON
        if (vertical) c.drawLine(mid, zero, mid, cur, p) else c.drawLine(zero, mid, cur, mid, p)

        val tx = if (vertical) mid else cur
        val ty = if (vertical) cur else mid
        val r = 11f * d
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(tx, ty, r * 1.8f, intArrayOf(Theme.alpha(Theme.NEON, 0x66), Theme.alpha(Theme.NEON, 0)), null, Shader.TileMode.CLAMP)
        c.drawCircle(tx, ty, r * 1.8f, p)
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(tx, ty - r, tx, ty + r, Color.argb(0xF0, 255, 255, 255), Color.argb(0x90, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawCircle(tx, ty, r, p)
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = Theme.NEON
        c.drawCircle(tx, ty, r - 1.2f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); upd(e) }
            MotionEvent.ACTION_MOVE -> upd(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    private fun upd(e: MotionEvent) {
        val pad = 16f * d
        val f = if (vertical) 1f - (e.y - pad) / (height - 2 * pad) else (e.x - pad) / (width - 2 * pad)
        var v = min + Math.round(f.coerceIn(0f, 1f) * (max - min))
        if (fromCenter && Math.abs(v) < 5) v = 0
        if (v != value) { value = v; onChange?.invoke(v) }
    }
}
