package com.zxcmuss.player

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns

/** Сохраняет аудио в Music/ZXCMUSS (без лишних разрешений) и ведёт плейлист «Загрузки». */
object Importer {
    private const val PREFS = "zx"
    private const val KEY = "dl"

    fun createAudio(ctx: Context, name: String, mime: String): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/ZXCMUSS")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)
    }

    fun publish(ctx: Context, uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, v, null, null)
    }

    @Synchronized
    fun markDownloaded(ctx: Context, id: Long) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = HashSet<String>(p.getStringSet(KEY, emptySet()) ?: emptySet())
        set.add(id.toString())
        p.edit().putStringSet(KEY, set).apply()
    }

    @Synchronized
    fun downloaded(ctx: Context): Set<Long> {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return (p.getStringSet(KEY, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    }

    /** Копирует выбранные/присланные файлы в Music/ZXCMUSS. done вызывается из фонового потока. */
    fun importUris(ctx: Context, uris: List<Uri>, done: (Int) -> Unit) {
        Thread {
            var n = 0
            for (u in uris) {
                try {
                    var name = "audio"
                    ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) name = it.getString(0) ?: name
                    }
                    if (!name.contains('.')) name += ".mp3"
                    val type = ctx.contentResolver.getType(u) ?: "audio/mpeg"
                    val mime = if (type.startsWith("audio/")) type else "audio/mpeg"
                    val dst = createAudio(ctx, name, mime)
                    if (dst == null) continue
                    ctx.contentResolver.openInputStream(u).use { inp ->
                        ctx.contentResolver.openOutputStream(dst).use { out ->
                            if (inp != null && out != null) inp.copyTo(out)
                        }
                    }
                    publish(ctx, dst)
                    markDownloaded(ctx, ContentUris.parseId(dst))
                    n++
                } catch (_: Exception) {
                }
            }
            done(n)
        }.start()
    }
}
