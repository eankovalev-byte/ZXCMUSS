package com.zxcmuss.player

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Спектр трека: frames × bands байт (0..255), fps кадров в секунду. */
class Spectrum(val bands: Int, val fps: Int, val data: ByteArray) {
    val frames: Int get() = data.size / bands
}

/**
 * Один раз декодирует трек в фоне (быстрее реального времени), считает спектр по FFT
 * и кэширует на диск. Потом визуализатор просто читает кадр по текущей позиции —
 * поэтому полоски точно совпадают со звуком каждой песни и не требуют лишних разрешений.
 */
object Analyzer {
    const val BANDS = 36
    const val FPS = 30
    private const val N = 2048

    private val pool = Executors.newSingleThreadExecutor { r ->
        Thread(r, "zx-analyzer").apply { priority = Thread.MIN_PRIORITY }
    }
    private val cache = HashMap<Long, Spectrum>()
    @Volatile private var wanted = -1L
    @Volatile var onReady: ((Long, Spectrum) -> Unit)? = null

    private val cosT = FloatArray(N / 2) { cos(2.0 * PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { (-sin(2.0 * PI * it / N)).toFloat() }
    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }

    fun cached(id: Long): Spectrum? = synchronized(cache) { cache[id] }

    fun request(ctx: Context, t: Track) {
        wanted = t.id
        cached(t.id)?.let { onReady?.invoke(t.id, it); return }
        val app = ctx.applicationContext
        pool.execute {
            if (wanted != t.id) return@execute
            val have = cached(t.id)
            val sp = have ?: loadOrDecode(app, t) ?: return@execute
            synchronized(cache) { if (cache.size > 6) cache.clear(); cache[t.id] = sp }
            onReady?.invoke(t.id, sp)
        }
    }

    private fun loadOrDecode(ctx: Context, t: Track): Spectrum? {
        val f = File(ctx.cacheDir, "viz2_${t.id}.bin")
        try {
            if (f.exists()) {
                val b = f.readBytes()
                if (b.isNotEmpty() && b.size % BANDS == 0) return Spectrum(BANDS, FPS, b)
            }
        } catch (_: Exception) {}
        val sp = decode(ctx, t) ?: return null
        try {
            f.writeBytes(sp.data)
            val all = ctx.cacheDir.listFiles { x -> x.name.startsWith("viz2_") }
            if (all != null && all.size > 150) all.sortedBy { it.lastModified() }.take(all.size - 120).forEach { it.delete() }
        } catch (_: Exception) {}
        return sp
    }

    // ---------- FFT ----------

    private fun fft(re: FloatArray, im: FloatArray) {
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val half = len / 2
            val step = N / len
            var i = 0
            while (i < N) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val tr = re[b] * wr - im[b] * wi
                    val ti = re[b] * wi + im[b] * wr
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                }
                i += len
            }
            len = len shl 1
        }
    }

    private class Engine(val sr: Int) {
        val hop = max(1, sr / FPS)
        val ring = FloatArray(N)
        var wi = 0
        var since = 0
        val re = FloatArray(N)
        val im = FloatArray(N)
        val edges = IntArray(BANDS + 1)
        val tilt = FloatArray(BANDS)
        val frames = ArrayList<FloatArray>()

        init {
            val f0 = 40f
            val f1 = min(14000f, sr / 2f * 0.92f)
            for (b in 0..BANDS) {
                val f = f0 * (f1 / f0).pow(b.toFloat() / BANDS)
                var bin = (f * N / sr).toInt().coerceIn(1, N / 2 - 2)
                if (b > 0 && bin <= edges[b - 1]) bin = edges[b - 1] + 1
                edges[b] = bin
            }
            for (b in 0 until BANDS) {
                val fc = f0 * (f1 / f0).pow((b + 0.5f) / BANDS)
                tilt[b] = 3f * (log10(fc / 200f) / log10(2f))
            }
        }

        fun push(s: Float, fftFn: (FloatArray, FloatArray) -> Unit) {
            ring[wi] = s
            wi = (wi + 1) and (N - 1)
            since++
            if (since >= hop) { since = 0; frames.add(compute(fftFn)) }
        }

        private fun compute(fftFn: (FloatArray, FloatArray) -> Unit): FloatArray {
            for (i in 0 until N) { re[i] = ring[(wi + i) and (N - 1)] * win[i]; im[i] = 0f }
            fftFn(re, im)
            val out = FloatArray(BANDS)
            for (b in 0 until BANDS) {
                val lo = edges[b]
                val hi = max(edges[b + 1], lo + 1)
                var sum = 0f
                for (k in lo until hi) sum += re[k] * re[k] + im[k] * im[k]
                val pw = sum / (hi - lo)
                out[b] = 10f * log10(pw + 1e-9f) + tilt[b]
            }
            return out
        }
    }

    // ---------- декодирование ----------

    private fun decode(ctx: Context, t: Track): Spectrum? {
        if (t.durationMs > 40 * 60_000L) return null
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, t.uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; fmt = f; break }
            }
            val format = fmt ?: return null
            ex.selectTrack(idx)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            var sr = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var floatPcm = false
            var eng = Engine(sr)
            val info = MediaCodec.BufferInfo()
            val fftFn: (FloatArray, FloatArray) -> Unit = { a, b -> fft(a, b) }
            var inDone = false
            var outDone = false
            var idle = 0

            while (!outDone) {
                if (wanted != t.id) return null
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)
                        val sz = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (sz < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    idle = 0
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            if (floatPcm) {
                                val fb = ob.asFloatBuffer()
                                val n = fb.remaining()
                                var k = 0
                                while (k + ch <= n) {
                                    var s = 0f
                                    for (q in 0 until ch) s += fb.get(k + q)
                                    eng.push(s / ch, fftFn)
                                    k += ch
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                val n = sb.remaining()
                                var k = 0
                                while (k + ch <= n) {
                                    var s = 0f
                                    for (q in 0 until ch) s += sb.get(k + q)
                                    eng.push(s / (ch * 32768f), fftFn)
                                    k += ch
                                }
                            }
                        }
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (nf.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        floatPcm = nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        val nsr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (nsr != sr && eng.frames.isEmpty()) { sr = nsr; eng = Engine(sr) }
                    }
                } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    idle++
                    if (inDone && idle > 400) break
                }
            }

            val frames = eng.frames
            val n = frames.size
            if (n < 2) return null
            val all = FloatArray(n * BANDS)
            for (i in 0 until n) System.arraycopy(frames[i], 0, all, i * BANDS, BANDS)
            val sorted = all.copyOf()
            sorted.sort()
            val ceil = sorted[(sorted.size * 0.995).toInt().coerceAtMost(sorted.size - 1)]
            val floor = ceil - 42f
            val bytes = ByteArray(all.size)
            for (i in all.indices) {
                val v = ((all[i] - floor) / (ceil - floor)).coerceIn(0f, 1f).pow(1.35f)
                bytes[i] = (v * 255f).toInt().toByte()
            }
            return Spectrum(BANDS, FPS, bytes)
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
