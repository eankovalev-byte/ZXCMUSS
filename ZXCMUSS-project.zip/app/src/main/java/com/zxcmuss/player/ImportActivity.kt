package com.zxcmuss.player

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** Невидимый экран: принимает «Поделиться → ZXCMUSS» (например, из Telegram) и сохраняет треки. */
class ImportActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = ArrayList<Uri>()
        try {
            when (intent?.action) {
                Intent.ACTION_SEND -> {
                    @Suppress("DEPRECATION")
                    val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (u != null) uris.add(u)
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    @Suppress("DEPRECATION")
                    val l = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                    if (l != null) uris.addAll(l)
                }
            }
        } catch (_: Exception) {
        }
        if (uris.isEmpty()) { finish(); return }
        Toast.makeText(this, "ZXCMUSS: сохраняю музыку…", Toast.LENGTH_SHORT).show()
        Importer.importUris(this, uris) { n ->
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (n > 0) "Добавлено треков: $n. Они во вкладке «Загрузки»" else "Не удалось сохранить файл",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }
    }
}
