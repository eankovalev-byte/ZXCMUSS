package com.zxcmuss.player

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** Невидимый экран: принимает «Поделиться → ZXCMUSS» (например, из Telegram) и сохраняет треки. */
class ImportActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = ArrayList<Uri>()
        if (intent?.action == Intent.ACTION_SEND && (intent.type ?: "").startsWith("text/")) {
            val raw = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val i = Intent(this, MainActivity::class.java)
                .putExtra("q", queryFrom(raw))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
            finish()
            return
        }
        try {
            when (intent?.action) {
                Intent.ACTION_SEND -> {
                    @Suppress("DEPRECATION")
                    val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (u != null) uris.add(u)
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    @Suppress("DEPRECATION")
                    val l = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                    if (l != null) uris.addAll(l)
                }
            }
        } catch (_: Exception) {
        }
        if (uris.isEmpty()) { finish(); return }
        Toast.makeText(this, "ZXCMUSS: сохраняю музыку…", Toast.LENGTH_SHORT).show()
        Importer.importUris(this, uris) { n ->
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (n > 0) "Добавлено треков: $n. Они во вкладке «Загрузки»" else "Не удалось сохранить файл",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }
    }

    /** Из текста «Поделиться» (ВК, Яндекс Музыка…) вытаскиваем «исполнитель название». */
    private fun queryFrom(text: String): String {
        var t = text.replace(Regex("https?://\\S+"), " ")
        t = t.replace(Regex("(?i)(слушайте|слушай|на яндекс музыке|в яндекс музыке|яндекс музыка|яндекс музыке|вк музыка|vk музыка|вконтакте|в вк)"), " ")
        val line = t.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        return line.replace(Regex("[«»\"“”]"), "")
            .replace(" — ", " ").replace(" – ", " ").replace(" - ", " ")
            .replace(Regex("\\s+"), " ").trim().take(80)
    }
}
