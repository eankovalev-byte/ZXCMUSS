package com.zxcmuss.player

import java.io.File

/** Необязательные синхронные тексты: файл «трек.lrc» рядом с «трек.mp3». */
object Lrc {
    class Line(val t: Long, val text: String)

    private val rx = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]")

    fun load(path: String?): List<Line> {
        if (path == null) return emptyList()
        return try {
            val f = File(path.substringBeforeLast('.') + ".lrc")
            if (!f.exists()) return emptyList()
            val res = ArrayList<Line>()
            f.forEachLine { raw ->
                val ms = rx.findAll(raw).toList()
                if (ms.isNotEmpty()) {
                    val text = raw.substring(ms.last().range.last + 1).trim()
                    for (m in ms) {
                        val frac = (m.groupValues[3]).padEnd(3, '0').take(3).toLong()
                        val t = m.groupValues[1].toLong() * 60000 + m.groupValues[2].toLong() * 1000 + frac
                        res.add(Line(t, text))
                    }
                }
            }
            res.filter { it.text.isNotEmpty() }.sortedBy { it.t }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
