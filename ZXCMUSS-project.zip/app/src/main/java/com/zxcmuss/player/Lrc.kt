package com.zxcmuss.player

import java.io.File

/** Синхронные тексты в формате LRC. */
object Lrc {
    class Line(val t: Long, val text: String)

    private val rx = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]")

    fun load(path: String?): List<Line> {
        if (path == null) return emptyList()
        return try {
            val f = File(path.substringBeforeLast('.') + ".lrc")
            if (!f.exists()) emptyList() else parse(f.readText())
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun parse(text: String): List<Line> {
        val res = ArrayList<Line>()
        try {
            for (raw in text.lineSequence()) {
                val ms = rx.findAll(raw).toList()
                if (ms.isEmpty()) continue
                val body = raw.substring(ms.last().range.last + 1).trim()
                for (m in ms) {
                    val frac = m.groupValues[3].padEnd(3, '0').take(3).toLong()
                    val t = m.groupValues[1].toLong() * 60000 + m.groupValues[2].toLong() * 1000 + frac
                    res.add(Line(t, body))
                }
            }
        } catch (_: Exception) {}
        return res.filter { it.text.isNotEmpty() }.sortedBy { it.t }
    }
}
