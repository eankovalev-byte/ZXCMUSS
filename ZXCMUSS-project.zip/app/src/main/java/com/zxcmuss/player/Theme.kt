package com.zxcmuss.player

import android.graphics.Color

/** Темы оформления. Исходная чёрно-зелёная осталась точно как была. */
object Theme {
    /** kind: 0 — исходная зелёная, 1 — тёмная с оттенком, 2 — чисто чёрная, 3 — светлая, 4 — графит */
    class P(val name: String, val accent: Int, val onAccent: Int, val kind: Int, val peak: Int)

    private fun c(r: Int, g: Int, b: Int): Int = Color.rgb(r, g, b)
    fun alpha(col: Int, a: Int): Int = (a shl 24) or (col and 0xFFFFFF)
    fun accentA(a: Int): Int = alpha(NEON, a)

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun scale(col: Int, k: Float): Int = Color.rgb(
        (Color.red(col) * k).toInt().coerceIn(0, 255),
        (Color.green(col) * k).toInt().coerceIn(0, 255),
        (Color.blue(col) * k).toInt().coerceIn(0, 255)
    )

    val list = listOf(
        P("Чёрно-зелёная", c(43, 253, 137), c(0, 23, 10), 0, 0),
        P("Чёрно-красная", c(255, 59, 72), c(255, 255, 255), 1, c(64, 12, 18)),
        P("Чёрно-жёлтая", c(255, 214, 10), c(26, 20, 0), 1, c(56, 46, 6)),
        P("Чёрная", c(214, 214, 214), c(0, 0, 0), 2, 0),
        P("Чёрно-белая", c(255, 255, 255), c(0, 0, 0), 1, c(46, 46, 48)),
        P("Чёрно-синяя", c(59, 130, 255), c(255, 255, 255), 1, c(14, 34, 70)),
        P("Чёрно-розовая", c(255, 64, 160), c(255, 255, 255), 1, c(62, 14, 40)),
        P("Чёрно-фиолетовая", c(160, 98, 255), c(255, 255, 255), 1, c(38, 20, 66)),
        P("Бело-красная", c(230, 30, 60), c(255, 255, 255), 3, c(255, 190, 198)),
        P("Серая", c(214, 218, 226), c(17, 20, 24), 4, c(78, 81, 88)),
        P("Белая", c(20, 22, 28), c(255, 255, 255), 3, c(208, 212, 220)),
        P("Бело-фиолетовая", c(110, 60, 230), c(255, 255, 255), 3, c(206, 192, 255))
    )

    private val ORIG = intArrayOf(
        c(0, 3, 0), c(0, 11, 0), c(0, 16, 2), c(5, 25, 11), c(12, 39, 21), c(19, 51, 31), c(8, 43, 22),
        c(9, 44, 23), c(2, 37, 16), c(0, 27, 11), c(0, 22, 6), c(3, 28, 12), c(23, 50, 34), c(25, 52, 36),
        c(1, 26, 10), c(0, 17, 2), c(0, 13, 0)
    )
    private val KS = floatArrayOf(
        .058f, .21f, .31f, .48f, .75f, .98f, .83f, .85f, .71f, .52f, .42f, .54f, .96f, 1f, .5f, .33f, .25f
    )
    val STOPS = floatArrayOf(0f, .09f, .125f, .16f, .22f, .25f, .31f, .40f, .50f, .60f, .66f, .69f, .75f, .78f, .84f, .90f, 1f)

    var index = 0
    var LIGHT = false
    var NEON = 0
    var NEON_DARK = 0
    var DIM = 0
    var EDGE = 0
    var TEXT = 0
    var LYRIC = 0
    var LYRIC_DIM = 0
    var LINE = 0
    var HINT = 0
    var CHIP_BG = 0
    var CHIP_STROKE = 0
    var HEART_OFF = 0
    var PANEL = 0
    var MINI = 0
    var SHEET_TOP = 0
    var SHEET_BOT = 0
    var BG_TOP = 0
    var BG_BOTTOM = 0
    var GLOW = 1f
    var BG_STOPS = IntArray(17)
    var CARD = IntArray(3)

    fun select(i: Int) {
        index = i.coerceIn(0, list.size - 1)
        val p = list[index]
        val kind = p.kind
        val white = Color.WHITE
        NEON = p.accent
        NEON_DARK = p.onAccent
        LIGHT = kind == 3
        TEXT = if (LIGHT) c(21, 23, 28) else white
        DIM = alpha(TEXT, 0x99)
        HINT = alpha(TEXT, 0x66)
        CHIP_BG = alpha(TEXT, 0x14)
        CHIP_STROKE = alpha(TEXT, 0x33)
        HEART_OFF = alpha(TEXT, 0x66)

        BG_STOPS = IntArray(17) { k ->
            when (kind) {
                0 -> ORIG[k]
                1 -> mix(c(0, 0, 0), p.peak, KS[k])
                2 -> c(0, 0, 0)
                4 -> mix(c(14, 15, 17), p.peak, KS[k])
                else -> mix(c(250, 250, 252), p.peak, KS[k] * 0.85f)
            }
        }
        BG_TOP = if (kind == 0) Color.BLACK else BG_STOPS[0]
        BG_BOTTOM = if (kind == 0) Color.BLACK else BG_STOPS[16]

        CARD = when (kind) {
            0 -> intArrayOf(0xE0071E10.toInt(), 0xCC0A3A22.toInt(), 0xD90C4A2C.toInt())
            1 -> intArrayOf(alpha(scale(p.accent, .12f), 0xE0), alpha(scale(p.accent, .23f), 0xCC), alpha(scale(p.accent, .29f), 0xD9))
            2 -> intArrayOf(alpha(scale(p.accent, .06f), 0xE6), alpha(scale(p.accent, .10f), 0xD9), alpha(scale(p.accent, .13f), 0xD9))
            4 -> intArrayOf(alpha(scale(p.accent, .20f), 0xE0), alpha(scale(p.accent, .30f), 0xCC), alpha(scale(p.accent, .38f), 0xD9))
            else -> intArrayOf(alpha(mix(white, p.peak, .25f), 0xF0), alpha(mix(white, p.peak, .40f), 0xE6), alpha(mix(white, p.peak, .60f), 0xE0))
        }
        EDGE = when (kind) {
            0 -> 0x99B7F5D1.toInt()
            3 -> alpha(p.accent, 0x80)
            else -> alpha(mix(p.accent, white, .55f), 0x99)
        }
        PANEL = when (kind) {
            0 -> 0xF5020A05.toInt()
            1 -> alpha(scale(p.accent, .04f), 0xF5)
            2 -> 0xF5000000.toInt()
            4 -> alpha(scale(p.accent, .07f), 0xF5)
            else -> 0xF8FAFAFC.toInt()
        }
        MINI = if (kind == 0) 0xE60C3A22.toInt() else alpha(CARD[1], 0xEE)
        SHEET_TOP = when (kind) {
            0 -> 0xF4082015.toInt()
            1 -> alpha(scale(p.accent, .13f), 0xF4)
            2 -> 0xF4101010.toInt()
            4 -> alpha(scale(p.accent, .20f), 0xF4)
            else -> 0xF8FFFFFF.toInt()
        }
        SHEET_BOT = when (kind) {
            0 -> 0xF6030A06.toInt()
            1 -> alpha(scale(p.accent, .04f), 0xF6)
            2 -> 0xF6000000.toInt()
            4 -> alpha(scale(p.accent, .08f), 0xF6)
            else -> 0xF8F1F1F5.toInt()
        }
        LYRIC = when (kind) {
            0 -> 0xFFE9FFF3.toInt()
            3 -> TEXT
            else -> mix(white, p.accent, .08f)
        }
        LYRIC_DIM = alpha(LYRIC, 0x8C)
        LINE = if (kind == 0) Color.argb(95, 170, 225, 195) else alpha(TEXT, 95)
        GLOW = when (kind) { 2 -> 0.25f; 3 -> 0.5f; 4 -> 0.6f; else -> 1f }
    }

    init { select(0) }
}
