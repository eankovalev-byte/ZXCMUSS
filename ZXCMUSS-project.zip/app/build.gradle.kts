plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zxcmuss.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zxcmuss.player"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    signingConfigs {
        create("zx") {
            storeFile = file("zxcmuss.jks")
            storePassword = "zxcmuss123"
            keyAlias = "zxc"
            keyPassword = "zxcmuss123"
        }
    }

    buildTypes {
        release {
            // R8 + удаление неиспользуемых ресурсов = маленький и быстрый APK
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // постоянный ключ: новые версии ставятся поверх старых
            signingConfig = signingConfigs.getByName("zx")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("/META-INF/*.version", "/kotlin/**", "/DebugProbesKt.bin") }
}
// Зависимостей нет: только системные API Android — минимальный размер.
