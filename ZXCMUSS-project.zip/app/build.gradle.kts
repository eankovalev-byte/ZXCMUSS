plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zxcmuss.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zxcmuss.player"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // R8 + удаление неиспользуемых ресурсов = маленький и быстрый APK
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // подпись debug-ключом, чтобы release-APK сразу устанавливался
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("/META-INF/*.version", "/kotlin/**", "/DebugProbesKt.bin") }
}
// Зависимостей нет: только системные API Android — минимальный размер.
