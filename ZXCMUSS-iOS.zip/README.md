# ZXCMUSS для iPhone (v3.1)
SwiftUI, iOS 16+. Сборка IPA: GitHub Actions (macOS), workflow .github/workflows/ios.yml.
Установка: Sideloadly / AltStore (подпись вашим Apple ID).
