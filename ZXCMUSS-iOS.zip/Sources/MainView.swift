import SwiftUI

func fmtTime(_ s: Double) -> String {
    if !s.isFinite || s < 0 { return "0:00" }
    let t = Int(s)
    return String(format: "%d:%02d", t / 60, t % 60)
}

struct MainView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var lib: Library
    @EnvironmentObject var player: Player
    @EnvironmentObject var lyrics: Lyrics
    @EnvironmentObject var prefs: Prefs

    @State private var showLib = false
    @State private var showMenu = false
    @State private var restored = false

    var body: some View {
        ZStack {
            AuroraView()
            VStack(spacing: 0) {
                topBar
                Spacer(minLength: 0)
                card
                controls
                Spacer(minLength: 0)
                Spacer(minLength: 0)
            }
        }
        .fullScreenCover(isPresented: $showLib) { LibraryView() }
        .sheet(isPresented: $showMenu) { MenuView() }
        .task {
            if MPMediaAuthNotDetermined() { lib.requestAppleMusic() }
            await lib.reload()
            restoreLast()
        }
        .onChange(of: player.current?.id) { _ in
            lyrics.load(for: player.current, online: prefs.onlineLyrics)
        }
        .onChange(of: prefs.onlineLyrics) { _ in
            lyrics.load(for: player.current, online: prefs.onlineLyrics)
        }
        .alert("Ошибка", isPresented: Binding(get: { player.errorText != nil }, set: { if !$0 { player.errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(player.errorText ?? "") }
        .alert(lib.notice ?? "", isPresented: Binding(get: { lib.notice != nil }, set: { if !$0 { lib.notice = nil } })) {
            Button("OK", role: .cancel) {}
        }
    }

    private func restoreLast() {
        guard !restored, player.current == nil else { return }
        restored = true
        let id = UserDefaults.standard.string(forKey: "lastId")
        if let id = id, let i = lib.tracks.firstIndex(where: { $0.id == id }) {
            player.setQueue(lib.tracks, start: i, autoplay: false)
        } else if !lib.tracks.isEmpty {
            player.setQueue(lib.tracks, start: 0, autoplay: false)
        }
    }

    // MARK: верхняя панель

    private var topBar: some View {
        HStack(spacing: 6) {
            Text("ZXCMUSS")
                .font(.system(size: 15, weight: .bold))
                .kerning(5)
                .foregroundColor(t.text)
            Spacer()
            barButton("heart" + ((player.current.map { lib.favs.contains($0.id) } ?? false) ? ".fill" : ""),
                      color: (player.current.map { lib.favs.contains($0.id) } ?? false) ? t.neon : t.text) {
                if let c = player.current { lib.toggleFav(c.id) }
            }
            barButton("music.note.list", color: t.text) { showLib = true }
            barButton("ellipsis", color: t.text, rotate: true) { showMenu = true }
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .frame(height: 56)
    }

    private func barButton(_ name: String, color: Color, rotate: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: name)
                .font(.system(size: 22, weight: .semibold))
                .rotationEffect(.degrees(rotate ? 90 : 0))
                .foregroundColor(color)
                .frame(width: 44, height: 44)
        }
    }

    // MARK: карточка

    private var card: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(player.current?.title ?? "Нет трека")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(t.text)
                        .lineLimit(1)
                    Text((player.current?.artist ?? "").isEmpty ? "Неизвестный исполнитель" : player.current!.artist)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(t.dim)
                        .lineLimit(1)
                }
                Spacer()
                MiniEq().padding(.top, 2)
            }
            LyricsBlock()
                .frame(minHeight: 150, alignment: .topLeading)
                .padding(.top, 18)
            SpectrumView()
                .frame(height: 112)
                .padding(.top, 6)
            SnakeSeek()
                .padding(.top, 8)
            TimelineView(.periodic(from: .now, by: 0.5)) { _ in
                HStack {
                    Text(fmtTime(player.position))
                    Spacer()
                    Text("-" + fmtTime(max(0, player.duration - player.position)))
                }
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(t.dim)
            }
            .padding(.horizontal, 6)
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 20)
        .background(
            RoundedRectangle(cornerRadius: 38, style: .continuous)
                .fill(LinearGradient(colors: t.card, startPoint: .top, endPoint: .bottom))
        )
        .overlay(RoundedRectangle(cornerRadius: 38, style: .continuous).strokeBorder(t.edge, lineWidth: 1))
        .padding(.horizontal, 14)
    }

    // MARK: кнопки

    private var controls: some View {
        HStack(spacing: 10) {
            ctrl(player.shuffle ? "shuffle" : "shuffle", color: player.shuffle ? t.neon : t.text) { player.setShuffle(!player.shuffle) }
            ctrl("backward.fill", size: 26) { player.prev() }
            Button { player.toggle() } label: {
                ZStack {
                    GlassCircle()
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 31, weight: .bold))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.25), radius: 3, y: 1)
                }
                .frame(width: 92, height: 92)
            }
            .buttonStyle(GlassButtonStyle())
            ctrl("forward.fill", size: 26) { player.next() }
            ctrl(player.repeatMode == 2 ? "repeat.1" : "repeat", color: player.repeatMode == 0 ? t.text : t.neon) { player.cycleRepeat() }
        }
        .padding(.top, 28)
    }

    private func ctrl(_ name: String, size: CGFloat = 21, color: Color? = nil, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: name)
                .font(.system(size: size, weight: .semibold))
                .foregroundColor(color ?? t.text)
                .frame(width: 54, height: 54)
        }
    }
}

import MediaPlayer
func MPMediaAuthNotDetermined() -> Bool { MPMediaLibrary.authorizationStatus() == .notDetermined }

// MARK: - текст: ровная подсветка слова

struct LyricsBlock: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player
    @EnvironmentObject var lyrics: Lyrics

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20)) { _ in
            content(pos: player.position)
        }
    }

    @ViewBuilder
    private func content(pos: Double) -> some View {
        let lines = lyrics.lines
        if let idx = lines.lastIndex(where: { $0.t <= pos + 0.05 }) {
            let line = lines[idx]
            let nextT = idx + 1 < lines.count ? lines[idx + 1].t : line.t + 5
            let span = max(0.5, min(nextT - line.t, 8))
            let frac = min(max((pos - line.t) / span, 0), 0.999)
            let words = line.text.split(separator: " ").map(String.init)
            let active = Int(frac * Double(max(words.count, 1)))
            FlowLayout(spacing: 0, lineSpacing: 6) {
                ForEach(Array(words.enumerated()), id: \.offset) { i, w in
                    Text(w)
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(i == active ? t.neonDark : (i > active ? t.lyricDim : t.lyric))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(
                            Capsule().fill(i == active ? t.neon : Color.clear)
                        )
                }
            }
            .animation(.easeOut(duration: 0.12), value: active)
        } else {
            Text(player.current?.title ?? "Выберите трек в библиотеке")
                .font(.system(size: 30, weight: .bold))
                .foregroundColor(t.lyric)
                .multilineTextAlignment(.leading)
        }
    }
}
