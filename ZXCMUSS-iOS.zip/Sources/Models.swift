import SwiftUI
import AVFoundation
import MediaPlayer

struct Track: Identifiable, Hashable {
    let id: String
    var title: String
    var artist: String
    let url: URL
    var duration: Double
    var added: Date
}

/// Библиотека: файлы приложения (папка «Музыка» в Файлах → ZXCMUSS) + локальные треки Apple Music.
@MainActor
final class Library: ObservableObject {
    @Published var tracks: [Track] = []
    @Published var favs: Set<String>
    @Published var downloads: Set<String>
    @Published var loading = false
    @Published var notice: String?

    nonisolated static let exts: Set<String> = ["mp3", "m4a", "aac", "wav", "flac", "aif", "aiff", "caf", "mp4"]

    nonisolated static var musicDir: URL {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Music", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    init() {
        favs = Set(UserDefaults.standard.stringArray(forKey: "favs") ?? [])
        downloads = Set(UserDefaults.standard.stringArray(forKey: "dl") ?? [])
    }

    func toggleFav(_ id: String) {
        if favs.contains(id) { favs.remove(id) } else { favs.insert(id) }
        UserDefaults.standard.set(Array(favs), forKey: "favs")
    }

    func markDownloaded(_ id: String) {
        downloads.insert(id)
        UserDefaults.standard.set(Array(downloads), forKey: "dl")
    }

    func reload() async {
        loading = true
        var out: [Track] = []
        let fm = FileManager.default
        let files = (try? fm.contentsOfDirectory(at: Library.musicDir, includingPropertiesForKeys: [.creationDateKey], options: [.skipsHiddenFiles])) ?? []
        for u in files where Library.exts.contains(u.pathExtension.lowercased()) {
            out.append(await Library.makeTrack(u))
        }
        out.append(contentsOf: Library.appleMusic())
        tracks = out
        loading = false
    }

    nonisolated static func makeTrack(_ u: URL) async -> Track {
        let asset = AVURLAsset(url: u)
        var title = u.deletingPathExtension().lastPathComponent
        var artist = ""
        var gotTitle = false
        if let items = try? await asset.load(.commonMetadata) {
            for it in items {
                if it.commonKey == .commonKeyTitle, let s = try? await it.load(.stringValue), !s.isEmpty { title = s; gotTitle = true }
                if it.commonKey == .commonKeyArtist, let s = try? await it.load(.stringValue), !s.isEmpty { artist = s }
            }
        }
        if !gotTitle, artist.isEmpty, let r = title.range(of: " - ") {
            artist = String(title[title.startIndex..<r.lowerBound])
            title = String(title[r.upperBound...])
        }
        let dur = (try? await asset.load(.duration))?.seconds ?? 0
        let date = (try? u.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date()
        return Track(id: "f:" + u.lastPathComponent, title: title, artist: artist, url: u,
                     duration: dur.isFinite ? dur : 0, added: date)
    }

    nonisolated static func appleMusic() -> [Track] {
        guard MPMediaLibrary.authorizationStatus() == .authorized else { return [] }
        let items = MPMediaQuery.songs().items ?? []
        var out: [Track] = []
        for m in items {
            guard let url = m.assetURL, !m.isCloudItem else { continue }
            out.append(Track(id: "m:\(m.persistentID)", title: m.title ?? "Без названия", artist: m.artist ?? "",
                             url: url, duration: m.playbackDuration, added: m.dateAdded))
        }
        return out
    }

    func requestAppleMusic() {
        MPMediaLibrary.requestAuthorization { _ in
            Task { @MainActor in await self.reload() }
        }
    }

    /// Копирует выбранные/присланные файлы в папку приложения и помечает как «Загрузки».
    func importURLs(_ urls: [URL]) async -> Int {
        var n = 0
        for u in urls {
            let ok = u.startAccessingSecurityScopedResource()
            defer { if ok { u.stopAccessingSecurityScopedResource() } }
            guard Library.exts.contains(u.pathExtension.lowercased()) else { continue }
            if let dest = Library.uniqueDest(u.lastPathComponent) {
                do {
                    try FileManager.default.copyItem(at: u, to: dest)
                    markDownloaded("f:" + dest.lastPathComponent)
                    n += 1
                } catch {}
            }
        }
        if n > 0 { await reload() }
        return n
    }

    nonisolated static func uniqueDest(_ name: String) -> URL? {
        let dir = musicDir
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var cand = dir.appendingPathComponent(name)
        var i = 1
        while FileManager.default.fileExists(atPath: cand.path) {
            cand = dir.appendingPathComponent("\(base) (\(i))." + ext)
            i += 1
            if i > 500 { return nil }
        }
        return cand
    }
}
