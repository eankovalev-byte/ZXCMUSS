import SwiftUI

struct RGB {
    var r: Double, g: Double, b: Double
    init(_ r: Double, _ g: Double, _ b: Double) { self.r = r; self.g = g; self.b = b }
    func color(_ a: Double = 1) -> Color { Color(.sRGB, red: r / 255, green: g / 255, blue: b / 255, opacity: a) }
    func mixed(_ o: RGB, _ t: Double) -> RGB {
        let k = min(max(t, 0), 1)
        return RGB(r + (o.r - r) * k, g + (o.g - g) * k, b + (o.b - b) * k)
    }
    func scaled(_ k: Double) -> RGB { RGB(min(255, r * k), min(255, g * k), min(255, b * k)) }
}

func argb(_ v: UInt32) -> Color {
    Color(.sRGB,
          red: Double((v >> 16) & 255) / 255,
          green: Double((v >> 8) & 255) / 255,
          blue: Double(v & 255) / 255,
          opacity: Double((v >> 24) & 255) / 255)
}

struct Palette {
    let name: String
    let accent: RGB
    let onAccent: RGB
    /// 0 — исходная зелёная, 1 — тёмная с оттенком, 2 — чисто чёрная, 3 — светлая, 4 — графит
    let kind: Int
    let peak: RGB
}

/// Темы оформления (те же 12, что в Android-версии).
final class Theme: ObservableObject {
    static let palettes: [Palette] = [
        Palette(name: "Чёрно-зелёная", accent: RGB(43, 253, 137), onAccent: RGB(0, 23, 10), kind: 0, peak: RGB(0, 0, 0)),
        Palette(name: "Чёрно-красная", accent: RGB(255, 59, 72), onAccent: RGB(255, 255, 255), kind: 1, peak: RGB(64, 12, 18)),
        Palette(name: "Чёрно-жёлтая", accent: RGB(255, 214, 10), onAccent: RGB(26, 20, 0), kind: 1, peak: RGB(56, 46, 6)),
        Palette(name: "Чёрная", accent: RGB(214, 214, 214), onAccent: RGB(0, 0, 0), kind: 2, peak: RGB(0, 0, 0)),
        Palette(name: "Чёрно-белая", accent: RGB(255, 255, 255), onAccent: RGB(0, 0, 0), kind: 1, peak: RGB(46, 46, 48)),
        Palette(name: "Чёрно-синяя", accent: RGB(59, 130, 255), onAccent: RGB(255, 255, 255), kind: 1, peak: RGB(14, 34, 70)),
        Palette(name: "Чёрно-розовая", accent: RGB(255, 64, 160), onAccent: RGB(255, 255, 255), kind: 1, peak: RGB(62, 14, 40)),
        Palette(name: "Чёрно-фиолетовая", accent: RGB(160, 98, 255), onAccent: RGB(255, 255, 255), kind: 1, peak: RGB(38, 20, 66)),
        Palette(name: "Бело-красная", accent: RGB(230, 30, 60), onAccent: RGB(255, 255, 255), kind: 3, peak: RGB(255, 190, 198)),
        Palette(name: "Серая", accent: RGB(214, 218, 226), onAccent: RGB(17, 20, 24), kind: 4, peak: RGB(78, 81, 88)),
        Palette(name: "Белая", accent: RGB(20, 22, 28), onAccent: RGB(255, 255, 255), kind: 3, peak: RGB(208, 212, 220)),
        Palette(name: "Бело-фиолетовая", accent: RGB(110, 60, 230), onAccent: RGB(255, 255, 255), kind: 3, peak: RGB(206, 192, 255))
    ]

    private static let orig: [RGB] = [
        RGB(0, 3, 0), RGB(0, 11, 0), RGB(0, 16, 2), RGB(5, 25, 11), RGB(12, 39, 21), RGB(19, 51, 31), RGB(8, 43, 22),
        RGB(9, 44, 23), RGB(2, 37, 16), RGB(0, 27, 11), RGB(0, 22, 6), RGB(3, 28, 12), RGB(23, 50, 34), RGB(25, 52, 36),
        RGB(1, 26, 10), RGB(0, 17, 2), RGB(0, 13, 0)
    ]
    private static let ks: [Double] = [.058, .21, .31, .48, .75, .98, .83, .85, .71, .52, .42, .54, .96, 1, .5, .33, .25]
    static let stopsPos: [Double] = [0, .09, .125, .16, .22, .25, .31, .40, .50, .60, .66, .69, .75, .78, .84, .90, 1]

    @Published var index: Int {
        didSet {
            UserDefaults.standard.set(index, forKey: "theme")
            build()
        }
    }

    private(set) var light = false
    private(set) var neon = Color.green
    private(set) var neonDark = Color.black
    private(set) var text = Color.white
    private(set) var dim = Color.gray
    private(set) var hint = Color.gray
    private(set) var chipBG = Color.white.opacity(0.08)
    private(set) var chipStroke = Color.white.opacity(0.2)
    private(set) var heartOff = Color.gray
    private(set) var edge = Color.white
    private(set) var panel = Color.black
    private(set) var sheetTop = Color.black
    private(set) var sheetBot = Color.black
    private(set) var lyric = Color.white
    private(set) var lyricDim = Color.gray
    private(set) var line = Color.gray
    private(set) var glow = 1.0
    private(set) var bgStops: [Gradient.Stop] = []
    private(set) var card: [Color] = []

    var palette: Palette { Theme.palettes[index] }

    init() {
        let i = UserDefaults.standard.integer(forKey: "theme")
        index = min(max(i, 0), Theme.palettes.count - 1)
        build()
    }

    private func build() {
        let p = palette
        let kind = p.kind
        let white = RGB(255, 255, 255)
        let black = RGB(0, 0, 0)
        neon = p.accent.color()
        neonDark = p.onAccent.color()
        light = kind == 3
        let textRGB = light ? RGB(21, 23, 28) : white
        text = textRGB.color()
        dim = textRGB.color(0.6)
        hint = textRGB.color(0.4)
        chipBG = textRGB.color(0.08)
        chipStroke = textRGB.color(0.2)
        heartOff = textRGB.color(0.4)

        var stops: [RGB] = []
        for k in 0..<17 {
            switch kind {
            case 0: stops.append(Theme.orig[k])
            case 1: stops.append(black.mixed(p.peak, Theme.ks[k]))
            case 2: stops.append(black)
            case 4: stops.append(RGB(14, 15, 17).mixed(p.peak, Theme.ks[k]))
            default: stops.append(RGB(250, 250, 252).mixed(p.peak, Theme.ks[k] * 0.85))
            }
        }
        bgStops = (0..<17).map { Gradient.Stop(color: stops[$0].color(), location: Theme.stopsPos[$0]) }

        switch kind {
        case 0:
            card = [argb(0xE0071E10), argb(0xCC0A3A22), argb(0xD90C4A2C)]
        case 1:
            card = [p.accent.scaled(0.12).color(0.88), p.accent.scaled(0.23).color(0.8), p.accent.scaled(0.29).color(0.85)]
        case 2:
            card = [p.accent.scaled(0.06).color(0.9), p.accent.scaled(0.10).color(0.85), p.accent.scaled(0.13).color(0.85)]
        case 4:
            card = [p.accent.scaled(0.20).color(0.88), p.accent.scaled(0.30).color(0.8), p.accent.scaled(0.38).color(0.85)]
        default:
            card = [white.mixed(p.peak, 0.25).color(0.94), white.mixed(p.peak, 0.40).color(0.9), white.mixed(p.peak, 0.60).color(0.88)]
        }
        switch kind {
        case 0: edge = argb(0x99B7F5D1)
        case 3: edge = p.accent.color(0.5)
        default: edge = p.accent.mixed(white, 0.55).color(0.6)
        }
        switch kind {
        case 0: panel = argb(0xF5020A05); sheetTop = argb(0xF4082015); sheetBot = argb(0xF6030A06)
        case 1: panel = p.accent.scaled(0.04).color(0.96); sheetTop = p.accent.scaled(0.13).color(0.96); sheetBot = p.accent.scaled(0.04).color(0.96)
        case 2: panel = argb(0xF5000000); sheetTop = argb(0xF4101010); sheetBot = argb(0xF6000000)
        case 4: panel = p.accent.scaled(0.07).color(0.96); sheetTop = p.accent.scaled(0.20).color(0.96); sheetBot = p.accent.scaled(0.08).color(0.96)
        default: panel = argb(0xF8FAFAFC); sheetTop = argb(0xF8FFFFFF); sheetBot = argb(0xF8F1F1F5)
        }
        switch kind {
        case 0: lyric = argb(0xFFE9FFF3)
        case 3: lyric = text
        default: lyric = white.mixed(p.accent, 0.08).color()
        }
        lyricDim = lyric.opacity(0.55)
        line = kind == 0 ? Color(.sRGB, red: 170 / 255, green: 225 / 255, blue: 195 / 255, opacity: 0.37) : textRGB.color(0.37)
        switch kind {
        case 2: glow = 0.25
        case 3: glow = 0.5
        case 4: glow = 0.6
        default: glow = 1
        }
    }

    func accent(_ a: Double) -> Color { neon.opacity(a) }
}
