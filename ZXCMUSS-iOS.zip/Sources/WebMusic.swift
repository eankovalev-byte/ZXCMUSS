import Foundation

/// Поиск и скачивание ТОЛЬКО свободной музыки: Audius (если автор разрешил скачивание),
/// Internet Archive и Jamendo (Creative Commons).
struct WebItem: Identifiable {
    let id: String          // уникальный ключ
    let source: Int         // 0 archive, 1 jamendo, 2 audius
    let rawId: String
    let title: String
    let artist: String
    let durationSec: Int
    let url: String?
}

struct WebFile: Identifiable {
    var id: String { url }
    let title: String
    let durationSec: Int
    let url: String
}

struct Genre { let label: String; let audius: String; let jamendo: String; let archive: String }

struct JamendoKeyError: Error {}

enum WebMusic {
    static let genres: [Genre] = [
        Genre(label: "Популярное", audius: "", jamendo: "", archive: ""),
        Genre(label: "Хип-хоп", audius: "Hip-Hop/Rap", jamendo: "hiphop", archive: "hip hop"),
        Genre(label: "Trap", audius: "Trap", jamendo: "trap", archive: "trap"),
        Genre(label: "Электроника", audius: "Electronic", jamendo: "electronic", archive: "electronic"),
        Genre(label: "Рок", audius: "Rock", jamendo: "rock", archive: "rock"),
        Genre(label: "Поп", audius: "Pop", jamendo: "pop", archive: "pop"),
        Genre(label: "Lo-Fi", audius: "Lo-Fi", jamendo: "lofi", archive: "lofi"),
        Genre(label: "Hyperpop", audius: "Hyperpop", jamendo: "", archive: "hyperpop"),
        Genre(label: "House", audius: "House", jamendo: "house", archive: "house"),
        Genre(label: "Drum & Bass", audius: "Drum & Bass", jamendo: "drumnbass", archive: "drum and bass")
    ]

    static func enc(_ s: String) -> String {
        var cs = CharacterSet.urlQueryAllowed
        cs.remove(charactersIn: "&+=?#/:;@$,")
        return s.addingPercentEncoding(withAllowedCharacters: cs) ?? s
    }

    static func encPath(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)?
            .replacingOccurrences(of: "/", with: "%2F") ?? s
    }

    static func getJSON(_ s: String) async throws -> Any {
        guard let u = URL(string: s) else { throw URLError(.badURL) }
        var r = URLRequest(url: u)
        r.timeoutInterval = 20
        r.setValue("ZXCMUSS/3.1", forHTTPHeaderField: "User-Agent")
        let (d, resp) = try await URLSession.shared.data(for: r)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try JSONSerialization.jsonObject(with: d)
    }

    private static func str(_ o: Any?) -> String {
        if let s = o as? String { return s }
        if let a = o as? [Any], let s = a.first as? String { return s }
        return ""
    }

    // MARK: Internet Archive

    private static func archiveDocs(_ query: String, sort: String) async throws -> [WebItem] {
        let url = "https://archive.org/advancedsearch.php?q=" + enc(query) +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&rows=30&page=1&output=json&sort%5B%5D=" + enc(sort)
        guard let root = try await getJSON(url) as? [String: Any],
              let resp = root["response"] as? [String: Any],
              let docs = resp["docs"] as? [[String: Any]] else { return [] }
        var out: [WebItem] = []
        for d in docs {
            let id = str(d["identifier"])
            if id.isEmpty { continue }
            let t = str(d["title"])
            out.append(WebItem(id: "a:" + id, source: 0, rawId: id, title: t.isEmpty ? id : t, artist: str(d["creator"]), durationSec: 0, url: nil))
        }
        return out
    }

    static func searchArchive(_ q: String) async throws -> [WebItem] {
        let cleaned = q.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? Character($0) : " " }
        let toks = String(cleaned).split(separator: " ").map(String.init)
        if toks.isEmpty { return [] }
        func part(_ t: String) -> String {
            let fz = t.count >= 4 ? " OR \(t)~" : ""
            return "(title:(\(t) OR \(t)*\(fz)) OR creator:(\(t) OR \(t)*\(fz)))"
        }
        let strict = toks.map(part).joined(separator: " AND ")
        var r = try await archiveDocs("(\(strict)) AND mediatype:audio", sort: "downloads desc")
        if r.isEmpty && toks.count > 1 {
            let loose = toks.map(part).joined(separator: " OR ")
            r = try await archiveDocs("(\(loose)) AND mediatype:audio", sort: "downloads desc")
        }
        return r
    }

    static func popularArchive(_ g: Genre) async throws -> [WebItem] {
        let sub = g.archive.isEmpty ? "" : " AND subject:(\(g.archive))"
        return try await archiveDocs("mediatype:audio AND format:MP3\(sub)", sort: "week desc")
    }

    static func archiveFiles(_ id: String) async throws -> [WebFile] {
        guard let root = try await getJSON("https://archive.org/metadata/" + encPath(id)) as? [String: Any],
              let files = root["files"] as? [[String: Any]] else { return [] }
        var seen = Set<String>()
        var out: [WebFile] = []
        for f in files {
            let name = (f["name"] as? String) ?? ""
            if !name.lowercased().hasSuffix(".mp3") { continue }
            var title = (f["title"] as? String) ?? ""
            if title.isEmpty { title = ((name as NSString).lastPathComponent as NSString).deletingPathExtension }
            if !seen.insert(title.lowercased()).inserted { continue }
            let path = name.split(separator: "/").map { encPath(String($0)) }.joined(separator: "/")
            let url = "https://archive.org/download/" + encPath(id) + "/" + path
            out.append(WebFile(title: title, durationSec: parseLen((f["length"] as? String) ?? ""), url: url))
            if out.count >= 60 { break }
        }
        return out
    }

    private static func parseLen(_ s: String) -> Int {
        if s.isEmpty { return 0 }
        var t = 0.0
        for p in s.split(separator: ":") { t = t * 60 + (Double(p) ?? 0) }
        return Int(t)
    }

    // MARK: Audius

    private static func audiusItems(_ url: String) async throws -> [WebItem] {
        guard let root = try await getJSON(url) as? [String: Any],
              let arr = root["data"] as? [[String: Any]] else { return [] }
        var out: [WebItem] = []
        for o in arr {
            let id = str(o["id"])
            if id.isEmpty { continue }
            if let st = o["is_streamable"] as? Bool, !st { continue }
            let dl = (o["is_downloadable"] as? Bool) ?? (o["downloadable"] as? Bool) ?? false
            var ok = dl
            if let acc = o["access"] as? [String: Any], let d = acc["download"] as? Bool, !d { ok = false }
            let user = ((o["user"] as? [String: Any])?["name"] as? String) ?? ""
            out.append(WebItem(id: "x:" + id, source: 2, rawId: id, title: str(o["title"]), artist: user,
                               durationSec: (o["duration"] as? Int) ?? 0,
                               url: ok ? "https://api.audius.co/v1/tracks/\(id)/stream?app_name=ZXCMUSS" : nil))
        }
        return out
    }

    static func searchAudius(_ q: String) async throws -> [WebItem] {
        try await audiusItems("https://api.audius.co/v1/tracks/search?app_name=ZXCMUSS&limit=30&query=" + enc(q))
    }

    static func popularAudius(_ g: Genre) async throws -> [WebItem] {
        try await audiusItems("https://api.audius.co/v1/tracks/trending?app_name=ZXCMUSS&limit=30&time=week" +
                              (g.audius.isEmpty ? "" : "&genre=" + enc(g.audius)))
    }

    // MARK: Jamendo

    private static func jamendoItems(_ url: String) async throws -> [WebItem] {
        guard let root = try await getJSON(url) as? [String: Any] else { return [] }
        if let h = root["headers"] as? [String: Any], (h["status"] as? String) == "failed" { throw JamendoKeyError() }
        guard let res = root["results"] as? [[String: Any]] else { return [] }
        var out: [WebItem] = []
        for o in res {
            let dl = (o["audiodownload"] as? String) ?? ""
            if dl.isEmpty || !((o["audiodownload_allowed"] as? Bool) ?? false) { continue }
            let id = str(o["id"])
            out.append(WebItem(id: "j:" + id, source: 1, rawId: id, title: str(o["name"]), artist: str(o["artist_name"]),
                               durationSec: (o["duration"] as? Int) ?? 0, url: dl))
        }
        return out
    }

    static func searchJamendo(_ q: String, key: String) async throws -> [WebItem] {
        try await jamendoItems("https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(key) +
                               "&format=json&limit=30&audiodlformat=mp32&search=" + enc(q))
    }

    static func popularJamendo(_ g: Genre, key: String) async throws -> [WebItem] {
        try await jamendoItems("https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(key) +
                               "&format=json&limit=30&audiodlformat=mp32&order=popularity_week" +
                               (g.jamendo.isEmpty ? "" : "&tags=" + enc(g.jamendo)))
    }

    // MARK: умный разбор запроса

    private static let en = Array("qwertyuiop[]asdfghjkl;'zxcvbnm,./")
    private static let ru = Array("йцукенгшщзхъфывапролджэячсмитьбю.")
    private static let tr: [Character: String] = [
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
        "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
        "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
        "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya"
    ]

    private static func swapLayout(_ q: String) -> String {
        let low = Array(q.lowercased())
        let toRu = low.contains { $0 >= "a" && $0 <= "z" }
        return String(low.map { ch -> Character in
            if toRu { if let i = en.firstIndex(of: ch) { return ru[i] } }
            else if let i = ru.firstIndex(of: ch) { return en[i] }
            return ch
        })
    }

    private static func translit(_ q: String) -> String {
        q.lowercased().map { tr[$0] ?? String($0) }.joined()
    }

    static func variants(_ q: String) -> [String] {
        let base = q.split(separator: " ").joined(separator: " ")
        var list = [base, swapLayout(base)]
        if base.lowercased().contains(where: { tr[$0] != nil }) { list.append(translit(base)) }
        let w = base.split(separator: " ")
        if w.count > 1 { list.append(w.dropLast().joined(separator: " ")) }
        var seen = Set<String>()
        return list.filter { !$0.isEmpty && seen.insert($0).inserted }
    }

    static func search(source: Int, q: String, genre: Int, key: String) async throws -> [WebItem] {
        let g = genres[min(max(genre, 0), genres.count - 1)]
        if q.trimmingCharacters(in: .whitespaces).isEmpty {
            switch source {
            case 0: return try await popularArchive(g)
            case 1: return try await popularJamendo(g, key: key)
            default: return try await popularAudius(g)
            }
        }
        for v in variants(q) {
            let r: [WebItem]
            switch source {
            case 0: r = try await searchArchive(v)
            case 1: r = try await searchJamendo(v, key: key)
            default: r = try await searchAudius(v)
            }
            if !r.isEmpty { return r }
        }
        return []
    }

    // MARK: скачивание

    static func safeName(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "\\/:*?\"<>|")
        let t = s.components(separatedBy: bad).joined(separator: "_").split(separator: " ").joined(separator: " ")
        return String(t.prefix(120))
    }

    /// Скачивает в папку «Музыка» приложения. Возвращает id трека.
    static func download(url: String, title: String, artist: String, progress: @escaping (Double) -> Void) async -> String? {
        guard let u = URL(string: url) else { return nil }
        let dl = Downloader(progress: progress)
        guard let (tmp, resp) = try? await dl.fetch(u) else { return nil }
        defer { try? FileManager.default.removeItem(at: tmp) }
        if let h = resp as? HTTPURLResponse, h.statusCode != 200 { return nil }
        let mime = (resp?.mimeType ?? "").lowercased()
        var ext = "mp3"
        if mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") { ext = "m4a" }
        else if mime.contains("flac") { ext = "flac" }
        else if mime.contains("wav") { ext = "wav" }
        else if url.lowercased().contains(".m4a") { ext = "m4a" }
        let base = artist.isEmpty ? title : "\(artist) - \(title)"
        let name = Library.uniqueDest(safeName(base) + "." + ext)
        guard let dest = name else { return nil }
        do { try FileManager.default.copyItem(at: tmp, to: dest) } catch { return nil }
        return "f:" + dest.lastPathComponent
    }
}

final class Downloader: NSObject, URLSessionDownloadDelegate {
    private let progress: (Double) -> Void
    private var cont: CheckedContinuation<(URL, URLResponse?), Error>?
    private var session: URLSession?
    private var moved: URL?

    init(progress: @escaping (Double) -> Void) { self.progress = progress }

    func fetch(_ url: URL) async throws -> (URL, URLResponse?) {
        try await withCheckedThrowingContinuation { c in
            self.cont = c
            let s = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
            self.session = s
            var r = URLRequest(url: url)
            r.timeoutInterval = 30
            r.setValue("ZXCMUSS/3.1", forHTTPHeaderField: "User-Agent")
            s.downloadTask(with: r).resume()
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        if totalBytesExpectedToWrite > 0 { progress(Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)) }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let keep = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try? FileManager.default.moveItem(at: location, to: keep)
        moved = keep
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        session.finishTasksAndInvalidate()
        guard let c = cont else { return }
        cont = nil
        if let e = error { c.resume(throwing: e) }
        else if let m = moved { c.resume(returning: (m, task.response)) }
        else { c.resume(throwing: URLError(.cannotCreateFile)) }
    }
}
