import SwiftUI

struct SheetBG: View {
    @EnvironmentObject var t: Theme
    var body: some View {
        LinearGradient(colors: [t.sheetTop, t.sheetBot], startPoint: .top, endPoint: .bottom)
            .background(t.light ? Color.white : Color.black)
            .ignoresSafeArea()
    }
}

struct Pill: View {
    @EnvironmentObject var t: Theme
    let title: String
    let on: Bool
    var small = false
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: small ? 13 : 14, weight: .semibold))
                .foregroundColor(on ? t.neonDark : t.text)
                .padding(.horizontal, small ? 14 : 18)
                .padding(.vertical, small ? 6 : 8)
                .background(Capsule().fill(on ? t.neon : t.chipBG))
                .overlay(Capsule().strokeBorder(on ? Color.clear : t.chipStroke, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct LibraryView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var lib: Library
    @EnvironmentObject var player: Player
    @EnvironmentObject var prefs: Prefs
    @Environment(\.dismiss) private var dismiss

    @State private var tab = 0
    @State private var query = ""

    private var filtered: [Track] {
        var base = lib.tracks
        if tab == 1 { base = base.filter { lib.favs.contains($0.id) } }
        if tab == 2 { base = base.filter { lib.downloads.contains($0.id) } }
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        if !q.isEmpty { base = base.filter { ($0.title + " " + $0.artist).lowercased().contains(q) } }
        switch prefs.sortMode {
        case 1: base.sort { $0.artist.lowercased() < $1.artist.lowercased() }
        case 2: base.sort { $0.added > $1.added }
        default: base.sort { $0.title.lowercased() < $1.title.lowercased() }
        }
        return base
    }

    var body: some View {
        let list = filtered
        ZStack {
            SheetBG()
            VStack(spacing: 0) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Музыка").font(.system(size: 24, weight: .bold)).foregroundColor(t.text)
                        Text("\(lib.tracks.count) треков").font(.system(size: 12)).foregroundColor(t.dim)
                    }
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark").font(.system(size: 18, weight: .semibold)).foregroundColor(t.text).frame(width: 44, height: 44)
                    }
                }
                .padding(.horizontal, 20).padding(.top, 12)

                HStack {
                    Image(systemName: "magnifyingglass").foregroundColor(t.hint)
                    TextField("", text: $query, prompt: Text("Поиск по названию").foregroundColor(t.hint))
                        .foregroundColor(t.text)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 16).frame(height: 44)
                .background(Capsule().fill(t.accent(0.12)))
                .overlay(Capsule().strokeBorder(t.accent(0.2), lineWidth: 1))
                .padding(.horizontal, 16).padding(.top, 8)

                HStack(spacing: 8) {
                    Pill(title: "Все", on: tab == 0) { tab = 0 }
                    Pill(title: "Избранное", on: tab == 1) { tab = 1 }
                    Pill(title: "Загрузки", on: tab == 2) { tab = 2 }
                    Spacer()
                }
                .padding(.horizontal, 16).padding(.vertical, 10)

                if list.isEmpty {
                    Spacer()
                    Text(emptyText)
                        .font(.system(size: 15)).foregroundColor(t.dim)
                        .multilineTextAlignment(.center).padding(.horizontal, 32)
                    if tab == 0 && lib.tracks.isEmpty {
                        Button("Разрешить доступ к Apple Music") { lib.requestAppleMusic() }
                            .foregroundColor(t.neon).padding(.top, 10)
                    }
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(Array(list.enumerated()), id: \.element.id) { i, tr in
                                row(tr, list: list, i: i)
                            }
                        }
                        .padding(.horizontal, 10).padding(.bottom, 90)
                    }
                }
            }
            VStack { Spacer(); miniPlayer }
        }
    }

    private var emptyText: String {
        if tab == 1 { return "Нажмите сердечко на плеере, чтобы добавить трек в избранное." }
        if tab == 2 { return "Здесь будут скачанные и добавленные треки: меню → «Музыка из интернета» или «Telegram и файлы»." }
        if !lib.tracks.isEmpty { return "Ничего не найдено" }
        return "Музыки пока нет. Добавьте файлы через меню → «Telegram и файлы» или разрешите доступ к Apple Music."
    }

    private func row(_ tr: Track, list: [Track], i: Int) -> some View {
        let cur = player.current?.id == tr.id
        return Button {
            player.setQueue(list, start: i, autoplay: true)
            dismiss()
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 13).fill(t.accent(0.12)).frame(width: 46, height: 46)
                    Image(systemName: cur && player.isPlaying ? "waveform" : "music.note")
                        .foregroundColor(t.neon).font(.system(size: 18, weight: .semibold))
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr.title).font(.system(size: 16, weight: .medium)).foregroundColor(cur ? t.neon : t.text).lineLimit(1)
                    Text(tr.artist.isEmpty ? "Неизвестный исполнитель" : tr.artist).font(.system(size: 13)).foregroundColor(t.dim).lineLimit(1)
                }
                Spacer()
                Text(fmtTime(tr.duration)).font(.system(size: 12)).foregroundColor(t.dim)
                if lib.favs.contains(tr.id) { Image(systemName: "heart.fill").foregroundColor(t.neon).font(.system(size: 13)) }
            }
            .padding(.horizontal, 8).padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button { lib.toggleFav(tr.id) } label: { Label(lib.favs.contains(tr.id) ? "Убрать из избранного" : "В избранное", systemImage: "heart") }
            if tr.id.hasPrefix("f:") {
                Button(role: .destructive) {
                    try? FileManager.default.removeItem(at: tr.url)
                    Task { await lib.reload() }
                } label: { Label("Удалить файл", systemImage: "trash") }
            }
        }
    }

    private var miniPlayer: some View {
        Group {
            if let c = player.current {
                HStack(spacing: 10) {
                    Image(systemName: "music.note").foregroundColor(t.neon)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(c.title).font(.system(size: 14, weight: .semibold)).foregroundColor(t.text).lineLimit(1)
                        Text(c.artist.isEmpty ? "Неизвестный исполнитель" : c.artist).font(.system(size: 12)).foregroundColor(t.dim).lineLimit(1)
                    }
                    Spacer()
                    Button { player.toggle() } label: {
                        Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").foregroundColor(t.text).font(.system(size: 20)).frame(width: 40, height: 40)
                    }
                    Button { player.next() } label: {
                        Image(systemName: "forward.fill").foregroundColor(t.text).font(.system(size: 18)).frame(width: 40, height: 40)
                    }
                }
                .padding(.horizontal, 16).frame(height: 62)
                .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(.ultraThinMaterial))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(t.edge.opacity(0.6), lineWidth: 1))
                .padding(.horizontal, 12).padding(.bottom, 8)
            }
        }
    }
}
