import SwiftUI

struct ArchiveSheet: Identifiable {
    let id = UUID()
    let title: String
    let artist: String
    let files: [WebFile]
}

struct WebMusicView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var lib: Library
    @EnvironmentObject var prefs: Prefs

    @State private var source = 2
    @State private var genre = 0
    @State private var query = ""
    @State private var items: [WebItem] = []
    @State private var status = "Загружаю популярное…"
    @State private var busy = false
    @State private var loaded = false
    @State private var progress: [String: Double] = [:]
    @State private var done: Set<String> = []
    @State private var archive: ArchiveSheet?
    @State private var askKey = false
    @State private var keyText = ""
    @State private var toast: String?
    @State private var searchToken = 0

    var body: some View {
        ZStack {
            SheetBG()
            VStack(spacing: 0) {
                Text("Только свободная и бесплатная музыка (Creative Commons)")
                    .font(.system(size: 12)).foregroundColor(t.dim).padding(.top, 4)
                HStack(spacing: 8) {
                    Pill(title: "Audius", on: source == 2) { setSource(2) }
                    Pill(title: "Archive", on: source == 0) { setSource(0) }
                    Pill(title: "Jamendo", on: source == 1) { setSource(1) }
                    Spacer()
                }
                .padding(.horizontal, 16).padding(.top, 10)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(0..<WebMusic.genres.count, id: \.self) { i in
                            Pill(title: WebMusic.genres[i].label, on: genre == i, small: true) {
                                genre = i; query = ""; search()
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .padding(.vertical, 10)

                HStack {
                    Image(systemName: "magnifyingglass").foregroundColor(t.hint)
                    TextField("", text: $query, prompt: Text("Песня или исполнитель (можно неточно)").foregroundColor(t.hint))
                        .foregroundColor(t.text)
                        .submitLabel(.search)
                        .autocorrectionDisabled()
                        .onSubmit { search() }
                }
                .padding(.horizontal, 16).frame(height: 46)
                .background(Capsule().fill(t.accent(0.12)))
                .overlay(Capsule().strokeBorder(t.accent(0.2), lineWidth: 1))
                .padding(.horizontal, 16).padding(.bottom, 6)

                if items.isEmpty {
                    Text(status).font(.system(size: 14)).foregroundColor(t.dim)
                        .multilineTextAlignment(.center).padding(24)
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(items) { it in row(it) }
                        }
                        .padding(.horizontal, 10).padding(.bottom, 20)
                    }
                }
            }
            if let m = toast {
                VStack {
                    Spacer()
                    Text(m).font(.system(size: 14, weight: .medium)).foregroundColor(t.text)
                        .padding(.horizontal, 18).padding(.vertical, 10)
                        .background(Capsule().fill(.ultraThinMaterial))
                        .padding(.bottom, 24)
                }
                .transition(.opacity)
            }
        }
        .navigationTitle("Музыка из интернета")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $archive) { a in ArchiveFilesView(sheet: a, start: { f in
            archive = nil
            startDownload(key: "a:" + f.url, url: f.url, title: f.title, artist: a.artist)
        }) }
        .sheet(isPresented: $askKey) { keySheet }
        .task {
            if !loaded { loaded = true; search() }
        }
    }

    private func row(_ it: WebItem) -> some View {
        Button { tap(it) } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(it.title).font(.system(size: 16, weight: .medium)).foregroundColor(t.text).lineLimit(2)
                    let sub = [it.artist, it.durationSec > 0 ? fmtTime(Double(it.durationSec)) : ""].filter { !$0.isEmpty }.joined(separator: " · ")
                    Text(sub).font(.system(size: 13)).foregroundColor(t.dim).lineLimit(1)
                }
                Spacer()
                Text(stateText(it)).font(.system(size: 13, weight: .bold)).foregroundColor(t.neon)
            }
            .padding(.horizontal, 8).padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func stateText(_ it: WebItem) -> String {
        if it.source == 0 { return "Треки ›" }
        if let p = progress[it.id] { return "\(Int(p * 100))%" }
        if done.contains(it.id) { return "✓" }
        return it.url == nil ? "—" : "Скачать"
    }

    private func tap(_ it: WebItem) {
        if it.source == 0 {
            Task { @MainActor in
                if let files = try? await WebMusic.archiveFiles(it.rawId), !files.isEmpty {
                    archive = ArchiveSheet(title: it.title, artist: it.artist, files: files)
                } else { show("В этой записи нет mp3-треков") }
            }
        } else if let u = it.url {
            startDownload(key: it.id, url: u, title: it.title, artist: it.artist)
        } else {
            show("Автор закрыл скачивание этого трека")
        }
    }

    private func startDownload(key: String, url: String, title: String, artist: String) {
        if progress[key] != nil { return }
        if done.contains(key) { show("Уже скачано"); return }
        progress[key] = 0
        show("Скачиваю: \(title)")
        Task { @MainActor in
            let id = await WebMusic.download(url: url, title: title, artist: artist) { p in
                Task { @MainActor in progress[key] = p }
            }
            progress[key] = nil
            if let id = id {
                done.insert(key)
                lib.markDownloaded(id)
                await lib.reload()
                show("Скачано и добавлено в «Загрузки»")
            } else {
                show("Не удалось скачать")
            }
        }
    }

    private func setSource(_ s: Int) {
        source = s
        search()
    }

    private func search() {
        if source == 1 && prefs.jamendoKey.trimmingCharacters(in: .whitespaces).isEmpty {
            items = []
            status = "Для Jamendo нужен бесплатный ключ (Client ID)."
            askKey = true
            return
        }
        searchToken += 1
        let token = searchToken
        let src = source, g = genre, q = query, key = prefs.jamendoKey
        status = "Ищу…"
        items = []
        Task { @MainActor in
            do {
                let r = try await WebMusic.search(source: src, q: q, genre: g, key: key)
                guard token == searchToken else { return }
                items = r
                if r.isEmpty { status = "Ничего не найдено" }
            } catch is JamendoKeyError {
                guard token == searchToken else { return }
                prefs.jamendoKey = ""
                status = "Ключ Jamendo не подошёл. Выберите Jamendo и введите ключ заново."
            } catch {
                guard token == searchToken else { return }
                status = "Нет соединения или сервис не отвечает."
            }
        }
    }

    private func show(_ s: String) {
        withAnimation { toast = s }
        let cur = s
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            if toast == cur { withAnimation { toast = nil } }
        }
    }

    private var keySheet: some View {
        ZStack {
            SheetBG()
            VStack(alignment: .leading, spacing: 14) {
                Text("Ключ Jamendo").font(.system(size: 22, weight: .bold)).foregroundColor(t.text)
                Text("Jamendo — музыка под лицензией Creative Commons. Нужен бесплатный ключ (Client ID): создайте приложение на devportal.jamendo.com и вставьте ключ сюда.")
                    .font(.system(size: 14)).foregroundColor(t.text.opacity(0.8))
                TextField("Client ID", text: $keyText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(t.accent(0.12)))
                    .foregroundColor(t.text)
                HStack {
                    Button("Открыть сайт") {
                        if let u = URL(string: "https://devportal.jamendo.com/") { UIApplication.shared.open(u) }
                    }
                    Spacer()
                    Button("Сохранить") {
                        prefs.jamendoKey = keyText.trimmingCharacters(in: .whitespaces)
                        askKey = false
                        search()
                    }
                    .font(.system(size: 16, weight: .bold))
                }
                .foregroundColor(t.neon)
                Spacer()
            }
            .padding(24)
        }
        .presentationDetents([.medium])
    }
}

struct ArchiveFilesView: View {
    @EnvironmentObject var t: Theme
    let sheet: ArchiveSheet
    let start: (WebFile) -> Void

    var body: some View {
        ZStack {
            SheetBG()
            VStack(alignment: .leading, spacing: 0) {
                Text(sheet.title).font(.system(size: 20, weight: .bold)).foregroundColor(t.text)
                    .lineLimit(2).padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 8)
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(sheet.files) { f in
                            Button { start(f) } label: {
                                HStack {
                                    Image(systemName: "arrow.down.circle").foregroundColor(t.neon)
                                    Text(f.title).foregroundColor(t.text).font(.system(size: 16)).lineLimit(2)
                                    Spacer()
                                    if f.durationSec > 0 { Text(fmtTime(Double(f.durationSec))).foregroundColor(t.dim).font(.system(size: 12)) }
                                }
                                .padding(.horizontal, 20).padding(.vertical, 10)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
        }
    }
}
