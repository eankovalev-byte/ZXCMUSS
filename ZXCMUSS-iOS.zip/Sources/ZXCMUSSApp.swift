import SwiftUI

@main
struct ZXCMUSSApp: App {
    @StateObject private var theme = Theme()
    @StateObject private var lib = Library()
    @StateObject private var player = Player()
    @StateObject private var lyrics = Lyrics()
    @StateObject private var prefs = Prefs()

    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(theme)
                .environmentObject(lib)
                .environmentObject(player)
                .environmentObject(lyrics)
                .environmentObject(prefs)
                .preferredColorScheme(theme.light ? .light : .dark)
                .onOpenURL { url in
                    // «Поделиться → Открыть в ZXCMUSS» из Telegram, Файлов и других приложений
                    Task { @MainActor in
                        let n = await lib.importURLs([url])
                        if n > 0 { lib.notice = "Добавлено треков: \(n) (вкладка «Загрузки»)" }
                    }
                }
        }
    }
}

/// Настройки, не связанные с темой.
final class Prefs: ObservableObject {
    @Published var onlineLyrics: Bool { didSet { UserDefaults.standard.set(onlineLyrics, forKey: "online") } }
    @Published var sortMode: Int { didSet { UserDefaults.standard.set(sortMode, forKey: "sort") } }
    @Published var jamendoKey: String { didSet { UserDefaults.standard.set(jamendoKey, forKey: "jamendo") } }

    init() {
        onlineLyrics = UserDefaults.standard.object(forKey: "online") as? Bool ?? true
        sortMode = UserDefaults.standard.integer(forKey: "sort")
        jamendoKey = UserDefaults.standard.string(forKey: "jamendo") ?? ""
    }
}
