import SwiftUI

// MARK: - фон: чёрно-зелёная дымка, пульсирует от баса

struct AuroraView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { _ in
            let _ = player.isPlaying ? () : player.spectrum.decay()
            let energy = Double(min(1, player.spectrum.bass * 1.4))
            GeometryReader { g in
                ZStack {
                    LinearGradient(stops: t.bgStops, startPoint: .top, endPoint: .bottom)
                    RadialGradient(colors: [t.neon.opacity((0.04 + 0.28 * energy) * t.glow), .clear],
                                   center: UnitPoint(x: 0.5, y: 0.62),
                                   startRadius: 0, endRadius: g.size.width * 0.95)
                        .blendMode(.plusLighter)
                }
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - спектр (бары зеркально, по реальному звуку)

struct SpectrumView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { _ in
            let _ = player.isPlaying ? () : player.spectrum.decay()
            let bands = player.spectrum.get()
            Canvas { ctx, size in
                let n = bands.count * 2
                let gap: CGFloat = 2
                let w = (size.width - gap * CGFloat(n - 1)) / CGFloat(n)
                let mid = size.height / 2
                for i in 0..<n {
                    let b = i < bands.count ? bands.count - 1 - i : i - bands.count
                    let lv = CGFloat(bands[b])
                    let h = max(4, lv * size.height * 0.98)
                    let x = CGFloat(i) * (w + gap)
                    let r = CGRect(x: x, y: mid - h / 2, width: w, height: h)
                    ctx.fill(Path(roundedRect: r, cornerRadius: w / 2), with: .color(t.neon.opacity(0.55 + 0.45 * Double(lv))))
                }
            }
        }
    }
}

struct MiniEq: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { _ in
            let v = [player.spectrum.bass, player.spectrum.mid, player.spectrum.high * 2, player.spectrum.mid]
            Canvas { ctx, size in
                let w: CGFloat = 4
                for i in 0..<4 {
                    let h = max(5, CGFloat(min(1, v[i] * 1.5)) * size.height)
                    let x = CGFloat(i) * (w + 3)
                    let r = CGRect(x: x, y: size.height - h, width: w, height: h)
                    ctx.fill(Path(roundedRect: r, cornerRadius: 2), with: .color(t.neon))
                }
            }
        }
        .frame(width: 25, height: 22)
    }
}

// MARK: - прогресс «змейкой»

struct SnakeSeek: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player
    @State private var dragging = false
    @State private var dragProgress: Double = 0

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60)) { tl in
            let phase = tl.date.timeIntervalSinceReferenceDate
            let prog = dragging ? dragProgress : (player.duration > 0 ? player.position / player.duration : 0)
            Canvas { ctx, size in
                let pad: CGFloat = 8
                let x0 = pad, x1 = size.width - pad
                let midY = size.height / 2
                let px = x0 + (x1 - x0) * CGFloat(min(max(prog, 0), 1))
                // прямая линия справа
                var rest = Path()
                rest.move(to: CGPoint(x: px, y: midY))
                rest.addLine(to: CGPoint(x: x1, y: midY))
                ctx.stroke(rest, with: .color(t.line), style: StrokeStyle(lineWidth: 2, lineCap: .round))
                // волна слева
                let amp: CGFloat = dragging ? 5 : 3.4
                let len: CGFloat = 22
                let sp = player.isPlaying || dragging ? phase * 5 : 0
                var wave = Path()
                var x = x0
                wave.move(to: CGPoint(x: x0, y: midY))
                while x <= px {
                    let k = min(1, (px - x) / 18) * min(1, (x - x0) / 10 + 0.15)
                    let y = midY + sin((x / len) * 2 * .pi - CGFloat(sp)) * amp * k
                    wave.addLine(to: CGPoint(x: x, y: y))
                    x += 1.5
                }
                ctx.stroke(wave, with: .color(t.neon.opacity(0.22)), style: StrokeStyle(lineWidth: 7, lineCap: .round, lineJoin: .round))
                ctx.stroke(wave, with: .color(t.neon), style: StrokeStyle(lineWidth: 2.6, lineCap: .round, lineJoin: .round))
                // ползунок
                let th: CGFloat = dragging ? 15 : 12
                let thumb = CGRect(x: px - 1.6, y: midY - th, width: 3.2, height: th * 2)
                ctx.fill(Path(roundedRect: thumb, cornerRadius: 1.6), with: .color(t.neon))
            }
        }
        .frame(height: 34)
        .overlay(
            GeometryReader { g in
                Color.clear.contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 0)
                        .onChanged { v in
                            dragging = true
                            dragProgress = Double(min(max((v.location.x - 8) / max(1, g.size.width - 16), 0), 1))
                        }
                        .onEnded { v in
                            let p = Double(min(max((v.location.x - 8) / max(1, g.size.width - 16), 0), 1))
                            player.seek(to: p * player.duration)
                            dragging = false
                        })
            }
        )
    }
}

// MARK: - «жидкое стекло» (как iOS 26) для кнопки паузы

struct GlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.55), value: configuration.isPressed)
    }
}

struct GlassCircle: View {
    @EnvironmentObject var t: Theme

    var body: some View {
        let accent = t.neon
        ZStack {
            // свечение
            Circle().fill(accent.opacity(0.35)).blur(radius: 18).scaleEffect(1.05)
            // матовое стекло (настоящее размытие фона)
            Circle().fill(.ultraThinMaterial)
            // оттенок
            Circle().fill(LinearGradient(
                colors: [Color.white.opacity(t.light ? 0 : 0.30), accent.opacity(t.light ? 0.45 : 0.22), Color.white.opacity(t.light ? 0.1 : 0.08)],
                startPoint: .topLeading, endPoint: .bottomTrailing))
            // преломление у краёв
            Circle().fill(RadialGradient(colors: [.clear, .clear, Color.white.opacity(0.22)], center: .center, startRadius: 0, endRadius: 45))
            // верхний блик
            Ellipse()
                .fill(LinearGradient(colors: [Color.white.opacity(0.5), Color.white.opacity(0)], startPoint: .top, endPoint: .bottom))
                .frame(width: 58, height: 34)
                .offset(y: -22)
                .mask(Circle())
            // нижний отсвет
            Ellipse()
                .fill(LinearGradient(colors: [accent.opacity(0.4), accent.opacity(0)], startPoint: .bottom, endPoint: .top))
                .frame(width: 46, height: 26)
                .offset(y: 28)
                .mask(Circle())
            // светящаяся кромка
            Circle().strokeBorder(
                AngularGradient(gradient: Gradient(stops: [
                    .init(color: Color.white.opacity(0.2), location: 0),
                    .init(color: Color.white.opacity(0.85), location: 0.13),
                    .init(color: Color.white.opacity(0.1), location: 0.3),
                    .init(color: Color.white.opacity(0.08), location: 0.5),
                    .init(color: Color.white.opacity(0.9), location: 0.63),
                    .init(color: Color.white.opacity(0.2), location: 1)
                ]), center: .center),
                lineWidth: 1.6)
        }
    }
}

// MARK: - перенос слов по строкам (для текста с подсветкой)

struct FlowLayout: Layout {
    var spacing: CGFloat = 0
    var lineSpacing: CGFloat = 4

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, w: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x + sz.width > maxW && x > 0 { y += rowH + lineSpacing; x = 0; rowH = 0 }
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
            w = max(w, x - spacing)
        }
        return CGSize(width: w, height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x + sz.width > bounds.width && x > 0 { y += rowH + lineSpacing; x = 0; rowH = 0 }
            s.place(at: CGPoint(x: bounds.minX + x, y: bounds.minY + y), anchor: .topLeading, proposal: .unspecified)
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
        }
    }
}

// MARK: - стеклянный ползунок (эквалайзер / бас)

struct GlassSlider: View {
    @EnvironmentObject var t: Theme
    @Binding var value: Double
    var vertical: Bool
    var range: ClosedRange<Double>
    var fromCenter: Bool

    var body: some View {
        GeometryReader { g in
            let pad: CGFloat = 16
            let len = (vertical ? g.size.height : g.size.width) - pad * 2
            let f = CGFloat((value - range.lowerBound) / (range.upperBound - range.lowerBound))
            let z = fromCenter ? CGFloat((0 - range.lowerBound) / (range.upperBound - range.lowerBound)) : 0
            let pos: (CGFloat) -> CGPoint = { k in
                vertical ? CGPoint(x: g.size.width / 2, y: pad + len * (1 - k))
                         : CGPoint(x: pad + len * k, y: g.size.height / 2)
            }
            ZStack {
                Path { p in p.move(to: pos(0)); p.addLine(to: pos(1)) }
                    .stroke(t.accent(0.2), style: StrokeStyle(lineWidth: 6, lineCap: .round))
                Path { p in p.move(to: pos(z)); p.addLine(to: pos(f)) }
                    .stroke(t.neon, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                Circle().fill(t.neon.opacity(0.35)).frame(width: 40, height: 40).blur(radius: 6).position(pos(f))
                Circle().fill(Color.white.opacity(0.92)).frame(width: 22, height: 22)
                    .overlay(Circle().strokeBorder(t.neon, lineWidth: 2.5))
                    .position(pos(f))
            }
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0).onChanged { v in
                let raw = vertical ? 1 - (v.location.y - pad) / len : (v.location.x - pad) / len
                let k = Double(min(max(raw, 0), 1))
                var nv = range.lowerBound + k * (range.upperBound - range.lowerBound)
                if fromCenter && abs(nv) < (range.upperBound - range.lowerBound) * 0.025 { nv = 0 }
                value = nv
            })
        }
    }
}
