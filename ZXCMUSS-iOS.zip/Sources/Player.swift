import SwiftUI
import AVFoundation
import MediaPlayer
import Accelerate

/// Спектр, который пишет аудио-поток и читает отрисовка (без лишних обновлений SwiftUI).
final class SpectrumBox {
    static let bands = 36
    private let lock = NSLock()
    private var v = [Float](repeating: 0, count: SpectrumBox.bands)

    func set(_ a: [Float]) { lock.lock(); v = a; lock.unlock() }
    func get() -> [Float] { lock.lock(); defer { lock.unlock() }; return v }
    func decay() {
        lock.lock()
        for i in 0..<v.count { v[i] *= 0.86 }
        lock.unlock()
    }
    var bass: Float { let a = get(); return a[0..<6].reduce(0, +) / 6 }
    var mid: Float { let a = get(); return a[6..<18].reduce(0, +) / 12 }
    var high: Float { let a = get(); return a[18..<36].reduce(0, +) / 18 }
}

final class Player: ObservableObject {
    @Published var queue: [Track] = []
    @Published var index = -1
    @Published var isPlaying = false
    @Published var shuffle = false
    /// 0 — без повтора, 1 — повтор всех, 2 — зациклить трек
    @Published var repeatMode = 0
    @Published var duration: Double = 0
    @Published var sleepEnds: Date?
    @Published var errorText: String?

    // эквалайзер / бас
    @Published var fxOn: Bool { didSet { UserDefaults.standard.set(fxOn, forKey: "fx"); applyFx() } }
    @Published var bass: Double { didSet { UserDefaults.standard.set(bass, forKey: "bass"); applyFx() } }
    @Published var eq: [Double] { didSet { UserDefaults.standard.set(eq, forKey: "eqv"); applyFx() } }

    let spectrum = SpectrumBox()

    var current: Track? { queue.indices.contains(index) ? queue[index] : nil }

    private let engine = AVAudioEngine()
    private let node = AVAudioPlayerNode()
    private let eqUnit = AVAudioUnitEQ(numberOfBands: 5)
    private let bassUnit = AVAudioUnitEQ(numberOfBands: 1)
    private var file: AVAudioFile?
    private var startFrame: AVAudioFramePosition = 0
    private var pausedPos: Double = 0
    private var gen = 0
    private var original: [Track] = []
    private var sleepItem: DispatchWorkItem?
    private var wired = false

    private let fftN = 2048
    private var fftSetup: FFTSetup?
    private var window = [Float](repeating: 0, count: 2048)
    private var smooth = [Float](repeating: 0, count: SpectrumBox.bands)
    private var tapInstalled = false

    static let eqFreqs: [Float] = [60, 230, 910, 3600, 14000]

    init() {
        fxOn = UserDefaults.standard.bool(forKey: "fx")
        bass = UserDefaults.standard.double(forKey: "bass")
        let saved = UserDefaults.standard.array(forKey: "eqv") as? [Double]
        eq = (saved?.count == 5) ? saved! : [0, 0, 0, 0, 0]
        shuffle = UserDefaults.standard.bool(forKey: "shuffle")
        repeatMode = UserDefaults.standard.integer(forKey: "repeat")
        vDSP_hann_window(&window, vDSP_Length(fftN), Int32(vDSP_HANN_NORM))
        fftSetup = vDSP_create_fftsetup(11, FFTRadix(kFFTRadix2))
        engine.attach(node)
        engine.attach(eqUnit)
        engine.attach(bassUnit)
        setupBands()
        applyFx()
        setupSession()
        setupRemote()
    }

    deinit {
        if let s = fftSetup { vDSP_destroy_fftsetup(s) }
    }

    // MARK: - эквалайзер

    private func setupBands() {
        for i in 0..<5 {
            let b = eqUnit.bands[i]
            b.filterType = (i == 0) ? .lowShelf : (i == 4 ? .highShelf : .parametric)
            b.frequency = Player.eqFreqs[i]
            b.bandwidth = 1.0
            b.gain = 0
            b.bypass = false
        }
        let bb = bassUnit.bands[0]
        bb.filterType = .lowShelf
        bb.frequency = 90
        bb.bandwidth = 1.0
        bb.gain = 0
        bb.bypass = false
    }

    func applyFx() {
        eqUnit.bypass = !fxOn
        bassUnit.bypass = !fxOn
        for i in 0..<5 {
            eqUnit.bands[i].gain = Float(eq[i] * 12)
        }
        bassUnit.bands[0].gain = Float(bass * 15)
    }

    // MARK: - сессия и пульт

    private func setupSession() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .default, options: [])
        try? s.setActive(true)
        NotificationCenter.default.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] n in
            guard let self = self,
                  let raw = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
            if type == .began { self.pause() }
            else if let o = n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt,
                    AVAudioSession.InterruptionOptions(rawValue: o).contains(.shouldResume) { self.play() }
        }
        NotificationCenter.default.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main) { [weak self] _ in
            guard let self = self, self.current != nil else { return }
            let was = self.isPlaying
            let pos = self.position
            self.openCurrent(at: pos, autoplay: was)
        }
    }

    private func setupRemote() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in self?.play(); return .success }
        c.pauseCommand.addTarget { [weak self] _ in self?.pause(); return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in self?.toggle(); return .success }
        c.nextTrackCommand.addTarget { [weak self] _ in self?.next(); return .success }
        c.previousTrackCommand.addTarget { [weak self] _ in self?.prev(); return .success }
        c.changePlaybackPositionCommand.addTarget { [weak self] e in
            if let e = e as? MPChangePlaybackPositionCommandEvent { self?.seek(to: e.positionTime) }
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let t = current else {
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
            return
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: t.title,
            MPMediaItemPropertyArtist: t.artist.isEmpty ? "Неизвестный исполнитель" : t.artist,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: position,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
    }

    // MARK: - очередь

    func setQueue(_ list: [Track], start: Int, autoplay: Bool, seek: Double = 0) {
        guard list.indices.contains(start) else { return }
        original = list
        let cur = list[start]
        if shuffle {
            var rest = list
            rest.remove(at: start)
            rest.shuffle()
            queue = [cur] + rest
            index = 0
        } else {
            queue = list
            index = start
        }
        openCurrent(at: seek, autoplay: autoplay)
    }

    func playTrack(_ t: Track, in list: [Track]) {
        if let i = list.firstIndex(where: { $0.id == t.id }) { setQueue(list, start: i, autoplay: true) }
    }

    // MARK: - воспроизведение

    private func openCurrent(at pos: Double, autoplay: Bool) {
        gen += 1
        node.stop()
        engine.stop()
        guard let t = current else { isPlaying = false; return }
        do {
            let f = try AVAudioFile(forReading: t.url)
            file = f
            let fmt = f.processingFormat
            if wired {
                engine.disconnectNodeOutput(node)
                engine.disconnectNodeOutput(eqUnit)
                engine.disconnectNodeOutput(bassUnit)
            }
            engine.connect(node, to: eqUnit, format: fmt)
            engine.connect(eqUnit, to: bassUnit, format: fmt)
            engine.connect(bassUnit, to: engine.mainMixerNode, format: fmt)
            wired = true
            duration = Double(f.length) / fmt.sampleRate
            installTap()
            try engine.start()
            UserDefaults.standard.set(t.id, forKey: "lastId")
            schedule(from: max(0, min(pos, max(0, duration - 0.1))))
            if autoplay { node.play(); isPlaying = true } else { isPlaying = false }
        } catch {
            file = nil
            isPlaying = false
            duration = 0
            errorText = "Не удалось открыть: \(t.title)"
        }
        updateNowPlaying()
    }

    private func schedule(from sec: Double) {
        guard let f = file else { return }
        let sr = f.processingFormat.sampleRate
        var sf = AVAudioFramePosition(sec * sr)
        if sf >= f.length { sf = 0 }
        startFrame = sf
        pausedPos = Double(sf) / sr
        let my = gen
        let count = AVAudioFrameCount(f.length - sf)
        node.scheduleSegment(f, startingFrame: sf, frameCount: count, at: nil, completionCallbackType: .dataPlayedBack) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self, self.gen == my else { return }
                self.onComplete()
            }
        }
    }

    var position: Double {
        guard file != nil else { return 0 }
        if isPlaying, let nt = node.lastRenderTime, let pt = node.playerTime(forNodeTime: nt), pt.sampleRate > 0 {
            let p = (Double(startFrame) + Double(pt.sampleTime)) / pt.sampleRate
            return min(max(p, 0), duration)
        }
        return pausedPos
    }

    func play() {
        guard file != nil else { return }
        if !engine.isRunning { try? engine.start() }
        try? AVAudioSession.sharedInstance().setActive(true)
        node.play()
        isPlaying = true
        updateNowPlaying()
    }

    func pause() {
        guard isPlaying else { return }
        pausedPos = position
        node.pause()
        isPlaying = false
        updateNowPlaying()
    }

    func toggle() { isPlaying ? pause() : play() }

    func seek(to sec: Double) {
        guard file != nil else { return }
        let was = isPlaying
        gen += 1
        node.stop()
        schedule(from: max(0, min(sec, duration - 0.05)))
        if was { node.play() }
        isPlaying = was
        updateNowPlaying()
    }

    func next() {
        guard !queue.isEmpty else { return }
        index = (index + 1 < queue.count) ? index + 1 : 0
        openCurrent(at: 0, autoplay: true)
    }

    func prev() {
        guard !queue.isEmpty else { return }
        if position > 3 { seek(to: 0); return }
        index = index > 0 ? index - 1 : queue.count - 1
        openCurrent(at: 0, autoplay: true)
    }

    private func onComplete() {
        if repeatMode == 2 {
            openCurrent(at: 0, autoplay: true)
        } else if index + 1 < queue.count {
            index += 1
            openCurrent(at: 0, autoplay: true)
        } else if repeatMode == 1 {
            index = 0
            openCurrent(at: 0, autoplay: true)
        } else {
            gen += 1
            node.stop()
            isPlaying = false
            schedule(from: 0)
            pausedPos = 0
            updateNowPlaying()
        }
    }

    func setShuffle(_ on: Bool) {
        shuffle = on
        UserDefaults.standard.set(on, forKey: "shuffle")
        guard let cur = current else { return }
        if on {
            var rest = original.filter { $0.id != cur.id }
            rest.shuffle()
            queue = [cur] + rest
            index = 0
        } else {
            queue = original
            index = original.firstIndex(where: { $0.id == cur.id }) ?? 0
        }
    }

    func cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        UserDefaults.standard.set(repeatMode, forKey: "repeat")
    }

    func setSleep(minutes: Int) {
        sleepItem?.cancel()
        sleepItem = nil
        if minutes <= 0 { sleepEnds = nil; return }
        sleepEnds = Date().addingTimeInterval(Double(minutes) * 60)
        let it = DispatchWorkItem { [weak self] in
            self?.sleepEnds = nil
            self?.pause()
        }
        sleepItem = it
        DispatchQueue.main.asyncAfter(deadline: .now() + Double(minutes) * 60, execute: it)
    }

    // MARK: - анализ спектра (БПФ по реальному звуку)

    private func installTap() {
        let mixer = engine.mainMixerNode
        if tapInstalled { mixer.removeTap(onBus: 0) }
        mixer.installTap(onBus: 0, bufferSize: 2048, format: nil) { [weak self] buf, _ in
            self?.analyze(buf)
        }
        tapInstalled = true
    }

    private func analyze(_ buf: AVAudioPCMBuffer) {
        guard let setup = fftSetup, let ch = buf.floatChannelData?[0] else { return }
        let n = fftN
        let frames = min(Int(buf.frameLength), n)
        if frames < 256 { return }
        var input = [Float](repeating: 0, count: n)
        for i in 0..<frames { input[i] = ch[i] * window[i] }
        var re = [Float](repeating: 0, count: n / 2)
        var im = [Float](repeating: 0, count: n / 2)
        var mags = [Float](repeating: 0, count: n / 2)
        re.withUnsafeMutableBufferPointer { rp in
            im.withUnsafeMutableBufferPointer { ip in
                var split = DSPSplitComplex(realp: rp.baseAddress!, imagp: ip.baseAddress!)
                input.withUnsafeBufferPointer { inp in
                    inp.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: n / 2) {
                        vDSP_ctoz($0, 2, &split, 1, vDSP_Length(n / 2))
                    }
                }
                vDSP_fft_zrip(setup, &split, 1, 11, FFTDirection(FFT_FORWARD))
                vDSP_zvmags(&split, 1, &mags, 1, vDSP_Length(n / 2))
            }
        }
        let sr = Float(buf.format.sampleRate)
        let nb = SpectrumBox.bands
        let fLo: Float = 40
        let fHi: Float = min(16000, sr / 2 - 100)
        var out = [Float](repeating: 0, count: nb)
        for b in 0..<nb {
            let f0 = fLo * powf(fHi / fLo, Float(b) / Float(nb))
            let f1 = fLo * powf(fHi / fLo, Float(b + 1) / Float(nb))
            var i0 = Int(f0 * Float(n) / sr)
            var i1 = Int(f1 * Float(n) / sr)
            if i0 < 1 { i0 = 1 }
            if i1 <= i0 { i1 = i0 + 1 }
            if i1 > n / 2 { i1 = n / 2 }
            var s: Float = 0
            var c: Float = 0
            for i in i0..<i1 { s += mags[i]; c += 1 }
            let amp = sqrtf(s / max(c, 1)) / Float(n)
            let db = 20 * log10f(max(amp, 1e-7))
            var lv = (db + 66) / 52 + Float(b) * 0.004
            lv = min(max(lv, 0), 1)
            let old = smooth[b]
            lv = lv > old ? old + (lv - old) * 0.65 : old * 0.86 + lv * 0.14
            smooth[b] = lv
            out[b] = lv
        }
        spectrum.set(out)
    }
}
