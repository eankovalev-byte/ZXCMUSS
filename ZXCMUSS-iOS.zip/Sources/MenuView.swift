import SwiftUI
import UniformTypeIdentifiers

struct ZRow: View {
    @EnvironmentObject var t: Theme
    let icon: String
    let label: String
    var value: String? = nil
    var accent = false
    var checked = false
    var swatch: Color? = nil

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 13, style: .continuous).fill(t.accent(0.12)).frame(width: 42, height: 42)
                if let s = swatch {
                    Circle().fill(s).frame(width: 24, height: 24).overlay(Circle().strokeBorder(t.text.opacity(0.35), lineWidth: 2))
                } else {
                    Image(systemName: icon).font(.system(size: 18, weight: .semibold)).foregroundColor(t.neon)
                }
            }
            Text(label).font(.system(size: 16, weight: .medium)).foregroundColor(t.text)
            Spacer()
            if let v = value { Text(v).font(.system(size: 14)).foregroundColor(accent ? t.neon : t.dim) }
            if checked { Image(systemName: "checkmark").foregroundColor(t.neon).font(.system(size: 16, weight: .bold)) }
        }
        .padding(.horizontal, 8).padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

struct MenuView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var lib: Library
    @EnvironmentObject var player: Player
    @EnvironmentObject var prefs: Prefs
    @Environment(\.dismiss) private var dismiss

    private let sortNames = ["По названию", "По исполнителю", "Недавно добавленные"]

    var body: some View {
        NavigationStack {
            ZStack {
                SheetBG()
                VStack(spacing: 0) {
                    ScrollView {
                        VStack(spacing: 2) {
                            NavigationLink { ThemesView() } label: { ZRow(icon: "paintpalette", label: "Тема", value: Theme.palettes[t.index].name) }
                            NavigationLink { WebMusicView() } label: { ZRow(icon: "icloud.and.arrow.down", label: "Музыка из интернета") }
                            NavigationLink { EqView() } label: { ZRow(icon: "slider.vertical.3", label: "Эквалайзер и бас-буст", value: player.fxOn ? "Вкл" : "Выкл", accent: player.fxOn) }
                            NavigationLink { ImportView() } label: { ZRow(icon: "paperplane", label: "Telegram и файлы") }
                            NavigationLink { SortView() } label: { ZRow(icon: "arrow.up.arrow.down", label: "Сортировка", value: sortNames[min(prefs.sortMode, 2)]) }
                            NavigationLink { SleepView() } label: { ZRow(icon: "timer", label: "Таймер сна", value: player.sleepEnds != nil ? "Вкл" : "Выкл", accent: player.sleepEnds != nil) }
                            Button { prefs.onlineLyrics.toggle() } label: {
                                ZRow(icon: "text.quote", label: "Тексты из интернета", value: prefs.onlineLyrics ? "Вкл" : "Выкл", accent: prefs.onlineLyrics)
                            }
                            Button { Task { await lib.reload() } } label: { ZRow(icon: "arrow.clockwise", label: "Обновить библиотеку") }
                            NavigationLink { AboutView() } label: { ZRow(icon: "info.circle", label: "О приложении") }
                        }
                        .padding(.horizontal, 14).padding(.top, 8)
                    }
                    Button {
                        if let u = URL(string: "https://t.me/xosub") { UIApplication.shared.open(u) }
                    } label: {
                        Text("@xosub донаты в тг автору")
                            .font(.system(size: 12)).foregroundColor(t.text.opacity(0.35))
                            .padding(.vertical, 14)
                    }
                }
            }
            .navigationTitle("ZXCMUSS")
            .navigationBarTitleDisplayMode(.inline)
        }
        .presentationDetents([.large])
        .tint(t.neon)
    }
}

struct ThemesView: View {
    @EnvironmentObject var t: Theme
    var body: some View {
        ZStack {
            SheetBG()
            ScrollView {
                VStack(spacing: 2) {
                    ForEach(0..<Theme.palettes.count, id: \.self) { i in
                        Button { t.index = i } label: {
                            ZRow(icon: "", label: Theme.palettes[i].name, checked: i == t.index, swatch: Theme.palettes[i].accent.color())
                        }
                    }
                }
                .padding(.horizontal, 14).padding(.top, 8)
            }
        }
        .navigationTitle("Тема")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SortView: View {
    @EnvironmentObject var prefs: Prefs
    private let names = ["По названию", "По исполнителю", "Недавно добавленные"]
    var body: some View {
        ZStack {
            SheetBG()
            VStack(spacing: 2) {
                ForEach(0..<3, id: \.self) { i in
                    Button { prefs.sortMode = i } label: { ZRow(icon: "arrow.up.arrow.down", label: names[i], checked: prefs.sortMode == i) }
                }
                Spacer()
            }
            .padding(.horizontal, 14).padding(.top, 8)
        }
        .navigationTitle("Сортировка")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SleepView: View {
    @EnvironmentObject var player: Player
    private let opts = [0, 15, 30, 45, 60, 90]
    var body: some View {
        ZStack {
            SheetBG()
            VStack(spacing: 2) {
                ForEach(opts, id: \.self) { m in
                    Button { player.setSleep(minutes: m) } label: {
                        ZRow(icon: "timer", label: m == 0 ? "Выключить" : "\(m) минут")
                    }
                }
                Spacer()
            }
            .padding(.horizontal, 14).padding(.top, 8)
        }
        .navigationTitle("Таймер сна")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AboutView: View {
    @EnvironmentObject var t: Theme
    var body: some View {
        ZStack {
            SheetBG()
            VStack(alignment: .leading, spacing: 14) {
                Text("ZXCMUSS").font(.system(size: 26, weight: .bold)).kerning(4).foregroundColor(t.text)
                Text("Версия 3.1 (iOS)").foregroundColor(t.neon)
                Text("Плеер с живым спектром, темами, эквалайзером, бас-бустом и поиском свободной музыки.")
                    .foregroundColor(t.text.opacity(0.8))
                Text("Автор: @xosub").foregroundColor(t.dim)
                Spacer()
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .navigationTitle("О приложении")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ImportView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var lib: Library
    @State private var picking = false
    @State private var msg: String?

    var body: some View {
        ZStack {
            SheetBG()
            ScrollView {
                VStack(spacing: 2) {
                    Button { picking = true } label: { ZRow(icon: "plus", label: "Выбрать аудиофайлы") }
                    Button { lib.requestAppleMusic() } label: { ZRow(icon: "music.note.house", label: "Треки из Apple Music") }
                    Button {
                        let p = Library.musicDir.deletingLastPathComponent().path
                        if let u = URL(string: "shareddocuments://" + p) { UIApplication.shared.open(u) }
                    } label: { ZRow(icon: "folder", label: "Открыть папку в «Файлах»") }
                    Text("Из Telegram: откройте аудио → «Поделиться» → «Сохранить в Файлы» (или «Открыть в ZXCMUSS», если приложение есть в списке). Потом выберите файлы здесь или положите их в папку ZXCMUSS в приложении «Файлы» и нажмите «Обновить библиотеку».\n\nПрямая синхронизация с аккаунтом Telegram невозможна: Telegram не даёт сторонним приложениям читать вашу музыку без собственного входа.")
                        .font(.system(size: 14)).foregroundColor(t.text.opacity(0.8))
                        .padding(.horizontal, 8).padding(.top, 12)
                }
                .padding(.horizontal, 14).padding(.top, 8)
            }
        }
        .navigationTitle("Telegram и файлы")
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(isPresented: $picking, allowedContentTypes: [.audio], allowsMultipleSelection: true) { res in
            if case .success(let urls) = res {
                Task { @MainActor in
                    let n = await lib.importURLs(urls)
                    lib.notice = n > 0 ? "Добавлено треков: \(n) (вкладка «Загрузки»)" : "Не удалось сохранить файлы"
                }
            }
        }
    }
}

// MARK: - эквалайзер и бас-буст

struct EqView: View {
    @EnvironmentObject var t: Theme
    @EnvironmentObject var player: Player

    private struct Preset { let name: String; let bands: [Double]; let bass: Double }
    private let presets = [
        Preset(name: "Плоский", bands: [0, 0, 0, 0, 0], bass: 0),
        Preset(name: "Бас-буст", bands: [0.8, 0.5, 0, -0.1, 0], bass: 0.8),
        Preset(name: "Глубокий бас", bands: [1, 0.7, 0.1, -0.2, -0.1], bass: 1),
        Preset(name: "Рок", bands: [0.45, 0.25, -0.15, 0.25, 0.45], bass: 0.2),
        Preset(name: "Поп", bands: [-0.1, 0.25, 0.4, 0.25, -0.1], bass: 0.1),
        Preset(name: "Вокал", bands: [-0.3, 0, 0.5, 0.35, 0], bass: 0),
        Preset(name: "Электро", bands: [0.6, 0.3, 0, 0.25, 0.5], bass: 0.5)
    ]
    private let freqs = ["60", "230", "910", "3.6k", "14k"]

    var body: some View {
        ZStack {
            SheetBG()
            ScrollView {
                VStack(spacing: 14) {
                    HStack {
                        Text("Эквалайзер").font(.system(size: 17, weight: .semibold)).foregroundColor(t.text)
                        Spacer()
                        Pill(title: player.fxOn ? "Вкл" : "Выкл", on: player.fxOn) { player.fxOn.toggle() }
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(0..<presets.count, id: \.self) { i in
                                Pill(title: presets[i].name, on: false, small: true) {
                                    player.fxOn = true
                                    player.eq = presets[i].bands
                                    player.bass = presets[i].bass
                                }
                            }
                        }
                    }
                    HStack(spacing: 0) {
                        ForEach(0..<5, id: \.self) { i in
                            VStack(spacing: 4) {
                                GlassSlider(value: Binding(
                                    get: { player.eq[i] },
                                    set: { v in player.fxOn = true; var e = player.eq; e[i] = v; player.eq = e }
                                ), vertical: true, range: -1...1, fromCenter: true)
                                    .frame(width: 48, height: 180)
                                Text(freqs[i]).font(.system(size: 11)).foregroundColor(t.dim)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    HStack {
                        Text("Бас-буст").font(.system(size: 17, weight: .semibold)).foregroundColor(t.text)
                        Spacer()
                        Text("\(Int(player.bass * 100))%").foregroundColor(t.neon).font(.system(size: 14, weight: .bold))
                    }
                    GlassSlider(value: Binding(
                        get: { player.bass },
                        set: { v in player.fxOn = true; player.bass = v }
                    ), vertical: false, range: 0...1, fromCenter: false)
                        .frame(height: 44)
                }
                .padding(18)
            }
        }
        .navigationTitle("Эквалайзер")
        .navigationBarTitleDisplayMode(.inline)
    }
}
