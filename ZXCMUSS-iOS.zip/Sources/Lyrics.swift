import SwiftUI

struct LrcLine { let t: Double; let text: String }

/// Синхронные тексты: локальный .lrc рядом с файлом или lrclib.net.
@MainActor
final class Lyrics: ObservableObject {
    @Published var lines: [LrcLine] = []
    private var forId: String?

    static func parse(_ text: String) -> [LrcLine] {
        var res: [LrcLine] = []
        guard let rx = try? NSRegularExpression(pattern: "\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]") else { return [] }
        for raw in text.components(separatedBy: .newlines) {
            let ns = raw as NSString
            let ms = rx.matches(in: raw, range: NSRange(location: 0, length: ns.length))
            guard let last = ms.last else { continue }
            let body = ns.substring(from: last.range.location + last.range.length).trimmingCharacters(in: .whitespaces)
            if body.isEmpty { continue }
            for m in ms {
                let mm = Double(ns.substring(with: m.range(at: 1))) ?? 0
                let ss = Double(ns.substring(with: m.range(at: 2))) ?? 0
                var frac = 0.0
                if m.range(at: 3).location != NSNotFound {
                    let f = ns.substring(with: m.range(at: 3))
                    frac = (Double("0." + f) ?? 0)
                }
                res.append(LrcLine(t: mm * 60 + ss + frac, text: body))
            }
        }
        return res.sorted { $0.t < $1.t }
    }

    func load(for t: Track?, online: Bool) {
        guard let t = t else { lines = []; forId = nil; return }
        if forId == t.id && !lines.isEmpty { return }
        forId = t.id
        lines = []
        let id = t.id
        // локальный .lrc
        let local = t.url.deletingPathExtension().appendingPathExtension("lrc")
        if t.url.isFileURL, let s = try? String(contentsOf: local, encoding: .utf8) {
            let l = Lyrics.parse(s)
            if !l.isEmpty { lines = l; return }
        }
        // кэш
        let cache = Lyrics.cacheFile(id)
        if let s = try? String(contentsOfFile: cache, encoding: .utf8) {
            let l = Lyrics.parse(s)
            if !l.isEmpty { lines = l; return }
        }
        guard online else { return }
        Task {
            let txt = await Lyrics.fetch(title: t.title, artist: t.artist, duration: t.duration)
            if let txt = txt {
                try? txt.write(toFile: cache, atomically: true, encoding: .utf8)
                if self.forId == id { self.lines = Lyrics.parse(txt) }
            }
        }
    }

    static func cacheFile(_ id: String) -> String {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let safe = id.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "x"
        return dir.appendingPathComponent("lrc_" + safe + ".lrc").path
    }

    static func fetch(title: String, artist: String, duration: Double) async -> String? {
        func get(_ s: String) async -> Data? {
            guard let u = URL(string: s) else { return nil }
            var r = URLRequest(url: u)
            r.timeoutInterval = 12
            r.setValue("ZXCMUSS/3.1", forHTTPHeaderField: "User-Agent")
            guard let (d, resp) = try? await URLSession.shared.data(for: r),
                  (resp as? HTTPURLResponse)?.statusCode == 200 else { return nil }
            return d
        }
        func enc(_ s: String) -> String { s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s }
        if !artist.isEmpty, duration > 0 {
            let u = "https://lrclib.net/api/get?track_name=\(enc(title))&artist_name=\(enc(artist))&duration=\(Int(duration))"
            if let d = await get(u),
               let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
               let s = o["syncedLyrics"] as? String, !s.isEmpty { return s }
        }
        let q = artist.isEmpty ? title : "\(artist) \(title)"
        if let d = await get("https://lrclib.net/api/search?q=\(enc(q))"),
           let arr = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] {
            for o in arr {
                if let s = o["syncedLyrics"] as? String, !s.isEmpty { return s }
            }
        }
        return nil
    }
}
